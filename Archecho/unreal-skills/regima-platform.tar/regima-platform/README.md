# RegimA Platform

> SkinTwin Cognitive Alchemist Workbench - AI-Powered Skincare Training & Consultation Platform

[![CI](https://github.com/skintwin-ai/regima-platform/actions/workflows/ci.yml/badge.svg)](https://github.com/skintwin-ai/regima-platform/actions/workflows/ci.yml)
[![Release](https://github.com/skintwin-ai/regima-platform/actions/workflows/release.yml/badge.svg)](https://github.com/skintwin-ai/regima-platform/actions/workflows/release.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Overview

RegimA Platform is a comprehensive skincare training and AI consultation system built on the **Zone Concept** methodology. It provides professional skincare education, personalized recommendations, and treatment workflow management through an integrated ecosystem of packages.

### Key Features

- **Training System**: Structured modules and lessons for skincare education
- **AI Consultation**: Personalized skin analysis and product recommendations
- **Zone Concept**: Three-zone approach (SPA, ZON, MED) for balanced skincare
- **Workflow Engine**: Treatment protocol management and progress tracking
- **Product Database**: Comprehensive ingredient and product information
- **CLI Tools**: Command-line interface for all platform features

## Architecture

```
regima-platform/
├── packages/
│   ├── core/          # Core business logic and domain models
│   ├── api/           # REST API server
│   └── cli/           # Command-line interface
├── tests/
│   └── e2e/           # End-to-end tests
├── docker/            # Docker configurations
├── scripts/           # Build and deployment scripts
└── .github/workflows/ # CI/CD pipelines
```

## Quick Start

### Prerequisites

- Node.js 20+
- pnpm 8+

### Installation

```bash
# Clone the repository
git clone https://github.com/skintwin-ai/regima-platform.git
cd regima-platform

# Install dependencies
pnpm install

# Build all packages
pnpm build
```

### Running the API Server

```bash
# Development mode
pnpm dev:api

# Production mode
pnpm build
node packages/api/dist/bin/server.js
```

### Using the CLI

```bash
# Install CLI globally
pnpm --filter @regima/cli build
npm link packages/cli

# Or run directly
pnpm dev:cli -- modules list
```

## Packages

### @regima/core

Core business logic including:
- Zone Concept Analyzer
- Recommendation Engine
- Workflow Engine
- Data schemas and types

```typescript
import { ZoneConceptAnalyzer, RecommendationEngine, WorkflowEngine } from '@regima/core';

const analyzer = new ZoneConceptAnalyzer();
const result = analyzer.analyzeSkinProfile({
  skinType: 'oily',
  skinConcerns: ['acne', 'enlarged pores'],
  currentProducts: [],
  lifestyle: {
    stressLevel: 'moderate',
    sleepQuality: 'good',
    diet: 'moderate',
    sunExposure: 'moderate'
  }
});
```

### @regima/api

REST API server with endpoints for:
- Training modules and lessons
- Products and ingredients
- AI consultations
- Workflows and progress tracking

```bash
# Start server
PORT=3000 node packages/api/dist/bin/server.js

# API endpoints
GET  /health
GET  /api/modules
GET  /api/lessons
GET  /api/products
GET  /api/ingredients
POST /api/agent/consultation
POST /api/agent/routine
POST /api/workflows
GET  /api/progress/:userId
```

### @regima/cli

Command-line interface for:
- Training management
- AI consultations
- Product search
- Workflow management

```bash
# List training modules
regima modules list

# Start AI consultation
regima agent consult

# Search products
regima products search retinol

# Create workflow
regima workflow create -u 1 -t daily_routine

# Check progress
regima progress show 1
```

## The Zone Concept

The platform is built around the **Zone Concept**, a three-zone approach to skincare:

| Zone | Name | Focus | Key Ingredients |
|------|------|-------|-----------------|
| SPA | Anti-inflammatory | Calming, soothing | Niacinamide, Centella Asiatica, Aloe Vera |
| ZON | Anti-oxidant | Protection, brightening | Vitamin C, Vitamin E, Ferulic Acid |
| MED | Rejuvenation | Renewal, anti-aging | Retinol, Peptides, AHAs/BHAs |

## Development

### Scripts

```bash
# Development
pnpm dev:api          # Start API in dev mode
pnpm dev:cli          # Start CLI in dev mode

# Building
pnpm build            # Build all packages
pnpm build:core       # Build core package
pnpm build:api        # Build API package
pnpm build:cli        # Build CLI package

# Testing
pnpm test             # Run all tests
pnpm test:core        # Test core package
pnpm test:api         # Test API package
pnpm test:cli         # Test CLI package
pnpm test:e2e         # Run E2E tests
pnpm test:coverage    # Run with coverage

# Quality
pnpm lint             # Run linter
pnpm lint:fix         # Fix lint issues
pnpm typecheck        # Type checking
pnpm format           # Format code

# Release
pnpm release          # Full release build
pnpm release:archives # Create release archives
```

### Docker

```bash
# Build images
pnpm docker:build

# Start services
pnpm docker:up

# Stop services
pnpm docker:down

# Or using docker-compose directly
docker-compose -f docker/docker-compose.yml up -d
```

### Testing

The platform includes comprehensive tests:

- **Unit Tests**: Core logic, services, utilities
- **Integration Tests**: API routes, database operations
- **E2E Tests**: Full workflow testing

```bash
# Run all tests
pnpm test

# Run with coverage
pnpm test:coverage

# Run specific package tests
pnpm --filter @regima/core test
pnpm --filter @regima/api test
pnpm --filter @regima/cli test
```

## API Reference

### Health Check

```
GET /health
Response: { status: "healthy", version: "1.0.0" }
```

### Modules

```
GET /api/modules
GET /api/modules/:id
GET /api/modules/:id/lessons
```

### Products

```
GET /api/products
GET /api/products/:id
GET /api/products/search?q=query
GET /api/products/categories
GET /api/products/recommendations?skinType=oily&concerns=acne
GET /api/products/:id/zone-analysis
```

### Ingredients

```
GET /api/ingredients
GET /api/ingredients/:name
GET /api/ingredients/search?q=query
GET /api/ingredients/categories
GET /api/ingredients/zones
GET /api/ingredients/compatibility?ingredient1=X&ingredient2=Y
GET /api/ingredients/for-concern/:concern
```

### Agent (AI)

```
POST /api/agent/consultation
POST /api/agent/routine
POST /api/agent/zone-analysis
GET  /api/agent/zone-info
GET  /api/agent/skin-types
GET  /api/agent/concerns
```

### Workflows

```
GET  /api/workflows?userId=1
GET  /api/workflows/types
POST /api/workflows
GET  /api/workflows/:id
GET  /api/workflows/:id/next-steps
POST /api/workflows/:id/execute
POST /api/workflows/:id/progress
POST /api/workflows/:id/adjust
POST /api/workflows/:id/pause
POST /api/workflows/:id/resume
POST /api/workflows/:id/complete
```

### Progress

```
GET  /api/progress/:userId
GET  /api/progress/:userId/modules
GET  /api/progress/:userId/modules/:moduleId
GET  /api/progress/:userId/lessons/:lessonId
POST /api/progress/lesson
POST /api/progress/quiz
GET  /api/progress/:userId/achievements
GET  /api/progress/:userId/streak
GET  /api/progress/:userId/certificate
```

## Configuration

### Environment Variables

```bash
# API Server
PORT=3000
HOST=0.0.0.0
NODE_ENV=production
LOG_LEVEL=info

# Session
SESSION_SECRET=your-secret-key

# Rate Limiting
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX=100
```

### CLI Configuration

Configuration is stored in `~/.regima/config.json`:

```json
{
  "apiUrl": "http://localhost:3000",
  "theme": "dark",
  "outputFormat": "table"
}
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- RegimA skincare methodology and Zone Concept
- SkinTwin AI research and development team
- Open source community

---

Built with ❤️ by the SkinTwin AI Team
