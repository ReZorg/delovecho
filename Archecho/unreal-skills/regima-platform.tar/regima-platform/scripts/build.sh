#!/bin/bash
# RegimA Platform Build Script

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print colored message
print_msg() {
    local color=$1
    local msg=$2
    echo -e "${color}${msg}${NC}"
}

# Print header
print_header() {
    echo ""
    print_msg "$BLUE" "═══════════════════════════════════════════════════════════"
    print_msg "$BLUE" "  $1"
    print_msg "$BLUE" "═══════════════════════════════════════════════════════════"
    echo ""
}

# Check if pnpm is installed
check_pnpm() {
    if ! command -v pnpm &> /dev/null; then
        print_msg "$YELLOW" "pnpm not found. Installing..."
        npm install -g pnpm
    fi
}

# Get version from package.json or argument
get_version() {
    if [ -n "$1" ]; then
        echo "$1"
    else
        node -p "require('./package.json').version"
    fi
}

# Clean build artifacts
clean() {
    print_header "Cleaning build artifacts"
    rm -rf packages/*/dist
    rm -rf packages/*/.turbo
    rm -rf node_modules/.cache
    print_msg "$GREEN" "✓ Clean complete"
}

# Install dependencies
install_deps() {
    print_header "Installing dependencies"
    pnpm install --frozen-lockfile
    print_msg "$GREEN" "✓ Dependencies installed"
}

# Run type check
typecheck() {
    print_header "Running type check"
    pnpm typecheck
    print_msg "$GREEN" "✓ Type check passed"
}

# Run linter
lint() {
    print_header "Running linter"
    pnpm lint
    print_msg "$GREEN" "✓ Lint passed"
}

# Run tests
test() {
    print_header "Running tests"
    pnpm test
    print_msg "$GREEN" "✓ Tests passed"
}

# Build packages
build() {
    print_header "Building packages"
    
    print_msg "$YELLOW" "Building @regima/core..."
    pnpm --filter @regima/core build
    
    print_msg "$YELLOW" "Building @regima/api..."
    pnpm --filter @regima/api build
    
    print_msg "$YELLOW" "Building @regima/cli..."
    pnpm --filter @regima/cli build
    
    # Make CLI executable
    chmod +x packages/cli/dist/bin/regima.js
    
    print_msg "$GREEN" "✓ Build complete"
}

# Create release archives
create_archives() {
    local version=$1
    print_header "Creating release archives (v$version)"
    
    mkdir -p dist
    
    # Core package
    print_msg "$YELLOW" "Creating regima-core-$version.tar.gz..."
    tar -czvf "dist/regima-core-$version.tar.gz" \
        -C packages/core dist package.json README.md 2>/dev/null || true
    
    # API package
    print_msg "$YELLOW" "Creating regima-api-$version.tar.gz..."
    tar -czvf "dist/regima-api-$version.tar.gz" \
        -C packages/api dist package.json README.md 2>/dev/null || true
    
    # CLI package
    print_msg "$YELLOW" "Creating regima-cli-$version.tar.gz..."
    tar -czvf "dist/regima-cli-$version.tar.gz" \
        -C packages/cli dist package.json README.md 2>/dev/null || true
    
    # Full platform
    print_msg "$YELLOW" "Creating regima-platform-$version.tar.gz..."
    tar -czvf "dist/regima-platform-$version.tar.gz" \
        packages/*/dist \
        packages/*/package.json \
        package.json \
        README.md \
        LICENSE 2>/dev/null || true
    
    print_msg "$GREEN" "✓ Archives created in dist/"
    ls -la dist/
}

# Build Docker images
build_docker() {
    local version=$1
    print_header "Building Docker images (v$version)"
    
    print_msg "$YELLOW" "Building API image..."
    docker build -t "regima-api:$version" -t "regima-api:latest" -f docker/Dockerfile.api .
    
    print_msg "$YELLOW" "Building CLI image..."
    docker build -t "regima-cli:$version" -t "regima-cli:latest" -f docker/Dockerfile.cli .
    
    print_msg "$GREEN" "✓ Docker images built"
    docker images | grep regima
}

# Full release build
release() {
    local version=$(get_version "$1")
    print_header "Starting release build (v$version)"
    
    clean
    install_deps
    typecheck
    lint
    test
    build
    create_archives "$version"
    
    print_msg "$GREEN" ""
    print_msg "$GREEN" "═══════════════════════════════════════════════════════════"
    print_msg "$GREEN" "  Release v$version build complete!"
    print_msg "$GREEN" "═══════════════════════════════════════════════════════════"
    print_msg "$GREEN" ""
}

# Show usage
usage() {
    echo "Usage: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  clean           Clean build artifacts"
    echo "  install         Install dependencies"
    echo "  typecheck       Run type check"
    echo "  lint            Run linter"
    echo "  test            Run tests"
    echo "  build           Build all packages"
    echo "  archives [ver]  Create release archives"
    echo "  docker [ver]    Build Docker images"
    echo "  release [ver]   Full release build"
    echo "  all [ver]       Clean, build, test, and create archives"
    echo ""
    echo "Options:"
    echo "  [ver]           Version number (defaults to package.json version)"
}

# Main
main() {
    check_pnpm
    
    case "$1" in
        clean)
            clean
            ;;
        install)
            install_deps
            ;;
        typecheck)
            typecheck
            ;;
        lint)
            lint
            ;;
        test)
            test
            ;;
        build)
            build
            ;;
        archives)
            create_archives "$(get_version "$2")"
            ;;
        docker)
            build_docker "$(get_version "$2")"
            ;;
        release)
            release "$2"
            ;;
        all)
            release "$2"
            build_docker "$(get_version "$2")"
            ;;
        *)
            usage
            exit 1
            ;;
    esac
}

main "$@"
