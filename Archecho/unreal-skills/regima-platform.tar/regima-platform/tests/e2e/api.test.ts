/**
 * End-to-End API Tests
 */

import { describe, it, expect, beforeAll, afterAll } from "vitest";

const API_URL = process.env.API_URL || "http://localhost:3000";

// Helper function for API requests
async function apiRequest(
  endpoint: string,
  options?: RequestInit
): Promise<{ status: number; data: any }> {
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers,
      },
    });

    const data = await response.json().catch(() => null);
    return { status: response.status, data };
  } catch (error) {
    return { status: 0, data: { error: (error as Error).message } };
  }
}

describe("E2E: API Health", () => {
  it("should return healthy status", async () => {
    const { status, data } = await apiRequest("/health");

    // Skip if server not running
    if (status === 0) {
      console.log("Skipping E2E tests - server not running");
      return;
    }

    expect(status).toBe(200);
    expect(data.status).toBe("healthy");
  });
});

describe("E2E: Training Flow", () => {
  it("should complete a full training flow", async () => {
    // 1. Get modules
    const modulesRes = await apiRequest("/api/modules");
    if (modulesRes.status === 0) return; // Skip if server not running

    expect(modulesRes.status).toBe(200);
    expect(modulesRes.data.data.length).toBeGreaterThan(0);

    const firstModule = modulesRes.data.data[0];

    // 2. Get module details
    const moduleRes = await apiRequest(`/api/modules/${firstModule.id}`);
    expect(moduleRes.status).toBe(200);

    // 3. Get lessons for module
    const lessonsRes = await apiRequest(`/api/modules/${firstModule.id}/lessons`);
    expect(lessonsRes.status).toBe(200);

    // 4. Get user progress
    const progressRes = await apiRequest("/api/progress/1");
    expect(progressRes.status).toBe(200);
    expect(progressRes.data.data.userId).toBe(1);

    // 5. Update lesson progress
    const updateRes = await apiRequest("/api/progress/lesson", {
      method: "POST",
      body: JSON.stringify({
        userId: 1,
        lessonId: 1,
        completed: true,
        score: 85,
        timeSpent: 30,
      }),
    });
    expect(updateRes.status).toBe(200);

    // 6. Check achievements
    const achievementsRes = await apiRequest("/api/progress/1/achievements");
    expect(achievementsRes.status).toBe(200);
  });
});

describe("E2E: Consultation Flow", () => {
  it("should complete a full consultation flow", async () => {
    // 1. Get skin types info
    const skinTypesRes = await apiRequest("/api/agent/skin-types");
    if (skinTypesRes.status === 0) return; // Skip if server not running

    expect(skinTypesRes.status).toBe(200);

    // 2. Get concerns info
    const concernsRes = await apiRequest("/api/agent/concerns");
    expect(concernsRes.status).toBe(200);

    // 3. Run consultation
    const consultRes = await apiRequest("/api/agent/consultation", {
      method: "POST",
      body: JSON.stringify({
        skinType: "oily",
        skinConcerns: ["acne", "enlarged pores"],
        goals: ["clear skin"],
        budget: "moderate",
      }),
    });
    expect(consultRes.status).toBe(200);
    expect(consultRes.data.data.summary).toBeDefined();
    expect(consultRes.data.data.zoneRecommendations).toBeDefined();

    // 4. Generate routine
    const routineRes = await apiRequest("/api/agent/routine", {
      method: "POST",
      body: JSON.stringify({
        skinType: "oily",
        skinConcerns: ["acne"],
        routineType: "standard",
        includeWeeklyTreatments: true,
      }),
    });
    expect(routineRes.status).toBe(200);
    expect(routineRes.data.data.morning).toBeDefined();
    expect(routineRes.data.data.evening).toBeDefined();

    // 5. Get zone analysis
    const zoneRes = await apiRequest("/api/agent/zone-analysis", {
      method: "POST",
      body: JSON.stringify({
        skinType: "oily",
        skinConcerns: ["acne"],
      }),
    });
    expect(zoneRes.status).toBe(200);
  });
});

describe("E2E: Workflow Flow", () => {
  let workflowId: string;

  it("should complete a full workflow flow", async () => {
    // 1. Get workflow types
    const typesRes = await apiRequest("/api/workflows/types");
    if (typesRes.status === 0) return; // Skip if server not running

    expect(typesRes.status).toBe(200);

    // 2. Create workflow
    const createRes = await apiRequest("/api/workflows", {
      method: "POST",
      body: JSON.stringify({
        userId: 1,
        protocolType: "daily_routine",
        duration: 30,
        skinProfile: {
          skinType: "oily",
          skinConcerns: ["acne"],
        },
      }),
    });
    expect(createRes.status).toBe(201);
    expect(createRes.data.data.id).toBeDefined();
    workflowId = createRes.data.data.id;

    // 3. Get workflow details
    const detailsRes = await apiRequest(`/api/workflows/${workflowId}`);
    expect(detailsRes.status).toBe(200);

    // 4. Get next steps
    const stepsRes = await apiRequest(`/api/workflows/${workflowId}/next-steps?count=5`);
    expect(stepsRes.status).toBe(200);

    // 5. Execute step
    const executeRes = await apiRequest(`/api/workflows/${workflowId}/execute`, {
      method: "POST",
    });
    expect(executeRes.status).toBe(200);

    // 6. Update progress with feedback
    const progressRes = await apiRequest(`/api/workflows/${workflowId}/progress`, {
      method: "POST",
      body: JSON.stringify({
        stepNotes: "Skin felt good",
        skinResponse: {
          reaction: "positive",
          improvements: ["less oily"],
        },
      }),
    });
    expect(progressRes.status).toBe(200);

    // 7. Pause workflow
    const pauseRes = await apiRequest(`/api/workflows/${workflowId}/pause`, {
      method: "POST",
    });
    expect(pauseRes.status).toBe(200);

    // 8. Resume workflow
    const resumeRes = await apiRequest(`/api/workflows/${workflowId}/resume`, {
      method: "POST",
    });
    expect(resumeRes.status).toBe(200);

    // 9. Complete workflow
    const completeRes = await apiRequest(`/api/workflows/${workflowId}/complete`, {
      method: "POST",
    });
    expect(completeRes.status).toBe(200);
  });
});

describe("E2E: Product Search Flow", () => {
  it("should complete a full product search flow", async () => {
    // 1. Get all products
    const productsRes = await apiRequest("/api/products");
    if (productsRes.status === 0) return; // Skip if server not running

    expect(productsRes.status).toBe(200);

    // 2. Get categories
    const categoriesRes = await apiRequest("/api/products/categories");
    expect(categoriesRes.status).toBe(200);

    // 3. Filter by category
    const filteredRes = await apiRequest("/api/products?category=Cleansers");
    expect(filteredRes.status).toBe(200);

    // 4. Search products
    const searchRes = await apiRequest("/api/products/search?q=retinol");
    expect(searchRes.status).toBe(200);

    // 5. Get product details
    if (productsRes.data.data.length > 0) {
      const productId = productsRes.data.data[0].id;
      const detailsRes = await apiRequest(`/api/products/${productId}`);
      expect(detailsRes.status).toBe(200);

      // 6. Get zone analysis for product
      const zoneRes = await apiRequest(`/api/products/${productId}/zone-analysis`);
      expect(zoneRes.status).toBe(200);
    }

    // 7. Get recommendations
    const recsRes = await apiRequest("/api/products/recommendations?skinType=oily&concerns=acne");
    expect(recsRes.status).toBe(200);
  });
});

describe("E2E: Ingredients Flow", () => {
  it("should complete a full ingredients flow", async () => {
    // 1. Get all ingredients
    const ingredientsRes = await apiRequest("/api/ingredients");
    if (ingredientsRes.status === 0) return; // Skip if server not running

    expect(ingredientsRes.status).toBe(200);

    // 2. Get categories
    const categoriesRes = await apiRequest("/api/ingredients/categories");
    expect(categoriesRes.status).toBe(200);

    // 3. Get zones
    const zonesRes = await apiRequest("/api/ingredients/zones");
    expect(zonesRes.status).toBe(200);

    // 4. Search ingredients
    const searchRes = await apiRequest("/api/ingredients/search?q=retinol");
    expect(searchRes.status).toBe(200);

    // 5. Get ingredient details
    const detailsRes = await apiRequest("/api/ingredients/Retinol");
    expect(detailsRes.status).toBe(200);

    // 6. Check compatibility
    const compatRes = await apiRequest("/api/ingredients/compatibility?ingredient1=Retinol&ingredient2=Niacinamide");
    expect(compatRes.status).toBe(200);

    // 7. Get ingredients for concern
    const concernRes = await apiRequest("/api/ingredients/for-concern/acne");
    expect(concernRes.status).toBe(200);
  });
});
