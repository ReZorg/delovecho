/**
 * CLI Output Utilities
 */

import chalk from "chalk";
import Table from "cli-table3";
import boxen from "boxen";
import figures from "figures";
import ora, { type Ora } from "ora";

export interface OutputOptions {
  json?: boolean;
  quiet?: boolean;
  noColor?: boolean;
}

let globalOptions: OutputOptions = {};

export function setOutputOptions(options: OutputOptions): void {
  globalOptions = options;
}

export function getOutputOptions(): OutputOptions {
  return globalOptions;
}

// Spinners
export function createSpinner(text: string): Ora {
  return ora({
    text,
    color: "cyan",
    spinner: "dots",
  });
}

// Success/Error/Warning/Info messages
export function success(message: string): void {
  if (globalOptions.quiet) return;
  console.log(chalk.green(`${figures.tick} ${message}`));
}

export function error(message: string): void {
  console.error(chalk.red(`${figures.cross} ${message}`));
}

export function warning(message: string): void {
  if (globalOptions.quiet) return;
  console.log(chalk.yellow(`${figures.warning} ${message}`));
}

export function info(message: string): void {
  if (globalOptions.quiet) return;
  console.log(chalk.blue(`${figures.info} ${message}`));
}

// JSON output
export function outputJson(data: unknown): void {
  console.log(JSON.stringify(data, null, 2));
}

// Table output
export function createTable(headers: string[], options?: { compact?: boolean }): Table.Table {
  return new Table({
    head: headers.map((h) => chalk.cyan.bold(h)),
    style: {
      head: [],
      border: [],
      compact: options?.compact,
    },
    chars: {
      top: "─",
      "top-mid": "┬",
      "top-left": "┌",
      "top-right": "┐",
      bottom: "─",
      "bottom-mid": "┴",
      "bottom-left": "└",
      "bottom-right": "┘",
      left: "│",
      "left-mid": "├",
      mid: "─",
      "mid-mid": "┼",
      right: "│",
      "right-mid": "┤",
      middle: "│",
    },
  });
}

export function printTable(table: Table.Table): void {
  console.log(table.toString());
}

// Box output
export function printBox(
  content: string,
  options?: {
    title?: string;
    borderColor?: string;
    padding?: number;
  }
): void {
  console.log(
    boxen(content, {
      title: options?.title,
      titleAlignment: "center",
      padding: options?.padding ?? 1,
      margin: 1,
      borderStyle: "round",
      borderColor: (options?.borderColor as any) ?? "cyan",
    })
  );
}

// Section header
export function printHeader(text: string): void {
  if (globalOptions.quiet) return;
  console.log("");
  console.log(chalk.bold.cyan(`═══ ${text} ═══`));
  console.log("");
}

// Divider
export function printDivider(): void {
  if (globalOptions.quiet) return;
  console.log(chalk.gray("─".repeat(50)));
}

// Key-value pairs
export function printKeyValue(key: string, value: string | number | boolean): void {
  console.log(`${chalk.gray(key + ":")} ${chalk.white(String(value))}`);
}

// List
export function printList(items: string[], options?: { numbered?: boolean; indent?: number }): void {
  const indent = " ".repeat(options?.indent ?? 0);
  items.forEach((item, index) => {
    if (options?.numbered) {
      console.log(`${indent}${chalk.cyan(`${index + 1}.`)} ${item}`);
    } else {
      console.log(`${indent}${chalk.cyan(figures.bullet)} ${item}`);
    }
  });
}

// Progress bar (simple)
export function printProgress(current: number, total: number, label?: string): void {
  const percentage = Math.round((current / total) * 100);
  const filled = Math.round(percentage / 5);
  const empty = 20 - filled;
  const bar = chalk.cyan("█".repeat(filled)) + chalk.gray("░".repeat(empty));
  const labelStr = label ? `${label}: ` : "";
  process.stdout.write(`\r${labelStr}${bar} ${percentage}% (${current}/${total})`);
  if (current === total) {
    console.log("");
  }
}

// Zone colors
export function zoneColor(zone: string): string {
  switch (zone.toLowerCase()) {
    case "spa":
      return chalk.green(zone.toUpperCase());
    case "zon":
      return chalk.yellow(zone.toUpperCase());
    case "med":
      return chalk.red(zone.toUpperCase());
    default:
      return chalk.white(zone);
  }
}

// Score color
export function scoreColor(score: number): string {
  if (score >= 80) return chalk.green(String(score));
  if (score >= 60) return chalk.yellow(String(score));
  if (score >= 40) return chalk.hex("#FFA500")(String(score));
  return chalk.red(String(score));
}

// Status color
export function statusColor(status: string): string {
  switch (status.toLowerCase()) {
    case "active":
    case "completed":
    case "success":
      return chalk.green(status);
    case "paused":
    case "pending":
    case "warning":
      return chalk.yellow(status);
    case "failed":
    case "error":
    case "cancelled":
      return chalk.red(status);
    default:
      return chalk.white(status);
  }
}

// Highlight
export function highlight(text: string): string {
  return chalk.cyan.bold(text);
}

// Dim
export function dim(text: string): string {
  return chalk.gray(text);
}

// Format duration
export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}

// Format date
export function formatDate(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

// Format datetime
export function formatDateTime(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
