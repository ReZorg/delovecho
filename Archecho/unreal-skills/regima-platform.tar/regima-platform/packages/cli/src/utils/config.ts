/**
 * CLI Configuration Utilities
 */

import { existsSync, readFileSync, writeFileSync, mkdirSync } from "fs";
import { join } from "path";
import { homedir } from "os";

export interface CliConfig {
  apiUrl: string;
  defaultUserId?: number;
  theme: "dark" | "light";
  outputFormat: "table" | "json";
  lastProject?: string;
}

const CONFIG_DIR = join(homedir(), ".regima");
const CONFIG_FILE = join(CONFIG_DIR, "config.json");

const DEFAULT_CONFIG: CliConfig = {
  apiUrl: "http://localhost:3000",
  theme: "dark",
  outputFormat: "table",
};

export function ensureConfigDir(): void {
  if (!existsSync(CONFIG_DIR)) {
    mkdirSync(CONFIG_DIR, { recursive: true });
  }
}

export function loadConfig(): CliConfig {
  ensureConfigDir();
  
  if (!existsSync(CONFIG_FILE)) {
    saveConfig(DEFAULT_CONFIG);
    return DEFAULT_CONFIG;
  }
  
  try {
    const content = readFileSync(CONFIG_FILE, "utf-8");
    return { ...DEFAULT_CONFIG, ...JSON.parse(content) };
  } catch {
    return DEFAULT_CONFIG;
  }
}

export function saveConfig(config: CliConfig): void {
  ensureConfigDir();
  writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

export function updateConfig(updates: Partial<CliConfig>): CliConfig {
  const current = loadConfig();
  const updated = { ...current, ...updates };
  saveConfig(updated);
  return updated;
}

export function getConfigValue<K extends keyof CliConfig>(key: K): CliConfig[K] {
  const config = loadConfig();
  return config[key];
}

export function setConfigValue<K extends keyof CliConfig>(key: K, value: CliConfig[K]): void {
  updateConfig({ [key]: value });
}

// API client helper
export async function apiRequest<T>(
  endpoint: string,
  options?: RequestInit
): Promise<T> {
  const config = loadConfig();
  const url = `${config.apiUrl}${endpoint}`;
  
  const response = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });
  
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: response.statusText }));
    throw new Error(error.message || `API request failed: ${response.status}`);
  }
  
  return response.json();
}

// Project file helpers
export interface ProjectConfig {
  name: string;
  version: string;
  description?: string;
  apiUrl?: string;
}

const PROJECT_FILE = "regima.json";

export function findProjectRoot(startDir: string = process.cwd()): string | null {
  let currentDir = startDir;
  
  while (currentDir !== "/") {
    if (existsSync(join(currentDir, PROJECT_FILE))) {
      return currentDir;
    }
    currentDir = join(currentDir, "..");
  }
  
  return null;
}

export function loadProjectConfig(projectDir?: string): ProjectConfig | null {
  const dir = projectDir || findProjectRoot();
  if (!dir) return null;
  
  const configPath = join(dir, PROJECT_FILE);
  if (!existsSync(configPath)) return null;
  
  try {
    const content = readFileSync(configPath, "utf-8");
    return JSON.parse(content);
  } catch {
    return null;
  }
}

export function saveProjectConfig(config: ProjectConfig, projectDir: string): void {
  const configPath = join(projectDir, PROJECT_FILE);
  writeFileSync(configPath, JSON.stringify(config, null, 2));
}

export function isInProject(): boolean {
  return findProjectRoot() !== null;
}
