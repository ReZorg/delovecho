/**
 * @regima/cli
 * 
 * Command-line interface for the RegimA Training Platform.
 * Provides tools for managing training content, running consultations,
 * and interacting with the AI agent.
 */

export * from "./commands";
export * from "./utils/output";
export * from "./utils/config";

export const VERSION = "1.0.0";
