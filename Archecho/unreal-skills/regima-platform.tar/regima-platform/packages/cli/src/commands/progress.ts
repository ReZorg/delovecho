/**
 * Progress Command - Training Progress Tracking
 */

import { Command } from "commander";
import chalk from "chalk";
import { 
  createSpinner, 
  createTable, 
  printTable, 
  success, 
  error, 
  outputJson,
  printHeader,
  printKeyValue,
  highlight,
  getOutputOptions,
  printList,
  scoreColor,
  printProgress,
  formatDuration,
} from "../utils/output";
import { apiRequest } from "../utils/config";

interface ApiResponse<T> {
  success: boolean;
  data: T;
}

export const progressCommand = new Command("progress")
  .description("Track training progress")
  .option("--json", "Output as JSON");

// Show overall progress
progressCommand
  .command("show <userId>")
  .description("Show overall progress for a user")
  .action(async (userId: string) => {
    const spinner = createSpinner("Fetching progress...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>(`/api/progress/${userId}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const progress = response.data;

      printHeader("Training Progress");

      // Overall stats
      console.log(chalk.cyan.bold("Overall Progress:"));
      printKeyValue("  Modules Completed", `${progress.modulesCompleted}/${progress.totalModules}`);
      printKeyValue("  Lessons Completed", `${progress.lessonsCompleted}/${progress.totalLessons}`);
      printKeyValue("  Average Score", scoreColor(progress.averageScore) + "%");
      printKeyValue("  Total Time Spent", formatDuration(progress.totalTimeSpent));

      // Progress bar
      console.log("");
      const percentage = Math.round((progress.lessonsCompleted / progress.totalLessons) * 100);
      const filled = Math.round(percentage / 5);
      const empty = 20 - filled;
      const bar = chalk.cyan("█".repeat(filled)) + chalk.gray("░".repeat(empty));
      console.log(`  Progress: ${bar} ${percentage}%`);

      // Streak
      console.log(chalk.cyan.bold("\nLearning Streak:"));
      printKeyValue("  Current Streak", `${progress.currentStreak} days 🔥`);
      printKeyValue("  Longest Streak", `${progress.longestStreak} days`);

      if (progress.lastActivityAt) {
        printKeyValue("  Last Activity", new Date(progress.lastActivityAt).toLocaleDateString());
      }

      success("Progress retrieved!");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch progress: ${(err as Error).message}`);
    }
  });

// Show module progress
progressCommand
  .command("modules <userId>")
  .description("Show module-level progress")
  .action(async (userId: string) => {
    const spinner = createSpinner("Fetching module progress...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any[]>>(`/api/progress/${userId}/modules`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Module Progress");

      const table = createTable(["Module", "Lessons", "Progress", "Avg Score"]);
      
      for (const mod of response.data) {
        const progress = Math.round((mod.lessonsCompleted / mod.totalLessons) * 100);
        const progressBar = chalk.cyan("█".repeat(Math.round(progress / 10))) + 
                          chalk.gray("░".repeat(10 - Math.round(progress / 10)));
        
        table.push([
          `Module ${mod.moduleId}`,
          `${mod.lessonsCompleted}/${mod.totalLessons}`,
          `${progressBar} ${progress}%`,
          mod.averageScore > 0 ? scoreColor(mod.averageScore) + "%" : "-",
        ]);
      }

      printTable(table);
      success("Module progress retrieved!");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch module progress: ${(err as Error).message}`);
    }
  });

// Show detailed module progress
progressCommand
  .command("module <userId> <moduleId>")
  .description("Show detailed progress for a specific module")
  .action(async (userId: string, moduleId: string) => {
    const spinner = createSpinner("Fetching module details...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>(`/api/progress/${userId}/modules/${moduleId}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const data = response.data;

      printHeader(`Module ${moduleId} Progress`);

      printKeyValue("Lessons Completed", `${data.module.lessonsCompleted}/${data.module.totalLessons}`);
      printKeyValue("Average Score", data.module.averageScore > 0 ? scoreColor(data.module.averageScore) + "%" : "-");

      console.log(chalk.cyan.bold("\nLessons:"));
      const table = createTable(["Lesson", "Status", "Score", "Attempts"]);
      
      for (const lesson of data.lessons) {
        table.push([
          `Lesson ${lesson.lessonId}`,
          lesson.completed ? chalk.green("✓ Completed") : chalk.gray("○ Not started"),
          lesson.score !== undefined ? scoreColor(lesson.score) + "%" : "-",
          String(lesson.attempts),
        ]);
      }

      printTable(table);
      success("Module details retrieved!");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch module details: ${(err as Error).message}`);
    }
  });

// Update lesson progress
progressCommand
  .command("update")
  .description("Update lesson progress")
  .requiredOption("-u, --user <userId>", "User ID")
  .requiredOption("-l, --lesson <lessonId>", "Lesson ID")
  .option("-c, --completed", "Mark as completed")
  .option("-s, --score <score>", "Quiz score")
  .option("-t, --time <minutes>", "Time spent in minutes")
  .action(async (options) => {
    const spinner = createSpinner("Updating progress...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>("/api/progress/lesson", {
        method: "POST",
        body: JSON.stringify({
          userId: parseInt(options.user, 10),
          lessonId: parseInt(options.lesson, 10),
          completed: options.completed || false,
          score: options.score ? parseInt(options.score, 10) : undefined,
          timeSpent: options.time ? parseInt(options.time, 10) : undefined,
        }),
      });

      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Progress Updated");
      printKeyValue("Lesson", options.lesson);
      printKeyValue("Completed", response.data.completed ? "Yes" : "No");
      if (response.data.score !== undefined) {
        printKeyValue("Score", scoreColor(response.data.score) + "%");
      }
      printKeyValue("Attempts", response.data.attempts);

      success("Progress updated successfully!");
    } catch (err) {
      spinner.stop();
      error(`Failed to update progress: ${(err as Error).message}`);
    }
  });

// Show achievements
progressCommand
  .command("achievements <userId>")
  .description("Show user achievements")
  .action(async (userId: string) => {
    const spinner = createSpinner("Fetching achievements...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any[]>>(`/api/progress/${userId}/achievements`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Achievements");

      if (response.data.length === 0) {
        console.log(chalk.gray("No achievements earned yet. Keep learning!"));
        return;
      }

      for (const achievement of response.data) {
        console.log(`\n  ${achievement.icon} ${highlight(achievement.name)}`);
        console.log(chalk.gray(`     ${achievement.description}`));
        console.log(chalk.gray(`     Earned: ${new Date(achievement.earnedAt).toLocaleDateString()}`));
      }

      console.log("");
      success(`${response.data.length} achievements earned!`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch achievements: ${(err as Error).message}`);
    }
  });

// Show streak
progressCommand
  .command("streak <userId>")
  .description("Show learning streak")
  .action(async (userId: string) => {
    const spinner = createSpinner("Fetching streak...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>(`/api/progress/${userId}/streak`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const streak = response.data;

      printHeader("Learning Streak");

      console.log(chalk.yellow.bold(`\n  🔥 Current Streak: ${streak.currentStreak} days`));
      console.log(chalk.cyan(`  🏆 Longest Streak: ${streak.longestStreak} days`));
      
      if (streak.lastActivityDate) {
        console.log(chalk.gray(`\n  Last activity: ${new Date(streak.lastActivityDate).toLocaleDateString()}`));
      }

      if (streak.currentStreak >= 7) {
        console.log(chalk.green("\n  Great job! Keep up the momentum! 💪"));
      } else if (streak.currentStreak > 0) {
        console.log(chalk.yellow("\n  You're building a habit! Don't break the chain! 📚"));
      } else {
        console.log(chalk.gray("\n  Start learning today to begin your streak! 🚀"));
      }

      console.log("");
      success("Streak info retrieved!");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch streak: ${(err as Error).message}`);
    }
  });

// Check certificate eligibility
progressCommand
  .command("certificate <userId>")
  .description("Check certificate eligibility")
  .action(async (userId: string) => {
    const spinner = createSpinner("Checking eligibility...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>(`/api/progress/${userId}/certificate`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const cert = response.data;

      printHeader("Certificate Eligibility");

      if (cert.eligible) {
        console.log(chalk.green.bold("\n  🎓 Congratulations! You are eligible for certification!"));
        console.log(chalk.cyan(`\n  Certificate: ${cert.certificateType}`));
      } else {
        console.log(chalk.yellow("\n  📋 Requirements to earn your certificate:"));
      }

      console.log(chalk.cyan.bold("\nRequirements:"));
      const table = createTable(["Requirement", "Status", "Progress"]);
      
      for (const req of cert.requirements) {
        table.push([
          req.requirement,
          req.met ? chalk.green("✓ Met") : chalk.red("✗ Not met"),
          `${req.current}/${req.required}`,
        ]);
      }

      printTable(table);

      if (!cert.eligible) {
        console.log(chalk.gray("\n  Keep learning to earn your RegimA certification!"));
      }

      console.log("");
      success("Eligibility check complete!");
    } catch (err) {
      spinner.stop();
      error(`Failed to check eligibility: ${(err as Error).message}`);
    }
  });
