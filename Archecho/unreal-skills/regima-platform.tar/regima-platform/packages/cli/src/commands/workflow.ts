/**
 * Workflow Command - Treatment Protocol Management
 */

import { Command } from "commander";
import chalk from "chalk";
import inquirer from "inquirer";
import { 
  createSpinner, 
  createTable, 
  printTable, 
  success, 
  error, 
  outputJson,
  printHeader,
  printKeyValue,
  highlight,
  getOutputOptions,
  printList,
  zoneColor,
  statusColor,
  formatDate,
  scoreColor,
} from "../utils/output";
import { apiRequest } from "../utils/config";

interface ApiResponse<T> {
  success: boolean;
  data: T;
}

export const workflowCommand = new Command("workflow")
  .description("Manage treatment workflows")
  .option("--json", "Output as JSON");

// List workflows
workflowCommand
  .command("list")
  .description("List all workflows for a user")
  .requiredOption("-u, --user <userId>", "User ID")
  .action(async (options) => {
    const spinner = createSpinner("Fetching workflows...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any[]>>(`/api/workflows?userId=${options.user}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Active Workflows");

      if (response.data.length === 0) {
        console.log(chalk.gray("No active workflows found."));
        return;
      }

      const table = createTable(["ID", "Type", "Status", "Progress", "Started"]);
      
      for (const wf of response.data) {
        const progress = `${wf.progress.completedSteps}/${wf.progress.totalSteps}`;
        table.push([
          wf.id.substring(0, 20) + "...",
          wf.type,
          statusColor(wf.status),
          progress,
          formatDate(wf.startDate),
        ]);
      }

      printTable(table);
      success(`Found ${response.data.length} workflows`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch workflows: ${(err as Error).message}`);
    }
  });

// Show workflow types
workflowCommand
  .command("types")
  .description("List available workflow types")
  .action(async () => {
    const spinner = createSpinner("Fetching workflow types...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any[]>>("/api/workflows/types");
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Workflow Types");

      for (const type of response.data) {
        console.log(chalk.cyan.bold(`\n${type.name}:`));
        console.log(chalk.gray(type.description));
        console.log(chalk.yellow(`  Default Duration: ${type.defaultDuration} days`));
      }

      console.log("");
      success(`Found ${response.data.length} workflow types`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch workflow types: ${(err as Error).message}`);
    }
  });

// Create workflow
workflowCommand
  .command("create")
  .description("Create a new workflow")
  .requiredOption("-u, --user <userId>", "User ID")
  .option("-t, --type <type>", "Workflow type")
  .option("-d, --duration <days>", "Duration in days")
  .option("-i, --interactive", "Interactive mode")
  .action(async (options) => {
    let workflowData: any = {
      userId: parseInt(options.user, 10),
    };

    if (options.interactive) {
      // Fetch workflow types
      const typesResponse = await apiRequest<ApiResponse<any[]>>("/api/workflows/types");
      const types = typesResponse.data;

      const answers = await inquirer.prompt([
        {
          type: "list",
          name: "protocolType",
          message: "Select workflow type:",
          choices: types.map((t) => ({ name: `${t.name} (${t.defaultDuration} days)`, value: t.id })),
        },
        {
          type: "number",
          name: "duration",
          message: "Duration in days (leave empty for default):",
          default: undefined,
        },
        {
          type: "input",
          name: "skinType",
          message: "Skin type:",
          default: "normal",
        },
        {
          type: "input",
          name: "concerns",
          message: "Skin concerns (comma-separated):",
          default: "",
        },
      ]);

      workflowData = {
        ...workflowData,
        protocolType: answers.protocolType,
        duration: answers.duration || undefined,
        skinProfile: {
          skinType: answers.skinType,
          skinConcerns: answers.concerns.split(",").map((c: string) => c.trim()).filter(Boolean),
          goals: [],
        },
      };
    } else {
      if (!options.type) {
        error("Workflow type is required. Use -t or --interactive");
        return;
      }
      workflowData.protocolType = options.type;
      if (options.duration) {
        workflowData.duration = parseInt(options.duration, 10);
      }
    }

    const spinner = createSpinner("Creating workflow...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>("/api/workflows", {
        method: "POST",
        body: JSON.stringify(workflowData),
      });

      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const wf = response.data;

      printHeader("Workflow Created");
      printKeyValue("ID", wf.id);
      printKeyValue("Type", wf.type);
      printKeyValue("Name", wf.name);
      printKeyValue("Duration", `${wf.duration} days`);
      printKeyValue("Status", statusColor(wf.status));
      printKeyValue("Total Steps", wf.steps.length);

      success("Workflow created successfully!");
    } catch (err) {
      spinner.stop();
      error(`Failed to create workflow: ${(err as Error).message}`);
    }
  });

// Show workflow details
workflowCommand
  .command("show <id>")
  .description("Show workflow details")
  .action(async (id: string) => {
    const spinner = createSpinner("Fetching workflow...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>(`/api/workflows/${id}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const wf = response.data;

      printHeader(wf.name);
      
      printKeyValue("ID", wf.id);
      printKeyValue("Type", wf.type);
      printKeyValue("Status", statusColor(wf.status));
      printKeyValue("Duration", `${wf.duration} days`);
      printKeyValue("Start Date", formatDate(wf.startDate));
      if (wf.endDate) {
        printKeyValue("End Date", formatDate(wf.endDate));
      }

      console.log(chalk.cyan.bold("\nProgress:"));
      printKeyValue("  Completed Steps", `${wf.progress.completedSteps}/${wf.progress.totalSteps}`);
      printKeyValue("  Compliance", scoreColor(wf.progress.compliance) + "%");

      if (wf.progress.skinImprovements) {
        console.log(chalk.cyan.bold("\nSkin Improvements:"));
        for (const [key, value] of Object.entries(wf.progress.skinImprovements)) {
          printKeyValue(`  ${key}`, scoreColor(value as number) + "%");
        }
      }

      console.log(chalk.cyan.bold("\nSteps:"));
      const table = createTable(["#", "Type", "Zone", "Status", "Time"]);
      
      for (const step of wf.steps.slice(0, 10)) {
        table.push([
          String(step.order),
          step.type,
          zoneColor(step.zone),
          step.completed ? chalk.green("✓") : chalk.gray("○"),
          step.time || "-",
        ]);
      }
      
      printTable(table);

      if (wf.steps.length > 10) {
        console.log(chalk.gray(`  ... and ${wf.steps.length - 10} more steps`));
      }

      success("Workflow details retrieved");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch workflow: ${(err as Error).message}`);
    }
  });

// Get next steps
workflowCommand
  .command("next <id>")
  .description("Get next steps in a workflow")
  .option("-c, --count <count>", "Number of steps to show", "5")
  .action(async (id: string, options) => {
    const spinner = createSpinner("Fetching next steps...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any[]>>(`/api/workflows/${id}/next-steps?count=${options.count}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Next Steps");

      if (response.data.length === 0) {
        console.log(chalk.gray("No pending steps."));
        return;
      }

      for (const step of response.data) {
        console.log(chalk.cyan.bold(`\nStep ${step.order}: ${step.type}`));
        console.log(`  Zone: ${zoneColor(step.zone)}`);
        console.log(`  Products: ${step.products.join(", ")}`);
        console.log(`  Instructions: ${step.instructions}`);
        if (step.duration) {
          console.log(`  Duration: ${step.duration} minutes`);
        }
        if (step.time) {
          console.log(`  Time: ${step.time}`);
        }
      }

      console.log("");
      success(`Showing ${response.data.length} upcoming steps`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch next steps: ${(err as Error).message}`);
    }
  });

// Execute step
workflowCommand
  .command("execute <id>")
  .description("Execute the current step in a workflow")
  .action(async (id: string) => {
    const spinner = createSpinner("Executing step...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>(`/api/workflows/${id}/execute`, {
        method: "POST",
      });

      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const step = response.data;

      printHeader("Step Completed");
      printKeyValue("Step", step.order);
      printKeyValue("Type", step.type);
      printKeyValue("Zone", zoneColor(step.zone));
      printKeyValue("Completed At", formatDate(step.completedAt));

      success("Step executed successfully!");
    } catch (err) {
      spinner.stop();
      error(`Failed to execute step: ${(err as Error).message}`);
    }
  });

// Pause workflow
workflowCommand
  .command("pause <id>")
  .description("Pause a workflow")
  .action(async (id: string) => {
    const spinner = createSpinner("Pausing workflow...");
    spinner.start();

    try {
      await apiRequest<ApiResponse<any>>(`/api/workflows/${id}/pause`, {
        method: "POST",
      });

      spinner.stop();
      success("Workflow paused successfully!");
    } catch (err) {
      spinner.stop();
      error(`Failed to pause workflow: ${(err as Error).message}`);
    }
  });

// Resume workflow
workflowCommand
  .command("resume <id>")
  .description("Resume a paused workflow")
  .action(async (id: string) => {
    const spinner = createSpinner("Resuming workflow...");
    spinner.start();

    try {
      await apiRequest<ApiResponse<any>>(`/api/workflows/${id}/resume`, {
        method: "POST",
      });

      spinner.stop();
      success("Workflow resumed successfully!");
    } catch (err) {
      spinner.stop();
      error(`Failed to resume workflow: ${(err as Error).message}`);
    }
  });

// Complete workflow
workflowCommand
  .command("complete <id>")
  .description("Mark a workflow as complete")
  .action(async (id: string) => {
    const spinner = createSpinner("Completing workflow...");
    spinner.start();

    try {
      await apiRequest<ApiResponse<any>>(`/api/workflows/${id}/complete`, {
        method: "POST",
      });

      spinner.stop();
      success("Workflow completed successfully!");
    } catch (err) {
      spinner.stop();
      error(`Failed to complete workflow: ${(err as Error).message}`);
    }
  });
