/**
 * Init Command - Project Initialization
 */

import { Command } from "commander";
import chalk from "chalk";
import inquirer from "inquirer";
import { existsSync, mkdirSync, writeFileSync } from "fs";
import { join } from "path";
import { 
  createSpinner, 
  success, 
  error, 
  info,
  printHeader,
  printKeyValue,
  printList,
} from "../utils/output";
import { saveProjectConfig, type ProjectConfig } from "../utils/config";

export const initCommand = new Command("init")
  .description("Initialize a new RegimA project")
  .option("-n, --name <name>", "Project name")
  .option("-y, --yes", "Skip prompts and use defaults")
  .action(async (options) => {
    printHeader("Initialize RegimA Project");

    let projectConfig: ProjectConfig;

    if (options.yes) {
      projectConfig = {
        name: options.name || "regima-project",
        version: "1.0.0",
        description: "A RegimA skincare training project",
      };
    } else {
      const answers = await inquirer.prompt([
        {
          type: "input",
          name: "name",
          message: "Project name:",
          default: options.name || "regima-project",
          validate: (input) => {
            if (!input.match(/^[a-z0-9-]+$/)) {
              return "Project name must be lowercase alphanumeric with hyphens only";
            }
            return true;
          },
        },
        {
          type: "input",
          name: "version",
          message: "Version:",
          default: "1.0.0",
        },
        {
          type: "input",
          name: "description",
          message: "Description:",
          default: "A RegimA skincare training project",
        },
        {
          type: "input",
          name: "apiUrl",
          message: "API URL:",
          default: "http://localhost:3000",
        },
      ]);

      projectConfig = answers;
    }

    const projectDir = process.cwd();
    const spinner = createSpinner("Creating project structure...");
    spinner.start();

    try {
      // Create directories
      const dirs = [
        "src",
        "src/data",
        "src/modules",
        "src/workflows",
        "tests",
        "docs",
        ".regima",
      ];

      for (const dir of dirs) {
        const dirPath = join(projectDir, dir);
        if (!existsSync(dirPath)) {
          mkdirSync(dirPath, { recursive: true });
        }
      }

      // Create regima.json
      saveProjectConfig(projectConfig, projectDir);

      // Create .gitignore
      const gitignore = `# Dependencies
node_modules/

# Build output
dist/
build/

# Environment
.env
.env.local

# IDE
.vscode/
.idea/

# OS
.DS_Store
Thumbs.db

# Logs
logs/
*.log

# RegimA
.regima/cache/
`;
      writeFileSync(join(projectDir, ".gitignore"), gitignore);

      // Create README.md
      const readme = `# ${projectConfig.name}

${projectConfig.description}

## Getting Started

### Prerequisites

- Node.js 18+
- RegimA CLI (\`npm install -g @regima/cli\`)

### Installation

\`\`\`bash
npm install
\`\`\`

### Running the API Server

\`\`\`bash
regima server start
\`\`\`

### CLI Commands

\`\`\`bash
# List training modules
regima modules list

# Start AI consultation
regima agent consult

# Search products
regima products search retinol

# Check progress
regima progress show 1
\`\`\`

## Project Structure

\`\`\`
${projectConfig.name}/
├── src/
│   ├── data/          # Custom data files
│   ├── modules/       # Custom training modules
│   └── workflows/     # Custom workflows
├── tests/             # Test files
├── docs/              # Documentation
├── regima.json        # Project configuration
└── README.md
\`\`\`

## License

MIT
`;
      writeFileSync(join(projectDir, "README.md"), readme);

      // Create example data file
      const exampleData = `{
  "customProducts": [],
  "customIngredients": [],
  "customWorkflows": []
}
`;
      writeFileSync(join(projectDir, "src/data/custom.json"), exampleData);

      spinner.stop();

      console.log("");
      success("Project initialized successfully!");
      console.log("");

      printKeyValue("Project", projectConfig.name);
      printKeyValue("Location", projectDir);
      console.log("");

      console.log(chalk.cyan.bold("Created files:"));
      printList([
        "regima.json - Project configuration",
        ".gitignore - Git ignore rules",
        "README.md - Project documentation",
        "src/data/custom.json - Custom data",
      ], { indent: 2 });

      console.log("");
      console.log(chalk.cyan.bold("Next steps:"));
      printList([
        "Run 'regima server start' to start the API server",
        "Run 'regima modules list' to view training modules",
        "Run 'regima agent consult' to start an AI consultation",
      ], { numbered: true, indent: 2 });

    } catch (err) {
      spinner.stop();
      error(`Failed to initialize project: ${(err as Error).message}`);
    }
  });
