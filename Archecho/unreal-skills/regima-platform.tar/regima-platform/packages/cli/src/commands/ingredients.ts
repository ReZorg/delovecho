/**
 * Ingredients Command
 */

import { Command } from "commander";
import chalk from "chalk";
import { 
  createSpinner, 
  createTable, 
  printTable, 
  success, 
  error, 
  outputJson,
  printHeader,
  printKeyValue,
  highlight,
  getOutputOptions,
  printList,
  zoneColor,
} from "../utils/output";
import { apiRequest } from "../utils/config";

interface Ingredient {
  name: string;
  inciName?: string;
  category: string;
  mainFunctions: string[];
  benefits: string[];
  concentration: string;
  notes: string;
  skinTypes?: string[];
  concerns?: string[];
  zoneCompatibility?: string[];
}

interface ApiResponse<T> {
  success: boolean;
  data: T;
  meta?: Record<string, unknown>;
}

export const ingredientsCommand = new Command("ingredients")
  .description("Browse and search ingredients")
  .option("--json", "Output as JSON");

// List ingredients
ingredientsCommand
  .command("list")
  .description("List all ingredients")
  .option("-c, --category <category>", "Filter by category")
  .option("-z, --zone <zone>", "Filter by zone (spa/zon/med)")
  .option("-s, --skin-type <skinType>", "Filter by skin type")
  .option("--concern <concern>", "Filter by skin concern")
  .action(async (options) => {
    const spinner = createSpinner("Fetching ingredients...");
    spinner.start();

    try {
      const params = new URLSearchParams();
      if (options.category) params.append("category", options.category);
      if (options.zone) params.append("zone", options.zone);
      if (options.skinType) params.append("skinType", options.skinType);
      if (options.concern) params.append("concern", options.concern);

      const endpoint = `/api/ingredients?${params.toString()}`;
      const response = await apiRequest<ApiResponse<Ingredient[]>>(endpoint);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Ingredients");

      const table = createTable(["Name", "Category", "Concentration", "Zones"]);
      
      for (const ing of response.data) {
        const zones = ing.zoneCompatibility?.map((z) => zoneColor(z)).join(", ") || "-";
        
        table.push([
          highlight(ing.name),
          ing.category,
          ing.concentration,
          zones,
        ]);
      }

      printTable(table);
      success(`Found ${response.data.length} ingredients`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch ingredients: ${(err as Error).message}`);
    }
  });

// Show ingredient details
ingredientsCommand
  .command("show <name>")
  .description("Show details of a specific ingredient")
  .action(async (name: string) => {
    const spinner = createSpinner("Fetching ingredient...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<Ingredient>>(`/api/ingredients/${encodeURIComponent(name)}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const ing = response.data;

      printHeader(ing.name);
      
      if (ing.inciName) {
        printKeyValue("INCI Name", ing.inciName);
      }
      printKeyValue("Category", ing.category);
      printKeyValue("Concentration", ing.concentration);

      if (ing.mainFunctions && ing.mainFunctions.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Main Functions:"));
        printList(ing.mainFunctions);
      }

      if (ing.benefits && ing.benefits.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Benefits:"));
        printList(ing.benefits);
      }

      if (ing.skinTypes && ing.skinTypes.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Suitable Skin Types:"));
        printList(ing.skinTypes);
      }

      if (ing.concerns && ing.concerns.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Addresses Concerns:"));
        printList(ing.concerns);
      }

      if (ing.zoneCompatibility && ing.zoneCompatibility.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Zone Compatibility:"));
        printList(ing.zoneCompatibility.map((z) => zoneColor(z)));
      }

      if (ing.notes) {
        console.log("");
        console.log(chalk.cyan.bold("Notes:"));
        console.log(chalk.gray(ing.notes));
      }

      success("Ingredient details retrieved");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch ingredient: ${(err as Error).message}`);
    }
  });

// Search ingredients
ingredientsCommand
  .command("search <query>")
  .description("Search ingredients by name or function")
  .action(async (query: string) => {
    const spinner = createSpinner("Searching ingredients...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<Ingredient[]>>(`/api/ingredients/search?q=${encodeURIComponent(query)}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader(`Search Results for "${query}"`);

      if (response.data.length === 0) {
        console.log(chalk.gray("No ingredients found matching your query."));
        return;
      }

      const table = createTable(["Name", "Category", "Benefits"]);
      
      for (const ing of response.data) {
        table.push([
          highlight(ing.name),
          ing.category,
          ing.benefits.slice(0, 2).join(", "),
        ]);
      }

      printTable(table);
      success(`Found ${response.data.length} matching ingredients`);
    } catch (err) {
      spinner.stop();
      error(`Failed to search ingredients: ${(err as Error).message}`);
    }
  });

// Get ingredients by category
ingredientsCommand
  .command("categories")
  .description("List ingredients organized by category")
  .action(async () => {
    const spinner = createSpinner("Fetching categories...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<Record<string, Ingredient[]>>>("/api/ingredients/categories");
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Ingredients by Category");

      for (const [category, ingredients] of Object.entries(response.data)) {
        console.log(chalk.cyan.bold(`\n${category}:`));
        printList(ingredients.map((i) => i.name), { indent: 2 });
      }

      console.log("");
      success(`Found ${Object.keys(response.data).length} categories`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch categories: ${(err as Error).message}`);
    }
  });

// Get ingredients by zone
ingredientsCommand
  .command("zones")
  .description("List ingredients organized by Zone Concept")
  .action(async () => {
    const spinner = createSpinner("Fetching zones...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<Record<string, Ingredient[]>>>("/api/ingredients/zones");
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Ingredients by Zone");

      const zoneNames: Record<string, string> = {
        spa: "SPA Zone (Anti-inflammatory)",
        zon: "ZON Zone (Anti-oxidant)",
        med: "MED Zone (Rejuvenation)",
      };

      for (const [zone, ingredients] of Object.entries(response.data)) {
        console.log(chalk.cyan.bold(`\n${zoneNames[zone] || zone}:`));
        printList(ingredients.map((i) => i.name), { indent: 2 });
      }

      console.log("");
      success("Zone ingredients retrieved");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch zones: ${(err as Error).message}`);
    }
  });

// Check ingredient compatibility
ingredientsCommand
  .command("compatibility <ingredient1> <ingredient2>")
  .description("Check compatibility between two ingredients")
  .action(async (ingredient1: string, ingredient2: string) => {
    const spinner = createSpinner("Checking compatibility...");
    spinner.start();

    try {
      const params = new URLSearchParams();
      params.append("ingredient1", ingredient1);
      params.append("ingredient2", ingredient2);

      const response = await apiRequest<ApiResponse<any>>(`/api/ingredients/compatibility?${params.toString()}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Ingredient Compatibility");

      const data = response.data;
      
      console.log(chalk.cyan.bold("Ingredients:"));
      console.log(`  1. ${highlight(data.ingredient1.name)}`);
      console.log(`  2. ${highlight(data.ingredient2.name)}`);
      console.log("");

      const compatible = data.compatibility.compatible;
      const status = compatible 
        ? chalk.green("✓ Compatible")
        : chalk.red("✗ Not Compatible");
      
      console.log(`Status: ${status}`);

      if (data.compatibility.notes) {
        console.log("");
        console.log(chalk.cyan.bold("Notes:"));
        console.log(chalk.gray(data.compatibility.notes));
      }

      success("Compatibility check complete");
    } catch (err) {
      spinner.stop();
      error(`Failed to check compatibility: ${(err as Error).message}`);
    }
  });

// Get ingredients for a concern
ingredientsCommand
  .command("for-concern <concern>")
  .description("Get recommended ingredients for a skin concern")
  .action(async (concern: string) => {
    const spinner = createSpinner("Fetching ingredients...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<Ingredient[]>>(`/api/ingredients/for-concern/${encodeURIComponent(concern)}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader(`Ingredients for ${concern}`);

      const table = createTable(["Name", "Category", "Concentration", "Benefits"]);
      
      for (const ing of response.data) {
        table.push([
          highlight(ing.name),
          ing.category,
          ing.concentration,
          ing.benefits.slice(0, 2).join(", "),
        ]);
      }

      printTable(table);
      success(`Found ${response.data.length} ingredients for ${concern}`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch ingredients: ${(err as Error).message}`);
    }
  });
