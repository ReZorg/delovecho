/**
 * Products Command
 */

import { Command } from "commander";
import chalk from "chalk";
import { 
  createSpinner, 
  createTable, 
  printTable, 
  success, 
  error, 
  outputJson,
  printHeader,
  printKeyValue,
  highlight,
  getOutputOptions,
  printList,
  zoneColor,
  scoreColor,
} from "../utils/output";
import { apiRequest } from "../utils/config";

interface Product {
  id: number;
  name: string;
  category: string;
  type: "professional" | "retail";
  description: string;
  keyIngredients?: string[];
  skinTypes?: string[];
  zoneAction?: string[];
}

interface ApiResponse<T> {
  success: boolean;
  data: T;
  meta?: Record<string, unknown>;
}

export const productsCommand = new Command("products")
  .description("Browse and search products")
  .option("--json", "Output as JSON");

// List products
productsCommand
  .command("list")
  .description("List all products")
  .option("-c, --category <category>", "Filter by category")
  .option("-t, --type <type>", "Filter by type (professional/retail)")
  .option("-z, --zone <zone>", "Filter by zone (spa/zon/med)")
  .option("-s, --skin-type <skinType>", "Filter by skin type")
  .option("-l, --limit <limit>", "Limit results", "20")
  .action(async (options) => {
    const spinner = createSpinner("Fetching products...");
    spinner.start();

    try {
      const params = new URLSearchParams();
      if (options.category) params.append("category", options.category);
      if (options.type) params.append("type", options.type);
      if (options.zone) params.append("zone", options.zone);
      if (options.skinType) params.append("skinType", options.skinType);
      if (options.limit) params.append("limit", options.limit);

      const endpoint = `/api/products?${params.toString()}`;
      const response = await apiRequest<ApiResponse<Product[]>>(endpoint);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Products");

      const table = createTable(["ID", "Name", "Category", "Type", "Zone"]);
      
      for (const product of response.data) {
        const zones = product.zoneAction?.map((z) => {
          if (z.toLowerCase().includes("inflammatory")) return zoneColor("spa");
          if (z.toLowerCase().includes("oxidant")) return zoneColor("zon");
          if (z.toLowerCase().includes("rejuvenation")) return zoneColor("med");
          return z;
        }).join(", ") || "-";

        table.push([
          String(product.id),
          highlight(product.name),
          product.category,
          product.type,
          zones,
        ]);
      }

      printTable(table);
      success(`Found ${response.data.length} products`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch products: ${(err as Error).message}`);
    }
  });

// Show product details
productsCommand
  .command("show <id>")
  .description("Show details of a specific product")
  .action(async (id: string) => {
    const spinner = createSpinner("Fetching product...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<Product & {
        zoneAnalysis?: any;
        primaryZone?: string;
      }>>(`/api/products/${id}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const product = response.data;

      printHeader(product.name);
      
      printKeyValue("ID", product.id);
      printKeyValue("Category", product.category);
      printKeyValue("Type", product.type);
      printKeyValue("Description", product.description);
      
      if (product.primaryZone) {
        console.log("");
        printKeyValue("Primary Zone", zoneColor(product.primaryZone));
      }

      if (product.keyIngredients && product.keyIngredients.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Key Ingredients:"));
        printList(product.keyIngredients);
      }

      if (product.skinTypes && product.skinTypes.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Suitable for:"));
        printList(product.skinTypes);
      }

      if (product.zoneAction && product.zoneAction.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Zone Actions:"));
        printList(product.zoneAction);
      }

      if (product.zoneAnalysis) {
        console.log("");
        console.log(chalk.cyan.bold("Zone Analysis:"));
        printKeyValue("  Anti-inflammatory (SPA)", scoreColor(product.zoneAnalysis.antiInflammatory) + "%");
        printKeyValue("  Anti-oxidant (ZON)", scoreColor(product.zoneAnalysis.antiOxidant) + "%");
        printKeyValue("  Rejuvenation (MED)", scoreColor(product.zoneAnalysis.rejuvenation) + "%");
      }

      success("Product details retrieved");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch product: ${(err as Error).message}`);
    }
  });

// Search products
productsCommand
  .command("search <query>")
  .description("Search products by name or description")
  .action(async (query: string) => {
    const spinner = createSpinner("Searching products...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<Product[]>>(`/api/products/search?q=${encodeURIComponent(query)}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader(`Search Results for "${query}"`);

      if (response.data.length === 0) {
        console.log(chalk.gray("No products found matching your query."));
        return;
      }

      const table = createTable(["ID", "Name", "Category", "Type"]);
      
      for (const product of response.data) {
        table.push([
          String(product.id),
          highlight(product.name),
          product.category,
          product.type,
        ]);
      }

      printTable(table);
      success(`Found ${response.data.length} matching products`);
    } catch (err) {
      spinner.stop();
      error(`Failed to search products: ${(err as Error).message}`);
    }
  });

// Get product categories
productsCommand
  .command("categories")
  .description("List all product categories")
  .action(async () => {
    const spinner = createSpinner("Fetching categories...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<string[]>>("/api/products/categories");
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Product Categories");
      printList(response.data);
      success(`Found ${response.data.length} categories`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch categories: ${(err as Error).message}`);
    }
  });

// Get product recommendations
productsCommand
  .command("recommend")
  .description("Get product recommendations")
  .requiredOption("-s, --skin-type <skinType>", "Your skin type")
  .option("-c, --concerns <concerns>", "Skin concerns (comma-separated)")
  .option("-g, --goals <goals>", "Skincare goals (comma-separated)")
  .action(async (options) => {
    const spinner = createSpinner("Getting recommendations...");
    spinner.start();

    try {
      const params = new URLSearchParams();
      params.append("skinType", options.skinType);
      if (options.concerns) params.append("concerns", options.concerns);
      if (options.goals) params.append("goals", options.goals);

      const response = await apiRequest<ApiResponse<any[]>>(`/api/products/recommendations?${params.toString()}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Product Recommendations");

      if (response.data.length === 0) {
        console.log(chalk.gray("No recommendations found for your profile."));
        return;
      }

      for (const rec of response.data.slice(0, 5)) {
        console.log(chalk.cyan.bold(`\n${rec.product.name}`));
        console.log(chalk.gray(`  Category: ${rec.product.category}`));
        console.log(chalk.gray(`  Match Score: ${scoreColor(rec.matchScore)}%`));
        if (rec.reasons && rec.reasons.length > 0) {
          console.log(chalk.gray("  Why: " + rec.reasons.join(", ")));
        }
      }

      console.log("");
      success(`Found ${response.data.length} recommendations`);
    } catch (err) {
      spinner.stop();
      error(`Failed to get recommendations: ${(err as Error).message}`);
    }
  });

// Get zone analysis for a product
productsCommand
  .command("zone-analysis <id>")
  .description("Get Zone Concept analysis for a product")
  .action(async (id: string) => {
    const spinner = createSpinner("Analyzing product...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>(`/api/products/${id}/zone-analysis`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const analysis = response.data;

      printHeader(`Zone Analysis: ${analysis.product.name}`);

      console.log(chalk.cyan.bold("Zone Scores:"));
      printKeyValue("  SPA (Anti-inflammatory)", scoreColor(analysis.zoneScores.antiInflammatory) + "%");
      printKeyValue("  ZON (Anti-oxidant)", scoreColor(analysis.zoneScores.antiOxidant) + "%");
      printKeyValue("  MED (Rejuvenation)", scoreColor(analysis.zoneScores.rejuvenation) + "%");

      console.log("");
      printKeyValue("Primary Zone", zoneColor(analysis.primaryZone));
      
      if (analysis.compatibility && analysis.compatibility.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Zone Compatibility:"));
        printList(analysis.compatibility.map((z: string) => zoneColor(z)));
      }

      if (analysis.recommendations && analysis.recommendations.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Recommendations:"));
        printList(analysis.recommendations);
      }

      success("Zone analysis complete");
    } catch (err) {
      spinner.stop();
      error(`Failed to analyze product: ${(err as Error).message}`);
    }
  });
