/**
 * Server Command - API Server Management
 */

import { Command } from "commander";
import chalk from "chalk";
import { spawn, type ChildProcess } from "child_process";
import { 
  createSpinner, 
  success, 
  error, 
  info,
  printHeader,
  printKeyValue,
  highlight,
} from "../utils/output";
import { loadConfig, updateConfig } from "../utils/config";

let serverProcess: ChildProcess | null = null;

export const serverCommand = new Command("server")
  .description("Manage the API server");

// Start server
serverCommand
  .command("start")
  .description("Start the API server")
  .option("-p, --port <port>", "Port number", "3000")
  .option("-h, --host <host>", "Host address", "0.0.0.0")
  .option("-d, --detach", "Run in background")
  .action(async (options) => {
    const config = loadConfig();
    
    printHeader("Starting RegimA API Server");
    
    printKeyValue("Host", options.host);
    printKeyValue("Port", options.port);
    printKeyValue("Mode", process.env.NODE_ENV || "development");
    
    console.log("");

    const env = {
      ...process.env,
      PORT: options.port,
      HOST: options.host,
    };

    if (options.detach) {
      // Run in background
      const spinner = createSpinner("Starting server in background...");
      spinner.start();

      try {
        serverProcess = spawn("node", ["./dist/bin/server.js"], {
          env,
          cwd: process.cwd(),
          detached: true,
          stdio: "ignore",
        });

        serverProcess.unref();

        // Update config with API URL
        updateConfig({ apiUrl: `http://${options.host === "0.0.0.0" ? "localhost" : options.host}:${options.port}` });

        spinner.stop();
        success(`Server started on http://${options.host}:${options.port}`);
        info(`PID: ${serverProcess.pid}`);
        console.log(chalk.gray("\nUse 'regima server stop' to stop the server"));
      } catch (err) {
        spinner.stop();
        error(`Failed to start server: ${(err as Error).message}`);
      }
    } else {
      // Run in foreground
      console.log(chalk.cyan("Starting server..."));
      console.log(chalk.gray("Press Ctrl+C to stop\n"));

      serverProcess = spawn("node", ["./dist/bin/server.js"], {
        env,
        cwd: process.cwd(),
        stdio: "inherit",
      });

      serverProcess.on("error", (err) => {
        error(`Server error: ${err.message}`);
      });

      serverProcess.on("exit", (code) => {
        if (code === 0) {
          info("Server stopped");
        } else {
          error(`Server exited with code ${code}`);
        }
      });

      // Handle Ctrl+C
      process.on("SIGINT", () => {
        console.log(chalk.yellow("\nShutting down server..."));
        serverProcess?.kill("SIGTERM");
        process.exit(0);
      });
    }
  });

// Stop server
serverCommand
  .command("stop")
  .description("Stop the running server")
  .action(async () => {
    const spinner = createSpinner("Stopping server...");
    spinner.start();

    try {
      // Try to find and kill the server process
      const { execSync } = await import("child_process");
      
      try {
        // Find process by port
        const result = execSync("lsof -ti:3000 2>/dev/null || true", { encoding: "utf-8" });
        const pids = result.trim().split("\n").filter(Boolean);
        
        if (pids.length > 0) {
          for (const pid of pids) {
            execSync(`kill ${pid} 2>/dev/null || true`);
          }
          spinner.stop();
          success("Server stopped");
        } else {
          spinner.stop();
          info("No server running on port 3000");
        }
      } catch {
        spinner.stop();
        info("No server running");
      }
    } catch (err) {
      spinner.stop();
      error(`Failed to stop server: ${(err as Error).message}`);
    }
  });

// Server status
serverCommand
  .command("status")
  .description("Check server status")
  .action(async () => {
    const config = loadConfig();
    const spinner = createSpinner("Checking server status...");
    spinner.start();

    try {
      const response = await fetch(`${config.apiUrl}/health`);
      
      if (response.ok) {
        const data = await response.json();
        spinner.stop();
        
        printHeader("Server Status");
        printKeyValue("Status", chalk.green("Running"));
        printKeyValue("URL", config.apiUrl);
        printKeyValue("Version", data.version || "unknown");
        printKeyValue("Uptime", data.uptime || "unknown");
        
        success("Server is healthy");
      } else {
        spinner.stop();
        error(`Server returned status ${response.status}`);
      }
    } catch (err) {
      spinner.stop();
      
      printHeader("Server Status");
      printKeyValue("Status", chalk.red("Not Running"));
      printKeyValue("URL", config.apiUrl);
      
      info("Server is not running. Use 'regima server start' to start it.");
    }
  });

// Server logs
serverCommand
  .command("logs")
  .description("View server logs")
  .option("-f, --follow", "Follow log output")
  .option("-n, --lines <lines>", "Number of lines to show", "50")
  .action(async (options) => {
    const logFile = "./logs/server.log";
    
    try {
      const { execSync, spawn } = await import("child_process");
      const fs = await import("fs");
      
      if (!fs.existsSync(logFile)) {
        info("No log file found. Server may not have been started yet.");
        return;
      }

      if (options.follow) {
        console.log(chalk.cyan("Following server logs... (Ctrl+C to stop)\n"));
        
        const tail = spawn("tail", ["-f", "-n", options.lines, logFile], {
          stdio: "inherit",
        });

        process.on("SIGINT", () => {
          tail.kill();
          process.exit(0);
        });
      } else {
        const output = execSync(`tail -n ${options.lines} ${logFile}`, { encoding: "utf-8" });
        console.log(output);
      }
    } catch (err) {
      error(`Failed to read logs: ${(err as Error).message}`);
    }
  });

// Server config
serverCommand
  .command("config")
  .description("View or update server configuration")
  .option("-s, --set <key=value>", "Set a configuration value")
  .option("-g, --get <key>", "Get a configuration value")
  .action(async (options) => {
    const config = loadConfig();

    if (options.set) {
      const [key, value] = options.set.split("=");
      if (!key || value === undefined) {
        error("Invalid format. Use: --set key=value");
        return;
      }
      
      updateConfig({ [key]: value } as any);
      success(`Set ${key} = ${value}`);
    } else if (options.get) {
      const value = (config as any)[options.get];
      if (value !== undefined) {
        console.log(value);
      } else {
        error(`Unknown configuration key: ${options.get}`);
      }
    } else {
      printHeader("Server Configuration");
      
      for (const [key, value] of Object.entries(config)) {
        printKeyValue(key, String(value));
      }
    }
  });
