/**
 * Agent Command - AI Consultation Interface
 */

import { Command } from "commander";
import chalk from "chalk";
import inquirer from "inquirer";
import { 
  createSpinner, 
  createTable, 
  printTable, 
  success, 
  error, 
  outputJson,
  printHeader,
  printKeyValue,
  highlight,
  getOutputOptions,
  printList,
  zoneColor,
  scoreColor,
  printBox,
} from "../utils/output";
import { apiRequest } from "../utils/config";

interface ApiResponse<T> {
  success: boolean;
  data: T;
}

export const agentCommand = new Command("agent")
  .description("AI-powered skincare consultation")
  .option("--json", "Output as JSON");

// Interactive consultation
agentCommand
  .command("consult")
  .description("Start an interactive AI consultation")
  .action(async () => {
    printHeader("RegimA AI Consultation");
    console.log(chalk.gray("Answer a few questions to receive personalized skincare recommendations.\n"));

    try {
      // Get skin types info
      const skinTypesResponse = await apiRequest<ApiResponse<any[]>>("/api/agent/skin-types");
      const skinTypes = skinTypesResponse.data.map((t) => t.type);

      // Get concerns info
      const concernsResponse = await apiRequest<ApiResponse<any[]>>("/api/agent/concerns");
      const concerns = concernsResponse.data.map((c) => c.concern);

      // Interactive questions
      const answers = await inquirer.prompt([
        {
          type: "list",
          name: "skinType",
          message: "What is your skin type?",
          choices: skinTypes,
        },
        {
          type: "checkbox",
          name: "skinConcerns",
          message: "What are your main skin concerns? (Select all that apply)",
          choices: concerns,
          validate: (input) => input.length > 0 || "Please select at least one concern",
        },
        {
          type: "checkbox",
          name: "goals",
          message: "What are your skincare goals?",
          choices: [
            "Maintain healthy skin",
            "Anti-aging",
            "Clear skin",
            "Brighten complexion",
            "Hydration",
            "Reduce sensitivity",
          ],
        },
        {
          type: "list",
          name: "budget",
          message: "What is your budget preference?",
          choices: ["budget", "moderate", "premium"],
        },
      ]);

      const spinner = createSpinner("Analyzing your skin profile...");
      spinner.start();

      const response = await apiRequest<ApiResponse<any>>("/api/agent/consultation", {
        method: "POST",
        body: JSON.stringify({
          skinType: answers.skinType,
          skinConcerns: answers.skinConcerns,
          goals: answers.goals,
          budget: answers.budget,
        }),
      });

      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const result = response.data;

      // Display summary
      printBox(result.summary, { title: "Consultation Summary", borderColor: "cyan" });

      // Zone recommendations
      console.log(chalk.cyan.bold("\nZone Recommendations:"));
      const zoneTable = createTable(["Zone", "Score", "Priority", "Focus"]);
      
      for (const [zone, data] of Object.entries(result.zoneRecommendations) as [string, any][]) {
        zoneTable.push([
          zoneColor(zone),
          scoreColor(data.score) + "%",
          data.priority,
          data.focus.slice(0, 2).join(", ") || "-",
        ]);
      }
      printTable(zoneTable);

      // Product recommendations
      if (result.productRecommendations && result.productRecommendations.length > 0) {
        console.log(chalk.cyan.bold("\nRecommended Products:"));
        for (const rec of result.productRecommendations.slice(0, 3)) {
          console.log(`\n  ${highlight(rec.product.name)}`);
          console.log(chalk.gray(`    Category: ${rec.product.category}`));
          console.log(chalk.gray(`    Match: ${scoreColor(rec.matchScore)}%`));
          console.log(chalk.gray(`    Usage: ${rec.usage}`));
        }
      }

      // Routine suggestion
      if (result.routineSuggestion) {
        console.log(chalk.cyan.bold("\nSuggested Routine:"));
        console.log(chalk.yellow("\n  Morning:"));
        printList(result.routineSuggestion.morning, { indent: 4 });
        console.log(chalk.yellow("\n  Evening:"));
        printList(result.routineSuggestion.evening, { indent: 4 });
      }

      // Lifestyle advice
      if (result.lifestyleAdvice && result.lifestyleAdvice.length > 0) {
        console.log(chalk.cyan.bold("\nLifestyle Tips:"));
        printList(result.lifestyleAdvice, { indent: 2 });
      }

      console.log("");
      success("Consultation complete!");
    } catch (err) {
      error(`Consultation failed: ${(err as Error).message}`);
    }
  });

// Generate routine
agentCommand
  .command("routine")
  .description("Generate a personalized skincare routine")
  .requiredOption("-s, --skin-type <skinType>", "Your skin type")
  .requiredOption("-c, --concerns <concerns>", "Skin concerns (comma-separated)")
  .option("-t, --type <type>", "Routine type (minimal/standard/comprehensive)", "standard")
  .action(async (options) => {
    const spinner = createSpinner("Generating routine...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>("/api/agent/routine", {
        method: "POST",
        body: JSON.stringify({
          skinType: options.skinType,
          skinConcerns: options.concerns.split(",").map((c: string) => c.trim()),
          routineType: options.type,
          includeWeeklyTreatments: true,
        }),
      });

      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const routine = response.data;

      printHeader(`${routine.routineType.charAt(0).toUpperCase() + routine.routineType.slice(1)} Skincare Routine`);

      // Morning routine
      console.log(chalk.yellow.bold("\n☀️  Morning Routine:"));
      const morningTable = createTable(["Step", "Category", "Purpose", "Instructions"]);
      for (const step of routine.morning) {
        morningTable.push([
          String(step.step),
          step.category,
          step.purpose.substring(0, 30) + "...",
          step.instructions.substring(0, 30) + "...",
        ]);
      }
      printTable(morningTable);

      // Evening routine
      console.log(chalk.blue.bold("\n🌙  Evening Routine:"));
      const eveningTable = createTable(["Step", "Category", "Purpose", "Instructions"]);
      for (const step of routine.evening) {
        eveningTable.push([
          String(step.step),
          step.category,
          step.purpose.substring(0, 30) + "...",
          step.instructions.substring(0, 30) + "...",
        ]);
      }
      printTable(eveningTable);

      // Weekly treatments
      if (routine.weekly && routine.weekly.length > 0) {
        console.log(chalk.magenta.bold("\n📅  Weekly Treatments:"));
        for (const treatment of routine.weekly) {
          console.log(`\n  ${highlight(treatment.treatment)}`);
          console.log(chalk.gray(`    Frequency: ${treatment.frequency}`));
          console.log(chalk.gray(`    Purpose: ${treatment.purpose}`));
        }
      }

      // Tips
      if (routine.tips && routine.tips.length > 0) {
        console.log(chalk.cyan.bold("\n💡  Tips:"));
        printList(routine.tips, { indent: 2 });
      }

      console.log("");
      success("Routine generated!");
    } catch (err) {
      spinner.stop();
      error(`Failed to generate routine: ${(err as Error).message}`);
    }
  });

// Zone analysis
agentCommand
  .command("zone-analysis")
  .description("Analyze your skin profile using the Zone Concept")
  .requiredOption("-s, --skin-type <skinType>", "Your skin type")
  .requiredOption("-c, --concerns <concerns>", "Skin concerns (comma-separated)")
  .action(async (options) => {
    const spinner = createSpinner("Analyzing zones...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>("/api/agent/zone-analysis", {
        method: "POST",
        body: JSON.stringify({
          skinType: options.skinType,
          skinConcerns: options.concerns.split(",").map((c: string) => c.trim()),
        }),
      });

      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const analysis = response.data;

      printHeader("Zone Concept Analysis");

      printKeyValue("Overall Balance", scoreColor(analysis.overallBalance) + "%");
      console.log("");

      // Zone details
      for (const [zone, data] of Object.entries(analysis.zones) as [string, any][]) {
        console.log(chalk.cyan.bold(`${zoneColor(zone)} - ${data.name}:`));
        console.log(`  Score: ${scoreColor(data.score)}%`);
        console.log(`  Status: ${data.status}`);
        if (data.recommendations.length > 0) {
          console.log("  Recommendations:");
          printList(data.recommendations, { indent: 4 });
        }
        console.log("");
      }

      // Priority actions
      if (analysis.priorityActions && analysis.priorityActions.length > 0) {
        console.log(chalk.cyan.bold("Priority Actions:"));
        printList(analysis.priorityActions, { indent: 2 });
      }

      // Suggested adjustments
      if (analysis.suggestedAdjustments && analysis.suggestedAdjustments.length > 0) {
        console.log(chalk.cyan.bold("\nSuggested Adjustments:"));
        printList(analysis.suggestedAdjustments, { indent: 2 });
      }

      console.log("");
      success("Zone analysis complete!");
    } catch (err) {
      spinner.stop();
      error(`Failed to analyze zones: ${(err as Error).message}`);
    }
  });

// Zone info
agentCommand
  .command("zone-info")
  .description("Learn about the Zone Concept")
  .action(async () => {
    const spinner = createSpinner("Fetching zone information...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>("/api/agent/zone-info");
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const info = response.data;

      printHeader("The Zone Concept");

      printBox(info.philosophy, { title: "Philosophy", borderColor: "cyan" });

      for (const zone of info.zones) {
        console.log(chalk.cyan.bold(`\n${zoneColor(zone.id)} - ${zone.name}:`));
        console.log(chalk.gray(zone.description));
        console.log(chalk.yellow("\n  Key Ingredients:"));
        printList(zone.keyIngredients, { indent: 4 });
        console.log(chalk.yellow("\n  Benefits:"));
        printList(zone.benefits, { indent: 4 });
      }

      console.log("");
      success("Zone information retrieved!");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch zone info: ${(err as Error).message}`);
    }
  });

// Skin types info
agentCommand
  .command("skin-types")
  .description("Learn about different skin types")
  .action(async () => {
    const spinner = createSpinner("Fetching skin type information...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any[]>>("/api/agent/skin-types");
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Skin Types");

      for (const skinType of response.data) {
        console.log(chalk.cyan.bold(`\n${skinType.type}:`));
        
        console.log(chalk.yellow("  Characteristics:"));
        printList(skinType.characteristics, { indent: 4 });
        
        console.log(chalk.yellow("\n  Common Concerns:"));
        printList(skinType.commonConcerns, { indent: 4 });
        
        console.log(chalk.green("\n  Recommended Ingredients:"));
        printList(skinType.recommendedIngredients, { indent: 4 });
        
        console.log(chalk.red("\n  Ingredients to Avoid:"));
        printList(skinType.ingredientsToAvoid, { indent: 4 });
      }

      console.log("");
      success("Skin type information retrieved!");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch skin types: ${(err as Error).message}`);
    }
  });

// Concerns info
agentCommand
  .command("concerns")
  .description("Learn about common skin concerns")
  .action(async () => {
    const spinner = createSpinner("Fetching skin concerns...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any[]>>("/api/agent/concerns");
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Skin Concerns");

      const table = createTable(["Concern", "Primary Zone", "Key Ingredients"]);
      
      for (const concern of response.data) {
        table.push([
          highlight(concern.concern),
          zoneColor(concern.primaryZone),
          concern.keyIngredients.slice(0, 3).join(", "),
        ]);
      }

      printTable(table);

      console.log("");
      for (const concern of response.data) {
        console.log(chalk.cyan.bold(`\n${concern.concern}:`));
        console.log(chalk.gray(concern.description));
      }

      console.log("");
      success("Skin concerns retrieved!");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch concerns: ${(err as Error).message}`);
    }
  });
