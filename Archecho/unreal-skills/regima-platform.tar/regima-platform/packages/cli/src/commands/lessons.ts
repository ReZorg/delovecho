/**
 * Lessons Command
 */

import { Command } from "commander";
import chalk from "chalk";
import { 
  createSpinner, 
  createTable, 
  printTable, 
  success, 
  error, 
  outputJson,
  printHeader,
  printKeyValue,
  highlight,
  getOutputOptions,
  printList,
} from "../utils/output";
import { apiRequest } from "../utils/config";

interface Lesson {
  id: number;
  moduleId: number;
  title: string;
  description: string;
  content: string;
  videoUrl?: string;
  order: number;
}

interface ApiResponse<T> {
  success: boolean;
  data: T;
  meta?: Record<string, unknown>;
}

export const lessonsCommand = new Command("lessons")
  .description("Manage training lessons")
  .option("--json", "Output as JSON");

// List lessons
lessonsCommand
  .command("list")
  .description("List all lessons")
  .option("-m, --module <id>", "Filter by module ID")
  .action(async (options) => {
    const spinner = createSpinner("Fetching lessons...");
    spinner.start();

    try {
      const endpoint = options.module 
        ? `/api/lessons?moduleId=${options.module}`
        : "/api/lessons";
      
      const response = await apiRequest<ApiResponse<Lesson[]>>(endpoint);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Training Lessons");

      const table = createTable(["ID", "Module", "Title", "Description"]);
      
      for (const lesson of response.data) {
        table.push([
          String(lesson.id),
          String(lesson.moduleId),
          highlight(lesson.title),
          lesson.description.substring(0, 40) + "...",
        ]);
      }

      printTable(table);
      success(`Found ${response.data.length} lessons`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch lessons: ${(err as Error).message}`);
    }
  });

// Show lesson details
lessonsCommand
  .command("show <id>")
  .description("Show details of a specific lesson")
  .option("-c, --content", "Show full content")
  .action(async (id: string, options) => {
    const spinner = createSpinner("Fetching lesson...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<Lesson & { 
        steps?: any[]; 
        resources?: any[]; 
        quiz?: any;
      }>>(`/api/lessons/${id}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const lesson = response.data;

      printHeader(`Lesson: ${lesson.title}`);
      
      printKeyValue("ID", lesson.id);
      printKeyValue("Module ID", lesson.moduleId);
      printKeyValue("Title", lesson.title);
      printKeyValue("Description", lesson.description);
      printKeyValue("Order", lesson.order);
      
      if (lesson.videoUrl) {
        printKeyValue("Video URL", lesson.videoUrl);
      }

      if (options.content) {
        console.log("");
        console.log(chalk.cyan.bold("Content:"));
        console.log(chalk.white(lesson.content));
      }

      if (lesson.steps && lesson.steps.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Steps:"));
        printList(lesson.steps.map((s: any) => `${s.title}: ${s.description}`), { numbered: true });
      }

      if (lesson.resources && lesson.resources.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Resources:"));
        printList(lesson.resources.map((r: any) => r.title));
      }

      if (lesson.quiz) {
        console.log("");
        console.log(chalk.cyan.bold("Quiz:"));
        console.log(`  ${lesson.quiz.questions.length} questions available`);
      }

      success("Lesson details retrieved");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch lesson: ${(err as Error).message}`);
    }
  });

// Get lesson steps
lessonsCommand
  .command("steps <id>")
  .description("List steps in a lesson")
  .action(async (id: string) => {
    const spinner = createSpinner("Fetching steps...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any[]>>(`/api/lessons/${id}/steps`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader(`Steps in Lesson ${id}`);

      if (response.data.length === 0) {
        console.log(chalk.gray("No steps found in this lesson."));
        return;
      }

      const table = createTable(["#", "Title", "Description"]);
      
      for (const step of response.data) {
        table.push([
          String(step.order),
          step.title,
          step.description,
        ]);
      }

      printTable(table);
      success(`Found ${response.data.length} steps`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch steps: ${(err as Error).message}`);
    }
  });

// Get lesson quiz
lessonsCommand
  .command("quiz <id>")
  .description("Show quiz for a lesson")
  .option("-a, --answers", "Show correct answers")
  .action(async (id: string, options) => {
    const spinner = createSpinner("Fetching quiz...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any>>(`/api/lessons/${id}/quiz`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      if (!response.data) {
        console.log(chalk.gray("No quiz available for this lesson."));
        return;
      }

      printHeader(`Quiz for Lesson ${id}`);

      const quiz = response.data;
      
      for (let i = 0; i < quiz.questions.length; i++) {
        const q = quiz.questions[i];
        console.log(chalk.cyan.bold(`\nQuestion ${i + 1}: ${q.question}`));
        
        for (const opt of q.options) {
          const isCorrect = options.answers && opt.id === q.correctOptionId;
          const prefix = isCorrect ? chalk.green("✓") : " ";
          console.log(`  ${prefix} ${opt.id}) ${opt.text}`);
        }
      }

      console.log("");
      success(`Quiz has ${quiz.questions.length} questions`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch quiz: ${(err as Error).message}`);
    }
  });
