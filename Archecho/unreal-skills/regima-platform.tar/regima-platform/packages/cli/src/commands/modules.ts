/**
 * Modules Command
 */

import { Command } from "commander";
import chalk from "chalk";
import { 
  createSpinner, 
  createTable, 
  printTable, 
  success, 
  error, 
  outputJson,
  printHeader,
  printKeyValue,
  formatDuration,
  highlight,
  getOutputOptions,
} from "../utils/output";
import { apiRequest, loadConfig } from "../utils/config";

interface Module {
  id: number;
  title: string;
  description: string;
  estimatedTime: string;
  order: number;
}

interface ApiResponse<T> {
  success: boolean;
  data: T;
  meta?: Record<string, unknown>;
}

export const modulesCommand = new Command("modules")
  .description("Manage training modules")
  .option("--json", "Output as JSON");

// List modules
modulesCommand
  .command("list")
  .description("List all training modules")
  .action(async () => {
    const spinner = createSpinner("Fetching modules...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<Module[]>>("/api/modules");
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader("Training Modules");

      const table = createTable(["#", "Title", "Description", "Duration"]);
      
      for (const module of response.data) {
        table.push([
          chalk.cyan(String(module.order)),
          highlight(module.title),
          module.description.substring(0, 50) + (module.description.length > 50 ? "..." : ""),
          module.estimatedTime,
        ]);
      }

      printTable(table);
      success(`Found ${response.data.length} modules`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch modules: ${(err as Error).message}`);
    }
  });

// Show module details
modulesCommand
  .command("show <id>")
  .description("Show details of a specific module")
  .action(async (id: string) => {
    const spinner = createSpinner("Fetching module...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<Module & { lessons: any[] }>>(`/api/modules/${id}`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      const module = response.data;

      printHeader(`Module ${module.order}: ${module.title}`);
      
      printKeyValue("ID", module.id);
      printKeyValue("Title", module.title);
      printKeyValue("Description", module.description);
      printKeyValue("Estimated Time", module.estimatedTime);
      printKeyValue("Order", module.order);

      if (module.lessons && module.lessons.length > 0) {
        console.log("");
        console.log(chalk.cyan.bold("Lessons:"));
        
        const table = createTable(["#", "Title", "Description"]);
        for (const lesson of module.lessons) {
          table.push([
            String(lesson.order),
            lesson.title,
            lesson.description.substring(0, 40) + "...",
          ]);
        }
        printTable(table);
      }

      success("Module details retrieved");
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch module: ${(err as Error).message}`);
    }
  });

// Get module lessons
modulesCommand
  .command("lessons <id>")
  .description("List lessons in a module")
  .action(async (id: string) => {
    const spinner = createSpinner("Fetching lessons...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<any[]>>(`/api/modules/${id}/lessons`);
      spinner.stop();

      if (getOutputOptions().json) {
        outputJson(response.data);
        return;
      }

      printHeader(`Lessons in Module ${id}`);

      if (response.data.length === 0) {
        console.log(chalk.gray("No lessons found in this module."));
        return;
      }

      const table = createTable(["#", "Title", "Description"]);
      
      for (const lesson of response.data) {
        table.push([
          String(lesson.order),
          lesson.title,
          lesson.description.substring(0, 50) + "...",
        ]);
      }

      printTable(table);
      success(`Found ${response.data.length} lessons`);
    } catch (err) {
      spinner.stop();
      error(`Failed to fetch lessons: ${(err as Error).message}`);
    }
  });

// Search modules
modulesCommand
  .command("search <query>")
  .description("Search modules by title or description")
  .action(async (query: string) => {
    const spinner = createSpinner("Searching modules...");
    spinner.start();

    try {
      const response = await apiRequest<ApiResponse<Module[]>>("/api/modules");
      spinner.stop();

      const queryLower = query.toLowerCase();
      const results = response.data.filter(
        (m) =>
          m.title.toLowerCase().includes(queryLower) ||
          m.description.toLowerCase().includes(queryLower)
      );

      if (getOutputOptions().json) {
        outputJson(results);
        return;
      }

      printHeader(`Search Results for "${query}"`);

      if (results.length === 0) {
        console.log(chalk.gray("No modules found matching your query."));
        return;
      }

      const table = createTable(["#", "Title", "Description"]);
      
      for (const module of results) {
        table.push([
          String(module.order),
          module.title,
          module.description.substring(0, 50) + "...",
        ]);
      }

      printTable(table);
      success(`Found ${results.length} matching modules`);
    } catch (err) {
      spinner.stop();
      error(`Failed to search modules: ${(err as Error).message}`);
    }
  });
