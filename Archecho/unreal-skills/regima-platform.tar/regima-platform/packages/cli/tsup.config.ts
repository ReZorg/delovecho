import { defineConfig } from "tsup";

export default defineConfig({
  entry: ["src/index.ts", "src/bin/regima.ts"],
  format: ["esm"],
  dts: false,
  splitting: false,
  sourcemap: true,
  clean: true,
  treeshake: true,
  shims: true,
  external: [
    "@regima/core",
    "commander",
    "chalk",
    "ora",
    "inquirer",
    "cli-table3",
    "boxen",
    "figures",
    "dotenv",
  ],
  outDir: "dist",
});
