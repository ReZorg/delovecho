/**
 * API Server Configuration
 */

import { config as dotenvConfig } from "dotenv";

// Load environment variables
dotenvConfig();

export interface Config {
  nodeEnv: string;
  port: number;
  host: string;
  version: string;
  sessionSecret: string;
  corsOrigins: string[];
  databaseUrl: string | undefined;
  logLevel: string;
}

function getEnvVar(key: string, defaultValue?: string): string {
  const value = process.env[key];
  if (value === undefined) {
    if (defaultValue !== undefined) {
      return defaultValue;
    }
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value;
}

function getEnvVarOptional(key: string): string | undefined {
  return process.env[key];
}

function getEnvVarNumber(key: string, defaultValue: number): number {
  const value = process.env[key];
  if (value === undefined) {
    return defaultValue;
  }
  const parsed = parseInt(value, 10);
  if (isNaN(parsed)) {
    throw new Error(`Environment variable ${key} must be a number`);
  }
  return parsed;
}

function getCorsOrigins(): string[] {
  const origins = process.env.CORS_ORIGINS;
  if (!origins) {
    return ["http://localhost:3000", "http://localhost:5173", "http://localhost:5000"];
  }
  return origins.split(",").map((origin) => origin.trim());
}

export const config: Config = {
  nodeEnv: getEnvVar("NODE_ENV", "development"),
  port: getEnvVarNumber("PORT", 3000),
  host: getEnvVar("HOST", "0.0.0.0"),
  version: getEnvVar("API_VERSION", "1.0.0"),
  sessionSecret: getEnvVar("SESSION_SECRET", "regima-secret-key-change-in-production"),
  corsOrigins: getCorsOrigins(),
  databaseUrl: getEnvVarOptional("DATABASE_URL"),
  logLevel: getEnvVar("LOG_LEVEL", "info"),
};

// Validate configuration
export function validateConfig(): void {
  if (config.nodeEnv === "production") {
    if (config.sessionSecret === "regima-secret-key-change-in-production") {
      throw new Error("SESSION_SECRET must be set in production");
    }
    if (!config.databaseUrl) {
      console.warn("Warning: DATABASE_URL not set, using in-memory storage");
    }
  }
}
