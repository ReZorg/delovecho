/**
 * @regima/api
 * 
 * RESTful API server for the RegimA Training Platform.
 * Provides endpoints for training modules, lessons, products,
 * ingredients, and AI agent interactions.
 */

import express, { type Express, type Request, type Response, type NextFunction } from "express";
import { createServer, type Server } from "http";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import compression from "compression";
import rateLimit from "express-rate-limit";
import session from "express-session";
import MemoryStore from "memorystore";
import { WebSocketServer } from "ws";
import { config } from "./config";
import { errorHandler, notFoundHandler } from "./middleware/error-handler";
import { registerRoutes } from "./routes";
import { logger } from "./services/logger";

export interface ApiServerOptions {
  port?: number;
  host?: string;
  corsOrigins?: string[];
  enableRateLimit?: boolean;
  enableWebSocket?: boolean;
}

export class ApiServer {
  private app: Express;
  private server: Server | null = null;
  private wss: WebSocketServer | null = null;
  private options: Required<ApiServerOptions>;

  constructor(options: ApiServerOptions = {}) {
    this.options = {
      port: options.port ?? config.port,
      host: options.host ?? config.host,
      corsOrigins: options.corsOrigins ?? config.corsOrigins,
      enableRateLimit: options.enableRateLimit ?? true,
      enableWebSocket: options.enableWebSocket ?? true,
    };

    this.app = express();
    this.setupMiddleware();
  }

  private setupMiddleware(): void {
    // Security headers
    this.app.use(helmet({
      contentSecurityPolicy: false, // Disable for API
    }));

    // CORS
    this.app.use(cors({
      origin: this.options.corsOrigins,
      credentials: true,
      methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
      allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"],
    }));

    // Compression
    this.app.use(compression());

    // Request logging
    if (config.nodeEnv !== "test") {
      this.app.use(morgan(config.nodeEnv === "production" ? "combined" : "dev"));
    }

    // Body parsing
    this.app.use(express.json({ limit: "10mb" }));
    this.app.use(express.urlencoded({ extended: true, limit: "10mb" }));

    // Rate limiting
    if (this.options.enableRateLimit) {
      const limiter = rateLimit({
        windowMs: 15 * 60 * 1000, // 15 minutes
        max: 100, // Limit each IP to 100 requests per windowMs
        message: { error: "Too many requests, please try again later." },
        standardHeaders: true,
        legacyHeaders: false,
      });
      this.app.use("/api/", limiter);
    }

    // Session management
    const MemoryStoreSession = MemoryStore(session);
    this.app.use(session({
      secret: config.sessionSecret,
      resave: false,
      saveUninitialized: false,
      store: new MemoryStoreSession({
        checkPeriod: 86400000, // 24 hours
      }),
      cookie: {
        secure: config.nodeEnv === "production",
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      },
    }));

    // Health check endpoint
    this.app.get("/health", (req: Request, res: Response) => {
      res.json({
        status: "healthy",
        timestamp: new Date().toISOString(),
        version: config.version,
        environment: config.nodeEnv,
      });
    });

    // API info endpoint
    this.app.get("/api", (req: Request, res: Response) => {
      res.json({
        name: "RegimA API",
        version: config.version,
        description: "RESTful API for RegimA Training Platform",
        documentation: "/api/docs",
        endpoints: {
          modules: "/api/modules",
          lessons: "/api/lessons",
          products: "/api/products",
          ingredients: "/api/ingredients",
          agent: "/api/agent",
          workflows: "/api/workflows",
          progress: "/api/progress",
        },
      });
    });
  }

  async start(): Promise<Server> {
    // Register API routes
    await registerRoutes(this.app);

    // Error handlers (must be last)
    this.app.use(notFoundHandler);
    this.app.use(errorHandler);

    // Create HTTP server
    this.server = createServer(this.app);

    // Setup WebSocket if enabled
    if (this.options.enableWebSocket) {
      this.setupWebSocket();
    }

    return new Promise((resolve, reject) => {
      this.server!.listen(this.options.port, this.options.host, () => {
        logger.info(`🚀 RegimA API server running at http://${this.options.host}:${this.options.port}`);
        logger.info(`📚 API documentation at http://${this.options.host}:${this.options.port}/api`);
        resolve(this.server!);
      });

      this.server!.on("error", (error: NodeJS.ErrnoException) => {
        if (error.code === "EADDRINUSE") {
          logger.error(`Port ${this.options.port} is already in use`);
        }
        reject(error);
      });
    });
  }

  private setupWebSocket(): void {
    if (!this.server) return;

    this.wss = new WebSocketServer({ server: this.server, path: "/ws" });

    this.wss.on("connection", (ws, req) => {
      logger.info(`WebSocket client connected from ${req.socket.remoteAddress}`);

      ws.on("message", (message) => {
        try {
          const data = JSON.parse(message.toString());
          this.handleWebSocketMessage(ws, data);
        } catch (error) {
          ws.send(JSON.stringify({ error: "Invalid message format" }));
        }
      });

      ws.on("close", () => {
        logger.info("WebSocket client disconnected");
      });

      ws.on("error", (error) => {
        logger.error("WebSocket error:", error);
      });

      // Send welcome message
      ws.send(JSON.stringify({
        type: "connected",
        message: "Connected to RegimA WebSocket server",
        timestamp: new Date().toISOString(),
      }));
    });

    logger.info("WebSocket server initialized at /ws");
  }

  private handleWebSocketMessage(ws: any, data: any): void {
    switch (data.type) {
      case "ping":
        ws.send(JSON.stringify({ type: "pong", timestamp: new Date().toISOString() }));
        break;
      case "subscribe":
        // Handle subscription to updates
        ws.send(JSON.stringify({ type: "subscribed", channel: data.channel }));
        break;
      default:
        ws.send(JSON.stringify({ type: "unknown", message: "Unknown message type" }));
    }
  }

  broadcast(message: any): void {
    if (!this.wss) return;

    const payload = JSON.stringify(message);
    this.wss.clients.forEach((client) => {
      if (client.readyState === 1) { // WebSocket.OPEN
        client.send(payload);
      }
    });
  }

  async stop(): Promise<void> {
    return new Promise((resolve) => {
      if (this.wss) {
        this.wss.close();
      }
      if (this.server) {
        this.server.close(() => {
          logger.info("Server stopped");
          resolve();
        });
      } else {
        resolve();
      }
    });
  }

  getApp(): Express {
    return this.app;
  }

  getServer(): Server | null {
    return this.server;
  }
}

// Export for programmatic use
export { config } from "./config";
export { logger } from "./services/logger";
export * from "./routes";

// Default export
export default ApiServer;
