/**
 * Workflows API Routes
 * Treatment protocol and workflow management
 */

import { Router, type Request, type Response } from "express";
import { z } from "zod";
import { asyncHandler, NotFoundError, BadRequestError } from "../middleware/error-handler";
import { WorkflowEngine, type WorkflowType } from "@regima/core";

const router = Router();
const workflowEngine = new WorkflowEngine();

// Schemas
const createWorkflowSchema = z.object({
  userId: z.number().int().positive(),
  protocolType: z.enum(["daily_routine", "weekly_treatment", "monthly_protocol", "acne_program", "anti_aging_program"]),
  duration: z.number().int().positive().optional(),
  skinProfile: z.object({
    skinType: z.string(),
    skinConcerns: z.array(z.string()),
    goals: z.array(z.string()).optional(),
  }).optional(),
});

const updateProgressSchema = z.object({
  stepNotes: z.string().optional(),
  skinResponse: z.object({
    reaction: z.enum(["positive", "neutral", "negative"]).optional(),
    improvements: z.array(z.string()).optional(),
    concerns: z.array(z.string()).optional(),
  }).optional(),
  productFeedback: z.array(z.object({
    productName: z.string(),
    rating: z.number().min(1).max(5),
    notes: z.string().optional(),
  })).optional(),
});

const adjustWorkflowSchema = z.object({
  reason: z.string(),
  feedback: z.any(),
});

/**
 * GET /api/workflows
 * List workflows for a user
 */
router.get("/", asyncHandler(async (req: Request, res: Response) => {
  const userId = parseInt(req.query.userId as string, 10);
  
  if (isNaN(userId)) {
    throw new BadRequestError("userId query parameter is required");
  }
  
  const workflows = await workflowEngine.getActiveWorkflows(userId);
  
  res.json({
    success: true,
    data: workflows,
    meta: {
      userId,
      total: workflows.length,
    },
  });
}));

/**
 * GET /api/workflows/types
 * Get available workflow types
 */
router.get("/types", asyncHandler(async (req: Request, res: Response) => {
  const types = [
    {
      id: "daily_routine",
      name: "Daily Skincare Routine",
      description: "Comprehensive daily AM/PM skincare routine optimized for your skin type",
      defaultDuration: 30,
    },
    {
      id: "weekly_treatment",
      name: "Weekly Treatment Protocol",
      description: "Intensive weekly treatments to address specific skin concerns",
      defaultDuration: 8,
    },
    {
      id: "monthly_protocol",
      name: "Monthly Renewal Protocol",
      description: "Long-term protocol for sustained skin transformation",
      defaultDuration: 30,
    },
    {
      id: "acne_program",
      name: "Acne Management Program",
      description: "Targeted protocol for acne-prone skin with progressive treatment intensity",
      defaultDuration: 90,
    },
    {
      id: "anti_aging_program",
      name: "Anti-Aging Program",
      description: "Comprehensive anti-aging protocol focusing on prevention and correction",
      defaultDuration: 120,
    },
  ];
  
  res.json({
    success: true,
    data: types,
  });
}));

/**
 * POST /api/workflows
 * Create a new workflow
 */
router.post("/", asyncHandler(async (req: Request, res: Response) => {
  const data = createWorkflowSchema.parse(req.body);
  
  const workflow = await workflowEngine.createWorkflow(
    data.userId,
    data.protocolType as WorkflowType,
    data.duration,
    data.skinProfile
  );
  
  res.status(201).json({
    success: true,
    data: workflow,
  });
}));

/**
 * GET /api/workflows/:id
 * Get a specific workflow
 */
router.get("/:id", asyncHandler(async (req: Request, res: Response) => {
  const workflowId = req.params.id;
  const workflow = workflowEngine.getWorkflow(workflowId);
  
  if (!workflow) {
    throw new NotFoundError(`Workflow ${workflowId} not found`);
  }
  
  res.json({
    success: true,
    data: workflow,
  });
}));

/**
 * GET /api/workflows/:id/next-steps
 * Get next steps in a workflow
 */
router.get("/:id/next-steps", asyncHandler(async (req: Request, res: Response) => {
  const workflowId = req.params.id;
  const count = parseInt(req.query.count as string, 10) || 5;
  
  const steps = await workflowEngine.getNextSteps(workflowId, count);
  
  res.json({
    success: true,
    data: steps,
    meta: {
      workflowId,
      count: steps.length,
    },
  });
}));

/**
 * POST /api/workflows/:id/execute
 * Execute the current step in a workflow
 */
router.post("/:id/execute", asyncHandler(async (req: Request, res: Response) => {
  const workflowId = req.params.id;
  const step = await workflowEngine.executeStep(workflowId);
  
  if (!step) {
    throw new NotFoundError(`No active step found for workflow ${workflowId}`);
  }
  
  res.json({
    success: true,
    data: step,
    message: "Step executed successfully",
  });
}));

/**
 * POST /api/workflows/:id/progress
 * Update workflow progress with feedback
 */
router.post("/:id/progress", asyncHandler(async (req: Request, res: Response) => {
  const workflowId = req.params.id;
  const feedback = updateProgressSchema.parse(req.body);
  
  const progress = await workflowEngine.updateProgress(workflowId, feedback);
  
  if (!progress) {
    throw new NotFoundError(`Workflow ${workflowId} not found`);
  }
  
  res.json({
    success: true,
    data: progress,
  });
}));

/**
 * POST /api/workflows/:id/adjust
 * Adjust workflow based on feedback
 */
router.post("/:id/adjust", asyncHandler(async (req: Request, res: Response) => {
  const workflowId = req.params.id;
  const data = adjustWorkflowSchema.parse(req.body);
  
  const workflow = await workflowEngine.adjustWorkflow(workflowId, data);
  
  if (!workflow) {
    throw new NotFoundError(`Workflow ${workflowId} not found`);
  }
  
  res.json({
    success: true,
    data: workflow,
    message: "Workflow adjusted successfully",
  });
}));

/**
 * POST /api/workflows/:id/pause
 * Pause a workflow
 */
router.post("/:id/pause", asyncHandler(async (req: Request, res: Response) => {
  const workflowId = req.params.id;
  const success = await workflowEngine.pauseWorkflow(workflowId);
  
  if (!success) {
    throw new NotFoundError(`Workflow ${workflowId} not found`);
  }
  
  res.json({
    success: true,
    message: "Workflow paused successfully",
  });
}));

/**
 * POST /api/workflows/:id/resume
 * Resume a paused workflow
 */
router.post("/:id/resume", asyncHandler(async (req: Request, res: Response) => {
  const workflowId = req.params.id;
  const success = await workflowEngine.resumeWorkflow(workflowId);
  
  if (!success) {
    throw new NotFoundError(`Workflow ${workflowId} not found or not paused`);
  }
  
  res.json({
    success: true,
    message: "Workflow resumed successfully",
  });
}));

/**
 * POST /api/workflows/:id/complete
 * Mark a workflow as complete
 */
router.post("/:id/complete", asyncHandler(async (req: Request, res: Response) => {
  const workflowId = req.params.id;
  const success = await workflowEngine.completeWorkflow(workflowId);
  
  if (!success) {
    throw new NotFoundError(`Workflow ${workflowId} not found`);
  }
  
  res.json({
    success: true,
    message: "Workflow completed successfully",
  });
}));

export { router as workflowsRouter };
