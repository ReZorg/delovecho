/**
 * Agent API Routes
 * AI agent interactions for consultations and recommendations
 */

import { Router, type Request, type Response } from "express";
import { z } from "zod";
import { asyncHandler, BadRequestError } from "../middleware/error-handler";
import { AgentService } from "../services/agent";

const router = Router();
const agentService = new AgentService();

// Schemas
const consultationSchema = z.object({
  skinType: z.string().min(1),
  skinConcerns: z.array(z.string()).min(1),
  goals: z.array(z.string()).optional().default([]),
  currentProducts: z.array(z.string()).optional().default([]),
  lifestyle: z.object({
    sunExposure: z.enum(["low", "moderate", "high"]).optional(),
    stressLevel: z.enum(["low", "moderate", "high"]).optional(),
    sleepQuality: z.enum(["poor", "fair", "good"]).optional(),
    diet: z.enum(["poor", "fair", "good"]).optional(),
    waterIntake: z.enum(["low", "moderate", "high"]).optional(),
  }).optional(),
  budget: z.enum(["budget", "moderate", "premium"]).optional(),
  preferences: z.object({
    preferNatural: z.boolean().optional(),
    fragranceFree: z.boolean().optional(),
    veganOnly: z.boolean().optional(),
  }).optional(),
});

const routineRequestSchema = z.object({
  skinType: z.string().min(1),
  skinConcerns: z.array(z.string()).min(1),
  goals: z.array(z.string()).optional().default([]),
  routineType: z.enum(["minimal", "standard", "comprehensive"]).optional().default("standard"),
  includeWeeklyTreatments: z.boolean().optional().default(true),
});

const zoneAnalysisSchema = z.object({
  skinType: z.string().min(1),
  skinConcerns: z.array(z.string()).min(1),
  currentProducts: z.array(z.string()).optional().default([]),
});

/**
 * POST /api/agent/consultation
 * Run an AI consultation
 */
router.post("/consultation", asyncHandler(async (req: Request, res: Response) => {
  const data = consultationSchema.parse(req.body);
  const result = await agentService.runConsultation(data);
  
  res.json({
    success: true,
    data: result,
  });
}));

/**
 * POST /api/agent/routine
 * Generate a personalized skincare routine
 */
router.post("/routine", asyncHandler(async (req: Request, res: Response) => {
  const data = routineRequestSchema.parse(req.body);
  const routine = await agentService.generateRoutine(data);
  
  res.json({
    success: true,
    data: routine,
  });
}));

/**
 * POST /api/agent/zone-analysis
 * Analyze skin profile using Zone Concept
 */
router.post("/zone-analysis", asyncHandler(async (req: Request, res: Response) => {
  const data = zoneAnalysisSchema.parse(req.body);
  const analysis = await agentService.analyzeZones(data);
  
  res.json({
    success: true,
    data: analysis,
  });
}));

/**
 * GET /api/agent/zone-info
 * Get information about the Zone Concept
 */
router.get("/zone-info", asyncHandler(async (req: Request, res: Response) => {
  const zoneInfo = agentService.getZoneInfo();
  
  res.json({
    success: true,
    data: zoneInfo,
  });
}));

/**
 * POST /api/agent/product-match
 * Find products matching specific criteria
 */
router.post("/product-match", asyncHandler(async (req: Request, res: Response) => {
  const { skinType, concerns, zone, category } = req.body;
  
  if (!skinType || !concerns || concerns.length === 0) {
    throw new BadRequestError("skinType and concerns are required");
  }
  
  const matches = await agentService.findProductMatches({
    skinType,
    concerns,
    zone,
    category,
  });
  
  res.json({
    success: true,
    data: matches,
  });
}));

/**
 * POST /api/agent/ingredient-advice
 * Get ingredient recommendations for specific concerns
 */
router.post("/ingredient-advice", asyncHandler(async (req: Request, res: Response) => {
  const { concerns, skinType, avoidIngredients } = req.body;
  
  if (!concerns || concerns.length === 0) {
    throw new BadRequestError("concerns array is required");
  }
  
  const advice = await agentService.getIngredientAdvice({
    concerns,
    skinType,
    avoidIngredients: avoidIngredients || [],
  });
  
  res.json({
    success: true,
    data: advice,
  });
}));

/**
 * GET /api/agent/skin-types
 * Get information about different skin types
 */
router.get("/skin-types", asyncHandler(async (req: Request, res: Response) => {
  const skinTypes = agentService.getSkinTypesInfo();
  
  res.json({
    success: true,
    data: skinTypes,
  });
}));

/**
 * GET /api/agent/concerns
 * Get list of common skin concerns
 */
router.get("/concerns", asyncHandler(async (req: Request, res: Response) => {
  const concerns = agentService.getSkinConcerns();
  
  res.json({
    success: true,
    data: concerns,
  });
}));

export { router as agentRouter };
