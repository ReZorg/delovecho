/**
 * Lessons API Routes
 */

import { Router, type Request, type Response } from "express";
import { z } from "zod";
import { asyncHandler, NotFoundError, BadRequestError } from "../middleware/error-handler";
import { LessonsService } from "../services/lessons";

const router = Router();
const lessonsService = new LessonsService();

const createLessonSchema = z.object({
  moduleId: z.number().int().positive(),
  title: z.string().min(1).max(200),
  description: z.string().min(1),
  content: z.string().min(1),
  videoUrl: z.string().url().optional(),
  order: z.number().int().positive(),
});

const updateLessonSchema = createLessonSchema.partial();

/**
 * GET /api/lessons
 * List all lessons (with optional filtering)
 */
router.get("/", asyncHandler(async (req: Request, res: Response) => {
  const moduleId = req.query.moduleId ? parseInt(req.query.moduleId as string, 10) : undefined;
  
  const lessons = moduleId 
    ? await lessonsService.getLessonsByModule(moduleId)
    : await lessonsService.getAllLessons();
  
  res.json({
    success: true,
    data: lessons,
    meta: {
      total: lessons.length,
      ...(moduleId && { moduleId }),
    },
  });
}));

/**
 * GET /api/lessons/:id
 * Get a specific lesson with all related data
 */
router.get("/:id", asyncHandler(async (req: Request, res: Response) => {
  const lessonId = parseInt(req.params.id, 10);
  
  if (isNaN(lessonId)) {
    throw new BadRequestError("Invalid lesson ID");
  }
  
  const lesson = await lessonsService.getLessonById(lessonId);
  
  if (!lesson) {
    throw new NotFoundError(`Lesson with ID ${lessonId} not found`);
  }
  
  res.json({
    success: true,
    data: lesson,
  });
}));

/**
 * GET /api/lessons/:id/steps
 * Get steps for a lesson
 */
router.get("/:id/steps", asyncHandler(async (req: Request, res: Response) => {
  const lessonId = parseInt(req.params.id, 10);
  
  if (isNaN(lessonId)) {
    throw new BadRequestError("Invalid lesson ID");
  }
  
  const steps = await lessonsService.getLessonSteps(lessonId);
  
  res.json({
    success: true,
    data: steps,
    meta: {
      lessonId,
      total: steps.length,
    },
  });
}));

/**
 * GET /api/lessons/:id/resources
 * Get resources for a lesson
 */
router.get("/:id/resources", asyncHandler(async (req: Request, res: Response) => {
  const lessonId = parseInt(req.params.id, 10);
  
  if (isNaN(lessonId)) {
    throw new BadRequestError("Invalid lesson ID");
  }
  
  const resources = await lessonsService.getLessonResources(lessonId);
  
  res.json({
    success: true,
    data: resources,
    meta: {
      lessonId,
      total: resources.length,
    },
  });
}));

/**
 * GET /api/lessons/:id/quiz
 * Get quiz for a lesson
 */
router.get("/:id/quiz", asyncHandler(async (req: Request, res: Response) => {
  const lessonId = parseInt(req.params.id, 10);
  
  if (isNaN(lessonId)) {
    throw new BadRequestError("Invalid lesson ID");
  }
  
  const quiz = await lessonsService.getLessonQuiz(lessonId);
  
  res.json({
    success: true,
    data: quiz,
  });
}));

/**
 * POST /api/lessons
 * Create a new lesson
 */
router.post("/", asyncHandler(async (req: Request, res: Response) => {
  const data = createLessonSchema.parse(req.body);
  const lesson = await lessonsService.createLesson(data);
  
  res.status(201).json({
    success: true,
    data: lesson,
  });
}));

/**
 * PUT /api/lessons/:id
 * Update a lesson
 */
router.put("/:id", asyncHandler(async (req: Request, res: Response) => {
  const lessonId = parseInt(req.params.id, 10);
  
  if (isNaN(lessonId)) {
    throw new BadRequestError("Invalid lesson ID");
  }
  
  const data = updateLessonSchema.parse(req.body);
  const lesson = await lessonsService.updateLesson(lessonId, data);
  
  if (!lesson) {
    throw new NotFoundError(`Lesson with ID ${lessonId} not found`);
  }
  
  res.json({
    success: true,
    data: lesson,
  });
}));

/**
 * DELETE /api/lessons/:id
 * Delete a lesson
 */
router.delete("/:id", asyncHandler(async (req: Request, res: Response) => {
  const lessonId = parseInt(req.params.id, 10);
  
  if (isNaN(lessonId)) {
    throw new BadRequestError("Invalid lesson ID");
  }
  
  const deleted = await lessonsService.deleteLesson(lessonId);
  
  if (!deleted) {
    throw new NotFoundError(`Lesson with ID ${lessonId} not found`);
  }
  
  res.json({
    success: true,
    message: "Lesson deleted successfully",
  });
}));

export { router as lessonsRouter };
