/**
 * Products API Routes
 */

import { Router, type Request, type Response } from "express";
import { z } from "zod";
import { asyncHandler, NotFoundError, BadRequestError } from "../middleware/error-handler";
import { ProductsService } from "../services/products";

const router = Router();
const productsService = new ProductsService();

const productFilterSchema = z.object({
  category: z.string().optional(),
  type: z.enum(["professional", "retail"]).optional(),
  skinType: z.string().optional(),
  concern: z.string().optional(),
  zone: z.enum(["spa", "zon", "med"]).optional(),
  search: z.string().optional(),
  limit: z.coerce.number().int().positive().max(100).optional(),
  offset: z.coerce.number().int().nonnegative().optional(),
});

/**
 * GET /api/products
 * List products with filtering
 */
router.get("/", asyncHandler(async (req: Request, res: Response) => {
  const filters = productFilterSchema.parse(req.query);
  const result = await productsService.getProducts(filters);
  
  res.json({
    success: true,
    data: result.products,
    meta: {
      total: result.total,
      limit: filters.limit || 50,
      offset: filters.offset || 0,
      filters: {
        category: filters.category,
        type: filters.type,
        skinType: filters.skinType,
        concern: filters.concern,
        zone: filters.zone,
      },
    },
  });
}));

/**
 * GET /api/products/categories
 * Get all product categories
 */
router.get("/categories", asyncHandler(async (req: Request, res: Response) => {
  const categories = await productsService.getCategories();
  
  res.json({
    success: true,
    data: categories,
  });
}));

/**
 * GET /api/products/search
 * Search products
 */
router.get("/search", asyncHandler(async (req: Request, res: Response) => {
  const query = req.query.q as string;
  
  if (!query || query.length < 2) {
    throw new BadRequestError("Search query must be at least 2 characters");
  }
  
  const products = await productsService.searchProducts(query);
  
  res.json({
    success: true,
    data: products,
    meta: {
      query,
      total: products.length,
    },
  });
}));

/**
 * GET /api/products/recommendations
 * Get product recommendations based on skin profile
 */
router.get("/recommendations", asyncHandler(async (req: Request, res: Response) => {
  const skinType = req.query.skinType as string;
  const concerns = (req.query.concerns as string)?.split(",") || [];
  const goals = (req.query.goals as string)?.split(",") || [];
  
  if (!skinType) {
    throw new BadRequestError("skinType is required");
  }
  
  const recommendations = await productsService.getRecommendations(skinType, concerns, goals);
  
  res.json({
    success: true,
    data: recommendations,
    meta: {
      skinType,
      concerns,
      goals,
    },
  });
}));

/**
 * GET /api/products/:id
 * Get a specific product
 */
router.get("/:id", asyncHandler(async (req: Request, res: Response) => {
  const productId = parseInt(req.params.id, 10);
  
  if (isNaN(productId)) {
    throw new BadRequestError("Invalid product ID");
  }
  
  const product = await productsService.getProductById(productId);
  
  if (!product) {
    throw new NotFoundError(`Product with ID ${productId} not found`);
  }
  
  res.json({
    success: true,
    data: product,
  });
}));

/**
 * GET /api/products/:id/zone-analysis
 * Get Zone Concept analysis for a product
 */
router.get("/:id/zone-analysis", asyncHandler(async (req: Request, res: Response) => {
  const productId = parseInt(req.params.id, 10);
  
  if (isNaN(productId)) {
    throw new BadRequestError("Invalid product ID");
  }
  
  const analysis = await productsService.getProductZoneAnalysis(productId);
  
  if (!analysis) {
    throw new NotFoundError(`Product with ID ${productId} not found`);
  }
  
  res.json({
    success: true,
    data: analysis,
  });
}));

/**
 * GET /api/products/:id/synergies
 * Get product synergies
 */
router.get("/:id/synergies", asyncHandler(async (req: Request, res: Response) => {
  const productId = parseInt(req.params.id, 10);
  
  if (isNaN(productId)) {
    throw new BadRequestError("Invalid product ID");
  }
  
  const synergies = await productsService.getProductSynergies(productId);
  
  res.json({
    success: true,
    data: synergies,
  });
}));

export { router as productsRouter };
