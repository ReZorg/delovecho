/**
 * Ingredients API Routes
 */

import { Router, type Request, type Response } from "express";
import { asyncHandler, NotFoundError, BadRequestError } from "../middleware/error-handler";
import { 
  ingredientsCatalog, 
  ingredientsByCategory, 
  ingredientsByConcern,
  ingredientsByZone,
  getIngredientInfo, 
  getIngredientsForConcern,
  getIngredientsForSkinType,
  checkIngredientCompatibility,
  type IngredientInfo 
} from "@regima/core";

const router = Router();

/**
 * GET /api/ingredients
 * List all ingredients with optional filtering
 */
router.get("/", asyncHandler(async (req: Request, res: Response) => {
  const category = req.query.category as string | undefined;
  const concern = req.query.concern as string | undefined;
  const skinType = req.query.skinType as string | undefined;
  const zone = req.query.zone as string | undefined;
  const search = req.query.search as string | undefined;
  
  let ingredients: IngredientInfo[] = [...ingredientsCatalog];
  
  if (category) {
    ingredients = ingredients.filter((i) => 
      i.category.toLowerCase().includes(category.toLowerCase())
    );
  }
  
  if (concern) {
    ingredients = getIngredientsForConcern(concern);
  }
  
  if (skinType) {
    ingredients = getIngredientsForSkinType(skinType);
  }
  
  if (zone) {
    ingredients = ingredients.filter((i) =>
      i.zoneCompatibility?.includes(zone as any)
    );
  }
  
  if (search) {
    const searchLower = search.toLowerCase();
    ingredients = ingredients.filter((i) =>
      i.name.toLowerCase().includes(searchLower) ||
      i.inciName?.toLowerCase().includes(searchLower) ||
      i.category.toLowerCase().includes(searchLower)
    );
  }
  
  res.json({
    success: true,
    data: ingredients,
    meta: {
      total: ingredients.length,
      filters: { category, concern, skinType, zone, search },
    },
  });
}));

/**
 * GET /api/ingredients/categories
 * Get ingredients organized by category
 */
router.get("/categories", asyncHandler(async (req: Request, res: Response) => {
  res.json({
    success: true,
    data: ingredientsByCategory,
    meta: {
      totalCategories: Object.keys(ingredientsByCategory).length,
    },
  });
}));

/**
 * GET /api/ingredients/concerns
 * Get ingredients organized by skin concern
 */
router.get("/concerns", asyncHandler(async (req: Request, res: Response) => {
  res.json({
    success: true,
    data: ingredientsByConcern,
    meta: {
      totalConcerns: Object.keys(ingredientsByConcern).length,
    },
  });
}));

/**
 * GET /api/ingredients/zones
 * Get ingredients organized by Zone Concept
 */
router.get("/zones", asyncHandler(async (req: Request, res: Response) => {
  res.json({
    success: true,
    data: ingredientsByZone,
    meta: {
      zones: Object.keys(ingredientsByZone),
    },
  });
}));

/**
 * GET /api/ingredients/search
 * Search ingredients
 */
router.get("/search", asyncHandler(async (req: Request, res: Response) => {
  const query = req.query.q as string;
  
  if (!query || query.length < 2) {
    throw new BadRequestError("Search query must be at least 2 characters");
  }
  
  const queryLower = query.toLowerCase();
  const results = ingredientsCatalog.filter((ingredient) =>
    ingredient.name.toLowerCase().includes(queryLower) ||
    ingredient.inciName?.toLowerCase().includes(queryLower) ||
    ingredient.category.toLowerCase().includes(queryLower) ||
    ingredient.mainFunctions.some((f) => f.toLowerCase().includes(queryLower)) ||
    ingredient.benefits.some((b) => b.toLowerCase().includes(queryLower))
  );
  
  res.json({
    success: true,
    data: results,
    meta: {
      query,
      total: results.length,
    },
  });
}));

/**
 * GET /api/ingredients/compatibility
 * Check compatibility between two ingredients
 */
router.get("/compatibility", asyncHandler(async (req: Request, res: Response) => {
  const ingredient1 = req.query.ingredient1 as string;
  const ingredient2 = req.query.ingredient2 as string;
  
  if (!ingredient1 || !ingredient2) {
    throw new BadRequestError("Both ingredient1 and ingredient2 are required");
  }
  
  const result = checkIngredientCompatibility(ingredient1, ingredient2);
  
  const info1 = getIngredientInfo(ingredient1);
  const info2 = getIngredientInfo(ingredient2);
  
  res.json({
    success: true,
    data: {
      ingredient1: info1 || { name: ingredient1 },
      ingredient2: info2 || { name: ingredient2 },
      compatibility: result,
    },
  });
}));

/**
 * GET /api/ingredients/for-concern/:concern
 * Get recommended ingredients for a specific skin concern
 */
router.get("/for-concern/:concern", asyncHandler(async (req: Request, res: Response) => {
  const concern = req.params.concern;
  const ingredients = getIngredientsForConcern(concern);
  
  if (ingredients.length === 0) {
    throw new NotFoundError(`No ingredients found for concern: ${concern}`);
  }
  
  res.json({
    success: true,
    data: ingredients,
    meta: {
      concern,
      total: ingredients.length,
    },
  });
}));

/**
 * GET /api/ingredients/for-skin-type/:skinType
 * Get recommended ingredients for a specific skin type
 */
router.get("/for-skin-type/:skinType", asyncHandler(async (req: Request, res: Response) => {
  const skinType = req.params.skinType;
  const ingredients = getIngredientsForSkinType(skinType);
  
  if (ingredients.length === 0) {
    throw new NotFoundError(`No ingredients found for skin type: ${skinType}`);
  }
  
  res.json({
    success: true,
    data: ingredients,
    meta: {
      skinType,
      total: ingredients.length,
    },
  });
}));

/**
 * GET /api/ingredients/:name
 * Get detailed information about a specific ingredient
 */
router.get("/:name", asyncHandler(async (req: Request, res: Response) => {
  const name = req.params.name;
  const ingredient = getIngredientInfo(name);
  
  if (!ingredient) {
    throw new NotFoundError(`Ingredient "${name}" not found`);
  }
  
  res.json({
    success: true,
    data: ingredient,
  });
}));

export { router as ingredientsRouter };
