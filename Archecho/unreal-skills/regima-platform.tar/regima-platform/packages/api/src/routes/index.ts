/**
 * API Routes Registration
 */

import type { Express } from "express";
import { modulesRouter } from "./modules";
import { lessonsRouter } from "./lessons";
import { productsRouter } from "./products";
import { ingredientsRouter } from "./ingredients";
import { agentRouter } from "./agent";
import { workflowsRouter } from "./workflows";
import { progressRouter } from "./progress";

export async function registerRoutes(app: Express): Promise<void> {
  // Training content routes
  app.use("/api/modules", modulesRouter);
  app.use("/api/lessons", lessonsRouter);
  
  // Product & ingredient routes
  app.use("/api/products", productsRouter);
  app.use("/api/ingredients", ingredientsRouter);
  
  // AI agent routes
  app.use("/api/agent", agentRouter);
  
  // Workflow routes
  app.use("/api/workflows", workflowsRouter);
  
  // Progress tracking routes
  app.use("/api/progress", progressRouter);
}

export { modulesRouter } from "./modules";
export { lessonsRouter } from "./lessons";
export { productsRouter } from "./products";
export { ingredientsRouter } from "./ingredients";
export { agentRouter } from "./agent";
export { workflowsRouter } from "./workflows";
export { progressRouter } from "./progress";
