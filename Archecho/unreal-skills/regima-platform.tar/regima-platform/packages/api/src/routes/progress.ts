/**
 * Progress API Routes
 * User progress tracking for training and skincare
 */

import { Router, type Request, type Response } from "express";
import { z } from "zod";
import { asyncHandler, NotFoundError, BadRequestError } from "../middleware/error-handler";
import { ProgressService } from "../services/progress";

const router = Router();
const progressService = new ProgressService();

// Schemas
const updateLessonProgressSchema = z.object({
  userId: z.number().int().positive(),
  lessonId: z.number().int().positive(),
  completed: z.boolean(),
  score: z.number().min(0).max(100).optional(),
  timeSpent: z.number().int().positive().optional(),
});

const submitQuizSchema = z.object({
  userId: z.number().int().positive(),
  lessonId: z.number().int().positive(),
  answers: z.array(z.object({
    questionId: z.string(),
    selectedOptionId: z.string(),
  })),
});

/**
 * GET /api/progress/:userId
 * Get overall progress for a user
 */
router.get("/:userId", asyncHandler(async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId, 10);
  
  if (isNaN(userId)) {
    throw new BadRequestError("Invalid user ID");
  }
  
  const progress = await progressService.getUserProgress(userId);
  
  res.json({
    success: true,
    data: progress,
  });
}));

/**
 * GET /api/progress/:userId/modules
 * Get module-level progress for a user
 */
router.get("/:userId/modules", asyncHandler(async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId, 10);
  
  if (isNaN(userId)) {
    throw new BadRequestError("Invalid user ID");
  }
  
  const moduleProgress = await progressService.getModuleProgress(userId);
  
  res.json({
    success: true,
    data: moduleProgress,
  });
}));

/**
 * GET /api/progress/:userId/modules/:moduleId
 * Get detailed progress for a specific module
 */
router.get("/:userId/modules/:moduleId", asyncHandler(async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId, 10);
  const moduleId = parseInt(req.params.moduleId, 10);
  
  if (isNaN(userId) || isNaN(moduleId)) {
    throw new BadRequestError("Invalid user ID or module ID");
  }
  
  const progress = await progressService.getModuleDetailedProgress(userId, moduleId);
  
  if (!progress) {
    throw new NotFoundError(`Progress not found for user ${userId} and module ${moduleId}`);
  }
  
  res.json({
    success: true,
    data: progress,
  });
}));

/**
 * GET /api/progress/:userId/lessons/:lessonId
 * Get progress for a specific lesson
 */
router.get("/:userId/lessons/:lessonId", asyncHandler(async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId, 10);
  const lessonId = parseInt(req.params.lessonId, 10);
  
  if (isNaN(userId) || isNaN(lessonId)) {
    throw new BadRequestError("Invalid user ID or lesson ID");
  }
  
  const progress = await progressService.getLessonProgress(userId, lessonId);
  
  res.json({
    success: true,
    data: progress,
  });
}));

/**
 * POST /api/progress/lesson
 * Update lesson progress
 */
router.post("/lesson", asyncHandler(async (req: Request, res: Response) => {
  const data = updateLessonProgressSchema.parse(req.body);
  const progress = await progressService.updateLessonProgress(data);
  
  res.json({
    success: true,
    data: progress,
  });
}));

/**
 * POST /api/progress/quiz
 * Submit quiz answers
 */
router.post("/quiz", asyncHandler(async (req: Request, res: Response) => {
  const data = submitQuizSchema.parse(req.body);
  const result = await progressService.submitQuiz(data);
  
  res.json({
    success: true,
    data: result,
  });
}));

/**
 * GET /api/progress/:userId/achievements
 * Get user achievements
 */
router.get("/:userId/achievements", asyncHandler(async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId, 10);
  
  if (isNaN(userId)) {
    throw new BadRequestError("Invalid user ID");
  }
  
  const achievements = await progressService.getUserAchievements(userId);
  
  res.json({
    success: true,
    data: achievements,
  });
}));

/**
 * GET /api/progress/:userId/streak
 * Get user's learning streak
 */
router.get("/:userId/streak", asyncHandler(async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId, 10);
  
  if (isNaN(userId)) {
    throw new BadRequestError("Invalid user ID");
  }
  
  const streak = await progressService.getUserStreak(userId);
  
  res.json({
    success: true,
    data: streak,
  });
}));

/**
 * GET /api/progress/:userId/certificate
 * Check certificate eligibility
 */
router.get("/:userId/certificate", asyncHandler(async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId, 10);
  
  if (isNaN(userId)) {
    throw new BadRequestError("Invalid user ID");
  }
  
  const certificate = await progressService.checkCertificateEligibility(userId);
  
  res.json({
    success: true,
    data: certificate,
  });
}));

export { router as progressRouter };
