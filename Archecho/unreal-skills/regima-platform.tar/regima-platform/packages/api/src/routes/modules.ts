/**
 * Modules API Routes
 * Training module management endpoints
 */

import { Router, type Request, type Response } from "express";
import { z } from "zod";
import { asyncHandler, NotFoundError, BadRequestError } from "../middleware/error-handler";
import { ModulesService } from "../services/modules";

const router = Router();
const modulesService = new ModulesService();

// Schema for creating/updating modules
const createModuleSchema = z.object({
  title: z.string().min(1).max(200),
  description: z.string().min(1),
  estimatedTime: z.string(),
  order: z.number().int().positive(),
});

const updateModuleSchema = createModuleSchema.partial();

/**
 * GET /api/modules
 * List all training modules
 */
router.get("/", asyncHandler(async (req: Request, res: Response) => {
  const modules = await modulesService.getAllModules();
  
  res.json({
    success: true,
    data: modules,
    meta: {
      total: modules.length,
    },
  });
}));

/**
 * GET /api/modules/:id
 * Get a specific module by ID
 */
router.get("/:id", asyncHandler(async (req: Request, res: Response) => {
  const moduleId = parseInt(req.params.id, 10);
  
  if (isNaN(moduleId)) {
    throw new BadRequestError("Invalid module ID");
  }
  
  const module = await modulesService.getModuleById(moduleId);
  
  if (!module) {
    throw new NotFoundError(`Module with ID ${moduleId} not found`);
  }
  
  res.json({
    success: true,
    data: module,
  });
}));

/**
 * GET /api/modules/:id/lessons
 * Get all lessons for a module
 */
router.get("/:id/lessons", asyncHandler(async (req: Request, res: Response) => {
  const moduleId = parseInt(req.params.id, 10);
  
  if (isNaN(moduleId)) {
    throw new BadRequestError("Invalid module ID");
  }
  
  const lessons = await modulesService.getModuleLessons(moduleId);
  
  res.json({
    success: true,
    data: lessons,
    meta: {
      moduleId,
      total: lessons.length,
    },
  });
}));

/**
 * POST /api/modules
 * Create a new module
 */
router.post("/", asyncHandler(async (req: Request, res: Response) => {
  const data = createModuleSchema.parse(req.body);
  const module = await modulesService.createModule(data);
  
  res.status(201).json({
    success: true,
    data: module,
  });
}));

/**
 * PUT /api/modules/:id
 * Update a module
 */
router.put("/:id", asyncHandler(async (req: Request, res: Response) => {
  const moduleId = parseInt(req.params.id, 10);
  
  if (isNaN(moduleId)) {
    throw new BadRequestError("Invalid module ID");
  }
  
  const data = updateModuleSchema.parse(req.body);
  const module = await modulesService.updateModule(moduleId, data);
  
  if (!module) {
    throw new NotFoundError(`Module with ID ${moduleId} not found`);
  }
  
  res.json({
    success: true,
    data: module,
  });
}));

/**
 * DELETE /api/modules/:id
 * Delete a module
 */
router.delete("/:id", asyncHandler(async (req: Request, res: Response) => {
  const moduleId = parseInt(req.params.id, 10);
  
  if (isNaN(moduleId)) {
    throw new BadRequestError("Invalid module ID");
  }
  
  const deleted = await modulesService.deleteModule(moduleId);
  
  if (!deleted) {
    throw new NotFoundError(`Module with ID ${moduleId} not found`);
  }
  
  res.json({
    success: true,
    message: "Module deleted successfully",
  });
}));

export { router as modulesRouter };
