/**
 * Error Handler Middleware
 */

import type { Request, Response, NextFunction } from "express";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { logger } from "../services/logger";
import { config } from "../config";

export interface ApiError extends Error {
  statusCode?: number;
  code?: string;
  details?: unknown;
}

export class HttpError extends Error implements ApiError {
  statusCode: number;
  code: string;
  details?: unknown;

  constructor(statusCode: number, message: string, code?: string, details?: unknown) {
    super(message);
    this.statusCode = statusCode;
    this.code = code || "ERROR";
    this.details = details;
    this.name = "HttpError";
  }
}

export class BadRequestError extends HttpError {
  constructor(message: string = "Bad Request", details?: unknown) {
    super(400, message, "BAD_REQUEST", details);
    this.name = "BadRequestError";
  }
}

export class UnauthorizedError extends HttpError {
  constructor(message: string = "Unauthorized") {
    super(401, message, "UNAUTHORIZED");
    this.name = "UnauthorizedError";
  }
}

export class ForbiddenError extends HttpError {
  constructor(message: string = "Forbidden") {
    super(403, message, "FORBIDDEN");
    this.name = "ForbiddenError";
  }
}

export class NotFoundError extends HttpError {
  constructor(message: string = "Not Found") {
    super(404, message, "NOT_FOUND");
    this.name = "NotFoundError";
  }
}

export class ConflictError extends HttpError {
  constructor(message: string = "Conflict") {
    super(409, message, "CONFLICT");
    this.name = "ConflictError";
  }
}

export class ValidationError extends HttpError {
  constructor(message: string = "Validation Error", details?: unknown) {
    super(422, message, "VALIDATION_ERROR", details);
    this.name = "ValidationError";
  }
}

export class InternalServerError extends HttpError {
  constructor(message: string = "Internal Server Error") {
    super(500, message, "INTERNAL_ERROR");
    this.name = "InternalServerError";
  }
}

export function notFoundHandler(req: Request, res: Response, next: NextFunction): void {
  res.status(404).json({
    success: false,
    error: {
      code: "NOT_FOUND",
      message: `Route ${req.method} ${req.path} not found`,
    },
  });
}

export function errorHandler(
  err: Error | ApiError,
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Log the error
  logger.error(`Error handling request ${req.method} ${req.path}`, err);

  // Handle Zod validation errors
  if (err instanceof ZodError) {
    const validationError = fromZodError(err);
    res.status(422).json({
      success: false,
      error: {
        code: "VALIDATION_ERROR",
        message: validationError.message,
        details: err.errors,
      },
    });
    return;
  }

  // Handle custom HTTP errors
  if (err instanceof HttpError) {
    res.status(err.statusCode).json({
      success: false,
      error: {
        code: err.code,
        message: err.message,
        ...(err.details && { details: err.details }),
      },
    });
    return;
  }

  // Handle generic errors
  const statusCode = (err as ApiError).statusCode || 500;
  const message = config.nodeEnv === "production"
    ? "Internal Server Error"
    : err.message || "Internal Server Error";

  res.status(statusCode).json({
    success: false,
    error: {
      code: "INTERNAL_ERROR",
      message,
      ...(config.nodeEnv !== "production" && { stack: err.stack }),
    },
  });
}

// Async handler wrapper to catch async errors
export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<void>
) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}
