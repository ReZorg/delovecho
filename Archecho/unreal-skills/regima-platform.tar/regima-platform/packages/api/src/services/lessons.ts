/**
 * Lessons Service
 * Business logic for training lessons
 */

import type { Lesson, InsertLesson, Step, Resource, Quiz } from "@regima/core";

// In-memory storage
const lessonsStore: Map<number, Lesson> = new Map();
const stepsStore: Map<number, Step> = new Map();
const resourcesStore: Map<number, Resource> = new Map();
const quizzesStore: Map<number, Quiz> = new Map();
let lessonIdCounter = 1;
let stepIdCounter = 1;
let resourceIdCounter = 1;
let quizIdCounter = 1;

// Initialize sample data
function initializeSampleData(): void {
  if (lessonsStore.size > 0) return;

  // Sample lessons for Module 1 (Introduction to RegimA)
  const sampleLessons: Omit<Lesson, "id">[] = [
    {
      moduleId: 1,
      title: "Welcome to RegimA",
      description: "An introduction to the RegimA brand and philosophy",
      content: `
# Welcome to RegimA

RegimA is a professional skincare brand founded on the principle of achieving optimal skin health through a balanced approach to skincare.

## Our Philosophy

The RegimA philosophy centers on three key pillars:

1. **Anti-inflammatory** - Calming and soothing the skin
2. **Anti-oxidant** - Protecting against environmental damage
3. **Rejuvenation** - Promoting cellular renewal and repair

## What You'll Learn

In this training program, you will:
- Understand the science behind effective skincare
- Master the Zone Concept
- Learn to recommend products based on individual skin needs
- Develop consultation skills
- Understand treatment protocols
      `,
      videoUrl: undefined,
      order: 1,
    },
    {
      moduleId: 1,
      title: "The RegimA Story",
      description: "Learn about the history and development of RegimA",
      content: `
# The RegimA Story

RegimA was developed by skincare professionals who recognized the need for a comprehensive approach to skin health.

## Our Beginnings

The brand was created to address the gap between medical-grade treatments and everyday skincare routines.

## Our Mission

To provide professional-grade skincare solutions that deliver visible results while maintaining skin health and integrity.
      `,
      videoUrl: undefined,
      order: 2,
    },
    {
      moduleId: 3,
      title: "Understanding the Zone Concept",
      description: "Deep dive into the three zones of skincare",
      content: `
# The Zone Concept

The Zone Concept is the foundation of the RegimA approach to skincare.

## The Three Zones

### SPA Zone (Anti-inflammatory)
- Focus on calming and soothing
- Reduces redness and irritation
- Supports barrier function
- Key ingredients: Centella Asiatica, Niacinamide, Bisabolol

### ZON Zone (Anti-oxidant)
- Protects against environmental damage
- Neutralizes free radicals
- Prevents premature aging
- Key ingredients: Vitamin C, Vitamin E, Ferulic Acid

### MED Zone (Rejuvenation)
- Promotes cellular renewal
- Stimulates collagen production
- Addresses signs of aging
- Key ingredients: Retinol, Peptides, AHAs

## Balancing the Zones

Effective skincare requires a balance of all three zones, tailored to individual skin needs.
      `,
      videoUrl: undefined,
      order: 1,
    },
  ];

  sampleLessons.forEach((lesson) => {
    const id = lessonIdCounter++;
    lessonsStore.set(id, { ...lesson, id });
  });

  // Add sample steps for first lesson
  const sampleSteps: Omit<Step, "id">[] = [
    {
      lessonId: 1,
      title: "Read the Introduction",
      description: "Familiarize yourself with the RegimA brand philosophy",
      order: 1,
    },
    {
      lessonId: 1,
      title: "Review the Three Pillars",
      description: "Understand the core principles of RegimA skincare",
      order: 2,
    },
    {
      lessonId: 1,
      title: "Complete the Knowledge Check",
      description: "Test your understanding with a short quiz",
      order: 3,
    },
  ];

  sampleSteps.forEach((step) => {
    const id = stepIdCounter++;
    stepsStore.set(id, { ...step, id });
  });

  // Add sample quiz
  const sampleQuiz: Omit<Quiz, "id"> = {
    lessonId: 1,
    questions: [
      {
        id: "q1",
        question: "What are the three pillars of the RegimA philosophy?",
        options: [
          { id: "a", text: "Cleanse, Tone, Moisturize" },
          { id: "b", text: "Anti-inflammatory, Anti-oxidant, Rejuvenation" },
          { id: "c", text: "Hydrate, Protect, Repair" },
          { id: "d", text: "Exfoliate, Treat, Seal" },
        ],
        correctOptionId: "b",
      },
      {
        id: "q2",
        question: "Which zone focuses on calming and soothing the skin?",
        options: [
          { id: "a", text: "MED Zone" },
          { id: "b", text: "ZON Zone" },
          { id: "c", text: "SPA Zone" },
          { id: "d", text: "PRO Zone" },
        ],
        correctOptionId: "c",
      },
    ],
  };

  const quizId = quizIdCounter++;
  quizzesStore.set(quizId, { ...sampleQuiz, id: quizId });
}

// Initialize on module load
initializeSampleData();

export interface LessonWithDetails extends Lesson {
  steps: Step[];
  resources: Resource[];
  quiz: Quiz | null;
}

export class LessonsService {
  async getAllLessons(): Promise<Lesson[]> {
    return Array.from(lessonsStore.values()).sort((a, b) => a.order - b.order);
  }

  async getLessonsByModule(moduleId: number): Promise<Lesson[]> {
    return Array.from(lessonsStore.values())
      .filter((lesson) => lesson.moduleId === moduleId)
      .sort((a, b) => a.order - b.order);
  }

  async getLessonById(id: number): Promise<LessonWithDetails | null> {
    const lesson = lessonsStore.get(id);
    if (!lesson) return null;

    const steps = await this.getLessonSteps(id);
    const resources = await this.getLessonResources(id);
    const quiz = await this.getLessonQuiz(id);

    return { ...lesson, steps, resources, quiz };
  }

  async getLessonSteps(lessonId: number): Promise<Step[]> {
    return Array.from(stepsStore.values())
      .filter((step) => step.lessonId === lessonId)
      .sort((a, b) => a.order - b.order);
  }

  async getLessonResources(lessonId: number): Promise<Resource[]> {
    return Array.from(resourcesStore.values())
      .filter((resource) => resource.lessonId === lessonId);
  }

  async getLessonQuiz(lessonId: number): Promise<Quiz | null> {
    const quiz = Array.from(quizzesStore.values())
      .find((q) => q.lessonId === lessonId);
    return quiz || null;
  }

  async createLesson(data: InsertLesson): Promise<Lesson> {
    const id = lessonIdCounter++;
    const lesson: Lesson = { ...data, id };
    lessonsStore.set(id, lesson);
    return lesson;
  }

  async updateLesson(id: number, data: Partial<InsertLesson>): Promise<Lesson | null> {
    const existing = lessonsStore.get(id);
    if (!existing) return null;

    const updated: Lesson = { ...existing, ...data };
    lessonsStore.set(id, updated);
    return updated;
  }

  async deleteLesson(id: number): Promise<boolean> {
    return lessonsStore.delete(id);
  }
}
