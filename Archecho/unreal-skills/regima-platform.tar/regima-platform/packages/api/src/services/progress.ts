/**
 * Progress Service
 * User progress tracking for training modules and lessons
 */

interface LessonProgress {
  lessonId: number;
  completed: boolean;
  score?: number;
  timeSpent?: number;
  completedAt?: Date;
  attempts: number;
}

interface ModuleProgress {
  moduleId: number;
  lessonsCompleted: number;
  totalLessons: number;
  averageScore: number;
  startedAt?: Date;
  completedAt?: Date;
}

interface UserProgress {
  userId: number;
  modulesCompleted: number;
  totalModules: number;
  lessonsCompleted: number;
  totalLessons: number;
  averageScore: number;
  totalTimeSpent: number;
  currentStreak: number;
  longestStreak: number;
  lastActivityAt?: Date;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  earnedAt: Date;
  icon: string;
}

interface QuizResult {
  lessonId: number;
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  passed: boolean;
  feedback: Array<{
    questionId: string;
    correct: boolean;
    correctAnswer?: string;
  }>;
}

// In-memory storage
const userProgressStore: Map<number, UserProgress> = new Map();
const lessonProgressStore: Map<string, LessonProgress> = new Map();
const achievementsStore: Map<number, Achievement[]> = new Map();

// Sample quiz data (would come from database)
const quizData: Record<number, Array<{ id: string; correctOptionId: string }>> = {
  1: [
    { id: "q1", correctOptionId: "b" },
    { id: "q2", correctOptionId: "c" },
  ],
};

export class ProgressService {
  async getUserProgress(userId: number): Promise<UserProgress> {
    let progress = userProgressStore.get(userId);
    
    if (!progress) {
      progress = {
        userId,
        modulesCompleted: 0,
        totalModules: 8,
        lessonsCompleted: 0,
        totalLessons: 24,
        averageScore: 0,
        totalTimeSpent: 0,
        currentStreak: 0,
        longestStreak: 0,
      };
      userProgressStore.set(userId, progress);
    }
    
    return progress;
  }

  async getModuleProgress(userId: number): Promise<ModuleProgress[]> {
    const modules: ModuleProgress[] = [];
    
    for (let moduleId = 1; moduleId <= 8; moduleId++) {
      const lessonsInModule = 3;
      let completed = 0;
      let totalScore = 0;
      let scoreCount = 0;
      
      for (let lessonId = 1; lessonId <= lessonsInModule; lessonId++) {
        const key = `${userId}-${moduleId}-${lessonId}`;
        const lessonProgress = lessonProgressStore.get(key);
        if (lessonProgress?.completed) {
          completed++;
          if (lessonProgress.score !== undefined) {
            totalScore += lessonProgress.score;
            scoreCount++;
          }
        }
      }
      
      modules.push({
        moduleId,
        lessonsCompleted: completed,
        totalLessons: lessonsInModule,
        averageScore: scoreCount > 0 ? Math.round(totalScore / scoreCount) : 0,
      });
    }
    
    return modules;
  }

  async getModuleDetailedProgress(
    userId: number,
    moduleId: number
  ): Promise<{
    module: ModuleProgress;
    lessons: LessonProgress[];
  } | null> {
    const lessonsInModule = 3;
    const lessons: LessonProgress[] = [];
    let completed = 0;
    let totalScore = 0;
    let scoreCount = 0;
    
    for (let lessonId = 1; lessonId <= lessonsInModule; lessonId++) {
      const key = `${userId}-${moduleId}-${lessonId}`;
      let lessonProgress = lessonProgressStore.get(key);
      
      if (!lessonProgress) {
        lessonProgress = {
          lessonId,
          completed: false,
          attempts: 0,
        };
      }
      
      lessons.push(lessonProgress);
      
      if (lessonProgress.completed) {
        completed++;
        if (lessonProgress.score !== undefined) {
          totalScore += lessonProgress.score;
          scoreCount++;
        }
      }
    }
    
    return {
      module: {
        moduleId,
        lessonsCompleted: completed,
        totalLessons: lessonsInModule,
        averageScore: scoreCount > 0 ? Math.round(totalScore / scoreCount) : 0,
      },
      lessons,
    };
  }

  async getLessonProgress(userId: number, lessonId: number): Promise<LessonProgress> {
    const key = `${userId}-${lessonId}`;
    let progress = lessonProgressStore.get(key);
    
    if (!progress) {
      progress = {
        lessonId,
        completed: false,
        attempts: 0,
      };
    }
    
    return progress;
  }

  async updateLessonProgress(data: {
    userId: number;
    lessonId: number;
    completed: boolean;
    score?: number;
    timeSpent?: number;
  }): Promise<LessonProgress> {
    const key = `${data.userId}-${data.lessonId}`;
    let progress = lessonProgressStore.get(key);
    
    if (!progress) {
      progress = {
        lessonId: data.lessonId,
        completed: false,
        attempts: 0,
      };
    }
    
    progress.completed = data.completed;
    if (data.score !== undefined) progress.score = data.score;
    if (data.timeSpent !== undefined) {
      progress.timeSpent = (progress.timeSpent || 0) + data.timeSpent;
    }
    if (data.completed) {
      progress.completedAt = new Date();
    }
    progress.attempts++;
    
    lessonProgressStore.set(key, progress);
    
    // Update user progress
    await this.recalculateUserProgress(data.userId);
    
    // Check for achievements
    await this.checkAchievements(data.userId);
    
    return progress;
  }

  async submitQuiz(data: {
    userId: number;
    lessonId: number;
    answers: Array<{ questionId: string; selectedOptionId: string }>;
  }): Promise<QuizResult> {
    const quiz = quizData[data.lessonId] || [];
    let correctAnswers = 0;
    const feedback: QuizResult["feedback"] = [];
    
    for (const answer of data.answers) {
      const question = quiz.find((q) => q.id === answer.questionId);
      const correct = question?.correctOptionId === answer.selectedOptionId;
      
      if (correct) correctAnswers++;
      
      feedback.push({
        questionId: answer.questionId,
        correct,
        correctAnswer: correct ? undefined : question?.correctOptionId,
      });
    }
    
    const totalQuestions = Math.max(quiz.length, data.answers.length);
    const score = Math.round((correctAnswers / totalQuestions) * 100);
    const passed = score >= 70;
    
    // Update lesson progress with quiz score
    await this.updateLessonProgress({
      userId: data.userId,
      lessonId: data.lessonId,
      completed: passed,
      score,
    });
    
    return {
      lessonId: data.lessonId,
      score,
      totalQuestions,
      correctAnswers,
      passed,
      feedback,
    };
  }

  async getUserAchievements(userId: number): Promise<Achievement[]> {
    return achievementsStore.get(userId) || [];
  }

  async getUserStreak(userId: number): Promise<{
    currentStreak: number;
    longestStreak: number;
    lastActivityDate?: string;
  }> {
    const progress = await this.getUserProgress(userId);
    
    return {
      currentStreak: progress.currentStreak,
      longestStreak: progress.longestStreak,
      lastActivityDate: progress.lastActivityAt?.toISOString(),
    };
  }

  async checkCertificateEligibility(userId: number): Promise<{
    eligible: boolean;
    requirements: Array<{
      requirement: string;
      met: boolean;
      current: number;
      required: number;
    }>;
    certificateType?: string;
  }> {
    const progress = await this.getUserProgress(userId);
    
    const requirements = [
      {
        requirement: "Complete all modules",
        met: progress.modulesCompleted >= progress.totalModules,
        current: progress.modulesCompleted,
        required: progress.totalModules,
      },
      {
        requirement: "Complete all lessons",
        met: progress.lessonsCompleted >= progress.totalLessons,
        current: progress.lessonsCompleted,
        required: progress.totalLessons,
      },
      {
        requirement: "Achieve minimum 70% average score",
        met: progress.averageScore >= 70,
        current: progress.averageScore,
        required: 70,
      },
    ];
    
    const eligible = requirements.every((r) => r.met);
    
    return {
      eligible,
      requirements,
      certificateType: eligible ? "RegimA Certified Skincare Specialist" : undefined,
    };
  }

  private async recalculateUserProgress(userId: number): Promise<void> {
    let lessonsCompleted = 0;
    let totalScore = 0;
    let scoreCount = 0;
    let totalTimeSpent = 0;
    
    lessonProgressStore.forEach((progress, key) => {
      if (key.startsWith(`${userId}-`)) {
        if (progress.completed) {
          lessonsCompleted++;
          if (progress.score !== undefined) {
            totalScore += progress.score;
            scoreCount++;
          }
        }
        if (progress.timeSpent) {
          totalTimeSpent += progress.timeSpent;
        }
      }
    });
    
    const modulesCompleted = Math.floor(lessonsCompleted / 3);
    
    const progress = await this.getUserProgress(userId);
    progress.lessonsCompleted = lessonsCompleted;
    progress.modulesCompleted = modulesCompleted;
    progress.averageScore = scoreCount > 0 ? Math.round(totalScore / scoreCount) : 0;
    progress.totalTimeSpent = totalTimeSpent;
    progress.lastActivityAt = new Date();
    
    // Update streak
    progress.currentStreak++;
    if (progress.currentStreak > progress.longestStreak) {
      progress.longestStreak = progress.currentStreak;
    }
    
    userProgressStore.set(userId, progress);
  }

  private async checkAchievements(userId: number): Promise<void> {
    const progress = await this.getUserProgress(userId);
    const achievements = achievementsStore.get(userId) || [];
    
    const possibleAchievements: Array<{
      id: string;
      name: string;
      description: string;
      icon: string;
      condition: () => boolean;
    }> = [
      {
        id: "first_lesson",
        name: "First Steps",
        description: "Complete your first lesson",
        icon: "🎯",
        condition: () => progress.lessonsCompleted >= 1,
      },
      {
        id: "first_module",
        name: "Module Master",
        description: "Complete your first module",
        icon: "📚",
        condition: () => progress.modulesCompleted >= 1,
      },
      {
        id: "perfect_score",
        name: "Perfect Score",
        description: "Achieve 100% on a quiz",
        icon: "⭐",
        condition: () => {
          let hasPerfect = false;
          lessonProgressStore.forEach((p, key) => {
            if (key.startsWith(`${userId}-`) && p.score === 100) {
              hasPerfect = true;
            }
          });
          return hasPerfect;
        },
      },
      {
        id: "streak_7",
        name: "Week Warrior",
        description: "Maintain a 7-day learning streak",
        icon: "🔥",
        condition: () => progress.currentStreak >= 7,
      },
      {
        id: "halfway",
        name: "Halfway There",
        description: "Complete 50% of all lessons",
        icon: "🏃",
        condition: () => progress.lessonsCompleted >= progress.totalLessons / 2,
      },
      {
        id: "graduate",
        name: "RegimA Graduate",
        description: "Complete all training modules",
        icon: "🎓",
        condition: () => progress.modulesCompleted >= progress.totalModules,
      },
    ];
    
    for (const possible of possibleAchievements) {
      if (!achievements.find((a) => a.id === possible.id) && possible.condition()) {
        achievements.push({
          id: possible.id,
          name: possible.name,
          description: possible.description,
          icon: possible.icon,
          earnedAt: new Date(),
        });
      }
    }
    
    achievementsStore.set(userId, achievements);
  }
}
