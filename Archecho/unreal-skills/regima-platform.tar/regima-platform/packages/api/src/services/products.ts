/**
 * Products Service
 * Business logic for product management and recommendations
 */

import type { Product, ZoneType } from "@regima/core";
import { ZoneConcept, RecommendationEngine, type ZoneProductScore, type ProductRecommendation } from "@regima/core";

// In-memory storage
const productsStore: Map<number, Product> = new Map();
let productIdCounter = 1;

const zoneConcept = new ZoneConcept();
const recommendationEngine = new RecommendationEngine();

// Initialize sample products
function initializeSampleProducts(): void {
  if (productsStore.size > 0) return;

  const sampleProducts: Omit<Product, "id">[] = [
    {
      name: "Gentle Cleansing Gel",
      category: "Cleanser",
      type: "retail",
      description: "A gentle, pH-balanced cleansing gel that effectively removes impurities without stripping the skin's natural moisture barrier.",
      mainFunctions: ["Deep cleansing", "pH balancing", "Hydrating"],
      starIngredients: { "Cleansing": ["Coco-Glucoside"], "Soothing": ["Aloe Vera", "Chamomile"] },
      keyIngredients: ["Coco-Glucoside", "Aloe Vera", "Chamomile Extract"],
      activeIngredients: ["Glycerin", "Panthenol"],
      skinTypes: ["All skin types", "Sensitive"],
      size: "200ml",
      usageInstructions: "Apply to damp skin, massage gently, rinse thoroughly.",
      pH: "5.5",
      zoneAction: ["Anti-inflammatory"],
      imageUrl: undefined,
      ingredients: ["Aqua", "Coco-Glucoside", "Glycerin", "Aloe Barbadensis Leaf Juice", "Panthenol", "Chamomilla Recutita Extract"],
    },
    {
      name: "Vitamin C Brightening Serum",
      category: "Serum",
      type: "retail",
      description: "A powerful antioxidant serum with stabilized Vitamin C to brighten skin tone and protect against environmental damage.",
      mainFunctions: ["Brightening", "Antioxidant protection", "Collagen support"],
      starIngredients: { "Brightening": ["L-Ascorbic Acid", "Niacinamide"], "Protection": ["Vitamin E", "Ferulic Acid"] },
      keyIngredients: ["L-Ascorbic Acid 15%", "Vitamin E", "Ferulic Acid"],
      activeIngredients: ["L-Ascorbic Acid", "Tocopherol", "Ferulic Acid", "Niacinamide"],
      skinTypes: ["Normal", "Oily", "Combination"],
      size: "30ml",
      usageInstructions: "Apply 2-3 drops to clean skin in the morning. Follow with moisturizer and sunscreen.",
      pH: "3.2",
      zoneAction: ["Anti-oxidant", "Rejuvenation"],
      imageUrl: undefined,
      ingredients: ["Aqua", "Ascorbic Acid", "Ethoxydiglycol", "Tocopherol", "Ferulic Acid", "Niacinamide"],
    },
    {
      name: "Retinol Night Treatment",
      category: "Treatment",
      type: "professional",
      description: "An advanced retinol treatment that accelerates cell turnover and stimulates collagen production for visible anti-aging results.",
      mainFunctions: ["Cell renewal", "Collagen stimulation", "Wrinkle reduction"],
      starIngredients: { "Renewal": ["Encapsulated Retinol"], "Soothing": ["Bisabolol", "Centella Asiatica"] },
      keyIngredients: ["Encapsulated Retinol 0.5%", "Bisabolol", "Centella Asiatica"],
      activeIngredients: ["Retinol", "Bisabolol", "Madecassoside"],
      skinTypes: ["Normal", "Oily", "Mature"],
      size: "30ml",
      usageInstructions: "Apply pea-sized amount to clean skin at night. Start with 2-3 times per week.",
      pH: "5.8",
      zoneAction: ["Rejuvenation", "Anti-inflammatory"],
      imageUrl: undefined,
      ingredients: ["Aqua", "Caprylic/Capric Triglyceride", "Retinol", "Bisabolol", "Centella Asiatica Extract"],
    },
    {
      name: "Hydrating Barrier Cream",
      category: "Moisturizer",
      type: "retail",
      description: "A rich, nourishing cream that strengthens the skin barrier and provides long-lasting hydration.",
      mainFunctions: ["Barrier repair", "Deep hydration", "Soothing"],
      starIngredients: { "Barrier": ["Ceramides", "Cholesterol"], "Hydration": ["Hyaluronic Acid", "Squalane"] },
      keyIngredients: ["Ceramide Complex", "Hyaluronic Acid", "Squalane"],
      activeIngredients: ["Ceramide NP", "Ceramide AP", "Sodium Hyaluronate", "Squalane"],
      skinTypes: ["Dry", "Sensitive", "Normal"],
      size: "50ml",
      usageInstructions: "Apply to face and neck morning and evening as the final step in your routine.",
      pH: "5.5",
      zoneAction: ["Anti-inflammatory"],
      imageUrl: undefined,
      ingredients: ["Aqua", "Squalane", "Glycerin", "Ceramide NP", "Ceramide AP", "Sodium Hyaluronate", "Cholesterol"],
    },
    {
      name: "AHA/BHA Exfoliating Solution",
      category: "Exfoliant",
      type: "professional",
      description: "A professional-strength exfoliating solution combining glycolic and salicylic acids for comprehensive skin renewal.",
      mainFunctions: ["Exfoliation", "Pore clearing", "Texture refinement"],
      starIngredients: { "Exfoliation": ["Glycolic Acid", "Salicylic Acid"], "Soothing": ["Green Tea Extract"] },
      keyIngredients: ["Glycolic Acid 10%", "Salicylic Acid 2%", "Green Tea Extract"],
      activeIngredients: ["Glycolic Acid", "Salicylic Acid", "Camellia Sinensis Extract"],
      skinTypes: ["Oily", "Combination", "Acne-prone"],
      size: "100ml",
      usageInstructions: "Apply to clean skin 2-3 times per week. Leave on for 10 minutes, then rinse.",
      pH: "3.5",
      zoneAction: ["Rejuvenation"],
      imageUrl: undefined,
      ingredients: ["Aqua", "Glycolic Acid", "Salicylic Acid", "Camellia Sinensis Leaf Extract", "Sodium Hydroxide"],
    },
    {
      name: "Peptide Firming Complex",
      category: "Serum",
      type: "professional",
      description: "An advanced peptide complex that targets multiple signs of aging for firmer, more youthful-looking skin.",
      mainFunctions: ["Firming", "Wrinkle reduction", "Elasticity improvement"],
      starIngredients: { "Peptides": ["Matrixyl 3000", "Argireline"], "Support": ["Hyaluronic Acid"] },
      keyIngredients: ["Matrixyl 3000", "Argireline", "Copper Peptides"],
      activeIngredients: ["Palmitoyl Tripeptide-1", "Palmitoyl Tetrapeptide-7", "Acetyl Hexapeptide-8", "Copper Tripeptide-1"],
      skinTypes: ["All skin types", "Mature"],
      size: "30ml",
      usageInstructions: "Apply to face and neck morning and evening before moisturizer.",
      pH: "6.0",
      zoneAction: ["Rejuvenation", "Anti-inflammatory"],
      imageUrl: undefined,
      ingredients: ["Aqua", "Glycerin", "Palmitoyl Tripeptide-1", "Palmitoyl Tetrapeptide-7", "Acetyl Hexapeptide-8"],
    },
    {
      name: "Daily Defense SPF 50",
      category: "Sunscreen",
      type: "retail",
      description: "A lightweight, broad-spectrum sunscreen with antioxidant protection for daily use.",
      mainFunctions: ["UV protection", "Antioxidant defense", "Hydration"],
      starIngredients: { "Protection": ["Zinc Oxide", "Titanium Dioxide"], "Antioxidants": ["Vitamin E", "Green Tea"] },
      keyIngredients: ["Zinc Oxide", "Titanium Dioxide", "Vitamin E"],
      activeIngredients: ["Zinc Oxide 15%", "Titanium Dioxide 5%", "Tocopherol"],
      skinTypes: ["All skin types"],
      size: "50ml",
      usageInstructions: "Apply liberally 15 minutes before sun exposure. Reapply every 2 hours.",
      pH: "6.5",
      zoneAction: ["Anti-oxidant"],
      imageUrl: undefined,
      ingredients: ["Aqua", "Zinc Oxide", "Titanium Dioxide", "Caprylic/Capric Triglyceride", "Tocopherol"],
    },
    {
      name: "Calming Recovery Mask",
      category: "Mask",
      type: "retail",
      description: "A soothing mask with centella asiatica and aloe vera to calm irritated skin and reduce redness.",
      mainFunctions: ["Calming", "Redness reduction", "Barrier support"],
      starIngredients: { "Calming": ["Centella Asiatica", "Aloe Vera"], "Healing": ["Madecassoside", "Allantoin"] },
      keyIngredients: ["Centella Asiatica Extract", "Aloe Vera", "Allantoin"],
      activeIngredients: ["Madecassoside", "Asiaticoside", "Allantoin", "Bisabolol"],
      skinTypes: ["Sensitive", "Irritated", "All skin types"],
      size: "75ml",
      usageInstructions: "Apply a thick layer to clean skin. Leave for 15-20 minutes, then rinse or tissue off.",
      pH: "5.5",
      zoneAction: ["Anti-inflammatory"],
      imageUrl: undefined,
      ingredients: ["Aqua", "Aloe Barbadensis Leaf Juice", "Centella Asiatica Extract", "Allantoin", "Bisabolol"],
    },
  ];

  sampleProducts.forEach((product) => {
    const id = productIdCounter++;
    productsStore.set(id, { ...product, id });
  });
}

// Initialize on module load
initializeSampleProducts();

export interface ProductFilters {
  category?: string;
  type?: "professional" | "retail";
  skinType?: string;
  concern?: string;
  zone?: ZoneType;
  search?: string;
  limit?: number;
  offset?: number;
}

export interface ProductsResult {
  products: Product[];
  total: number;
}

export interface ProductWithZoneAnalysis extends Product {
  zoneAnalysis: ZoneProductScore;
  primaryZone: ZoneType;
  zoneCompatibility: ZoneType[];
}

export class ProductsService {
  async getProducts(filters: ProductFilters): Promise<ProductsResult> {
    let products = Array.from(productsStore.values());

    // Apply filters
    if (filters.category) {
      products = products.filter((p) => 
        p.category.toLowerCase() === filters.category!.toLowerCase()
      );
    }

    if (filters.type) {
      products = products.filter((p) => p.type === filters.type);
    }

    if (filters.skinType) {
      products = products.filter((p) =>
        p.skinTypes?.some((t) => 
          t.toLowerCase().includes(filters.skinType!.toLowerCase()) ||
          t.toLowerCase() === "all skin types"
        )
      );
    }

    if (filters.zone) {
      products = products.filter((p) => {
        const analysis = zoneConcept.analyzeProductZoneActions(p);
        const primaryZone = zoneConcept.getPrimaryZone(p);
        return primaryZone === filters.zone;
      });
    }

    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      products = products.filter((p) =>
        p.name.toLowerCase().includes(searchLower) ||
        p.description.toLowerCase().includes(searchLower) ||
        p.category.toLowerCase().includes(searchLower)
      );
    }

    const total = products.length;

    // Apply pagination
    const limit = filters.limit || 50;
    const offset = filters.offset || 0;
    products = products.slice(offset, offset + limit);

    return { products, total };
  }

  async getProductById(id: number): Promise<ProductWithZoneAnalysis | null> {
    const product = productsStore.get(id);
    if (!product) return null;

    const zoneAnalysis = zoneConcept.analyzeProductZoneActions(product);
    const primaryZone = zoneConcept.getPrimaryZone(product);
    const zoneCompatibility = zoneConcept.getZoneCompatibility(product);

    return {
      ...product,
      zoneAnalysis,
      primaryZone,
      zoneCompatibility,
    };
  }

  async getCategories(): Promise<string[]> {
    const categories = new Set<string>();
    productsStore.forEach((product) => {
      categories.add(product.category);
    });
    return Array.from(categories).sort();
  }

  async searchProducts(query: string): Promise<Product[]> {
    const queryLower = query.toLowerCase();
    return Array.from(productsStore.values()).filter((product) =>
      product.name.toLowerCase().includes(queryLower) ||
      product.description.toLowerCase().includes(queryLower) ||
      product.keyIngredients?.some((i) => i.toLowerCase().includes(queryLower)) ||
      product.mainFunctions?.some((f) => f.toLowerCase().includes(queryLower))
    );
  }

  async getRecommendations(
    skinType: string,
    concerns: string[],
    goals: string[]
  ): Promise<ProductRecommendation[]> {
    const products = Array.from(productsStore.values());
    return recommendationEngine.generateSmartRecommendations(
      products,
      skinType,
      concerns,
      goals
    );
  }

  async getProductZoneAnalysis(id: number): Promise<{
    product: Product;
    zoneScores: ZoneProductScore;
    primaryZone: ZoneType;
    compatibility: ZoneType[];
    recommendations: string[];
  } | null> {
    const product = productsStore.get(id);
    if (!product) return null;

    const zoneScores = zoneConcept.analyzeProductZoneActions(product);
    const primaryZone = zoneConcept.getPrimaryZone(product);
    const compatibility = zoneConcept.getZoneCompatibility(product);
    
    const recommendations: string[] = [];
    if (zoneScores.antiInflammatory < 50) {
      recommendations.push("Consider pairing with calming products for sensitive skin");
    }
    if (zoneScores.antiOxidant < 50) {
      recommendations.push("Add antioxidant protection for comprehensive care");
    }
    if (zoneScores.rejuvenation < 50) {
      recommendations.push("Combine with renewal products for anti-aging benefits");
    }

    return {
      product,
      zoneScores,
      primaryZone,
      compatibility,
      recommendations,
    };
  }

  async getProductSynergies(id: number): Promise<{
    product: Product;
    synergisticProducts: Array<{
      product: Product;
      synergyScore: number;
      benefits: string[];
    }>;
  } | null> {
    const product = productsStore.get(id);
    if (!product) return null;

    const allProducts = Array.from(productsStore.values()).filter((p) => p.id !== id);
    const synergies = recommendationEngine.analyzeProductSynergies([product, ...allProducts]);

    const synergisticProducts = synergies
      .filter((s) => s.product1.id === id || s.product2.id === id)
      .map((s) => ({
        product: s.product1.id === id ? s.product2 : s.product1,
        synergyScore: s.synergyScore,
        benefits: s.benefits,
      }))
      .slice(0, 5);

    return {
      product,
      synergisticProducts,
    };
  }
}
