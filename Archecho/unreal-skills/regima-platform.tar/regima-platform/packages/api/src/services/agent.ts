/**
 * Agent Service
 * AI-powered consultation and recommendation engine
 */

import { 
  ZoneConcept, 
  RecommendationEngine, 
  type ZoneType,
  type Product,
  getIngredientsForConcern,
  getIngredientsForSkinType,
  ingredientsCatalog,
} from "@regima/core";

const zoneConcept = new ZoneConcept();
const recommendationEngine = new RecommendationEngine();

// Sample products for recommendations (in production, this would come from database)
const sampleProducts: Product[] = [
  {
    id: 1,
    name: "Gentle Cleansing Gel",
    category: "Cleanser",
    type: "retail",
    description: "A gentle, pH-balanced cleansing gel",
    mainFunctions: ["Deep cleansing", "pH balancing"],
    keyIngredients: ["Coco-Glucoside", "Aloe Vera"],
    activeIngredients: ["Glycerin", "Panthenol"],
    skinTypes: ["All skin types", "Sensitive"],
    size: "200ml",
    zoneAction: ["Anti-inflammatory"],
  },
  {
    id: 2,
    name: "Vitamin C Brightening Serum",
    category: "Serum",
    type: "retail",
    description: "Powerful antioxidant serum",
    mainFunctions: ["Brightening", "Antioxidant protection"],
    keyIngredients: ["L-Ascorbic Acid 15%", "Vitamin E"],
    activeIngredients: ["L-Ascorbic Acid", "Tocopherol", "Ferulic Acid"],
    skinTypes: ["Normal", "Oily", "Combination"],
    size: "30ml",
    zoneAction: ["Anti-oxidant", "Rejuvenation"],
  },
  {
    id: 3,
    name: "Hydrating Barrier Cream",
    category: "Moisturizer",
    type: "retail",
    description: "Rich, nourishing cream",
    mainFunctions: ["Barrier repair", "Deep hydration"],
    keyIngredients: ["Ceramide Complex", "Hyaluronic Acid"],
    activeIngredients: ["Ceramide NP", "Sodium Hyaluronate"],
    skinTypes: ["Dry", "Sensitive", "Normal"],
    size: "50ml",
    zoneAction: ["Anti-inflammatory"],
  },
];

export interface ConsultationInput {
  skinType: string;
  skinConcerns: string[];
  goals?: string[];
  currentProducts?: string[];
  lifestyle?: {
    sunExposure?: "low" | "moderate" | "high";
    stressLevel?: "low" | "moderate" | "high";
    sleepQuality?: "poor" | "fair" | "good";
    diet?: "poor" | "fair" | "good";
    waterIntake?: "low" | "moderate" | "high";
  };
  budget?: "budget" | "moderate" | "premium";
  preferences?: {
    preferNatural?: boolean;
    fragranceFree?: boolean;
    veganOnly?: boolean;
  };
}

export interface ConsultationResult {
  summary: string;
  skinAnalysis: {
    type: string;
    concerns: string[];
    primaryNeeds: string[];
  };
  zoneRecommendations: {
    spa: { score: number; priority: string; focus: string[] };
    zon: { score: number; priority: string; focus: string[] };
    med: { score: number; priority: string; focus: string[] };
  };
  productRecommendations: Array<{
    product: Product;
    matchScore: number;
    reasons: string[];
    usage: string;
  }>;
  ingredientRecommendations: Array<{
    name: string;
    benefits: string[];
    concentration: string;
  }>;
  routineSuggestion: {
    morning: string[];
    evening: string[];
    weekly: string[];
  };
  lifestyleAdvice: string[];
}

export interface RoutineInput {
  skinType: string;
  skinConcerns: string[];
  goals?: string[];
  routineType?: "minimal" | "standard" | "comprehensive";
  includeWeeklyTreatments?: boolean;
}

export interface RoutineResult {
  routineType: string;
  morning: Array<{
    step: number;
    category: string;
    purpose: string;
    suggestedProducts: string[];
    instructions: string;
  }>;
  evening: Array<{
    step: number;
    category: string;
    purpose: string;
    suggestedProducts: string[];
    instructions: string;
  }>;
  weekly?: Array<{
    treatment: string;
    frequency: string;
    purpose: string;
    instructions: string;
  }>;
  tips: string[];
}

export interface ZoneAnalysisInput {
  skinType: string;
  skinConcerns: string[];
  currentProducts?: string[];
}

export interface ZoneAnalysisResult {
  overallBalance: number;
  zones: {
    spa: {
      name: string;
      score: number;
      status: "deficient" | "balanced" | "excess";
      recommendations: string[];
    };
    zon: {
      name: string;
      score: number;
      status: "deficient" | "balanced" | "excess";
      recommendations: string[];
    };
    med: {
      name: string;
      score: number;
      status: "deficient" | "balanced" | "excess";
      recommendations: string[];
    };
  };
  priorityActions: string[];
  suggestedAdjustments: string[];
}

export class AgentService {
  async runConsultation(input: ConsultationInput): Promise<ConsultationResult> {
    const { skinType, skinConcerns, goals = [], lifestyle, preferences } = input;

    // Analyze skin needs
    const primaryNeeds = this.analyzePrimaryNeeds(skinType, skinConcerns);

    // Calculate zone priorities
    const zoneScores = this.calculateZoneScores(skinType, skinConcerns);

    // Get product recommendations
    const productRecs = recommendationEngine.generateSmartRecommendations(
      sampleProducts,
      skinType,
      skinConcerns,
      goals
    );

    // Get ingredient recommendations
    const ingredientRecs = this.getIngredientRecommendations(skinConcerns);

    // Generate routine suggestion
    const routineSuggestion = this.generateQuickRoutine(skinType, skinConcerns);

    // Generate lifestyle advice
    const lifestyleAdvice = this.generateLifestyleAdvice(lifestyle);

    return {
      summary: this.generateConsultationSummary(skinType, skinConcerns, zoneScores),
      skinAnalysis: {
        type: skinType,
        concerns: skinConcerns,
        primaryNeeds,
      },
      zoneRecommendations: {
        spa: {
          score: zoneScores.spa,
          priority: zoneScores.spa > 70 ? "high" : zoneScores.spa > 40 ? "medium" : "low",
          focus: this.getZoneFocus("spa", skinConcerns),
        },
        zon: {
          score: zoneScores.zon,
          priority: zoneScores.zon > 70 ? "high" : zoneScores.zon > 40 ? "medium" : "low",
          focus: this.getZoneFocus("zon", skinConcerns),
        },
        med: {
          score: zoneScores.med,
          priority: zoneScores.med > 70 ? "high" : zoneScores.med > 40 ? "medium" : "low",
          focus: this.getZoneFocus("med", skinConcerns),
        },
      },
      productRecommendations: productRecs.slice(0, 5).map((rec) => ({
        product: rec.product,
        matchScore: rec.matchScore,
        reasons: rec.reasons,
        usage: this.getProductUsage(rec.product),
      })),
      ingredientRecommendations: ingredientRecs,
      routineSuggestion,
      lifestyleAdvice,
    };
  }

  async generateRoutine(input: RoutineInput): Promise<RoutineResult> {
    const { skinType, skinConcerns, routineType = "standard", includeWeeklyTreatments = true } = input;

    const morning = this.buildMorningRoutine(skinType, skinConcerns, routineType);
    const evening = this.buildEveningRoutine(skinType, skinConcerns, routineType);
    const weekly = includeWeeklyTreatments
      ? this.buildWeeklyTreatments(skinType, skinConcerns)
      : undefined;

    return {
      routineType,
      morning,
      evening,
      weekly,
      tips: this.getRoutineTips(skinType, skinConcerns),
    };
  }

  async analyzeZones(input: ZoneAnalysisInput): Promise<ZoneAnalysisResult> {
    const { skinType, skinConcerns } = input;

    const scores = this.calculateZoneScores(skinType, skinConcerns);

    const getStatus = (score: number): "deficient" | "balanced" | "excess" => {
      if (score < 40) return "deficient";
      if (score > 80) return "excess";
      return "balanced";
    };

    const overallBalance = Math.round((scores.spa + scores.zon + scores.med) / 3);

    return {
      overallBalance,
      zones: {
        spa: {
          name: "Anti-inflammatory",
          score: scores.spa,
          status: getStatus(scores.spa),
          recommendations: this.getZoneRecommendations("spa", getStatus(scores.spa)),
        },
        zon: {
          name: "Anti-oxidant",
          score: scores.zon,
          status: getStatus(scores.zon),
          recommendations: this.getZoneRecommendations("zon", getStatus(scores.zon)),
        },
        med: {
          name: "Rejuvenation",
          score: scores.med,
          status: getStatus(scores.med),
          recommendations: this.getZoneRecommendations("med", getStatus(scores.med)),
        },
      },
      priorityActions: this.getPriorityActions(scores, skinConcerns),
      suggestedAdjustments: this.getSuggestedAdjustments(scores),
    };
  }

  async findProductMatches(criteria: {
    skinType: string;
    concerns: string[];
    zone?: ZoneType;
    category?: string;
  }): Promise<Array<{ product: Product; matchScore: number; reasons: string[] }>> {
    let products = [...sampleProducts];

    if (criteria.category) {
      products = products.filter((p) =>
        p.category.toLowerCase() === criteria.category!.toLowerCase()
      );
    }

    if (criteria.zone) {
      products = products.filter((p) =>
        zoneConcept.getPrimaryZone(p) === criteria.zone
      );
    }

    return recommendationEngine
      .generateSmartRecommendations(products, criteria.skinType, criteria.concerns, [])
      .slice(0, 10);
  }

  async getIngredientAdvice(input: {
    concerns: string[];
    skinType?: string;
    avoidIngredients: string[];
  }): Promise<{
    recommended: Array<{ name: string; benefits: string[]; forConcerns: string[] }>;
    toAvoid: Array<{ name: string; reason: string }>;
    tips: string[];
  }> {
    const recommended: Array<{ name: string; benefits: string[]; forConcerns: string[] }> = [];

    for (const concern of input.concerns) {
      const ingredients = getIngredientsForConcern(concern);
      for (const ing of ingredients.slice(0, 3)) {
        if (!input.avoidIngredients.includes(ing.name)) {
          const existing = recommended.find((r) => r.name === ing.name);
          if (existing) {
            existing.forConcerns.push(concern);
          } else {
            recommended.push({
              name: ing.name,
              benefits: ing.benefits,
              forConcerns: [concern],
            });
          }
        }
      }
    }

    const toAvoid = this.getIngredientsToAvoid(input.skinType, input.concerns);

    return {
      recommended: recommended.slice(0, 10),
      toAvoid,
      tips: this.getIngredientTips(input.skinType, input.concerns),
    };
  }

  getZoneInfo(): {
    zones: Array<{
      id: ZoneType;
      name: string;
      description: string;
      keyIngredients: string[];
      benefits: string[];
    }>;
    philosophy: string;
  } {
    return {
      zones: [
        {
          id: "spa",
          name: "SPA Zone - Anti-inflammatory",
          description: "Focus on calming, soothing, and reducing inflammation. Essential for maintaining skin health and barrier function.",
          keyIngredients: ["Centella Asiatica", "Niacinamide", "Bisabolol", "Aloe Vera", "Chamomile"],
          benefits: ["Reduces redness", "Calms irritation", "Strengthens barrier", "Soothes sensitivity"],
        },
        {
          id: "zon",
          name: "ZON Zone - Anti-oxidant",
          description: "Protection against environmental damage and free radicals. Prevents premature aging and maintains skin vitality.",
          keyIngredients: ["Vitamin C", "Vitamin E", "Ferulic Acid", "Resveratrol", "Green Tea"],
          benefits: ["Neutralizes free radicals", "Protects from UV damage", "Brightens skin", "Prevents aging"],
        },
        {
          id: "med",
          name: "MED Zone - Rejuvenation",
          description: "Active renewal and regeneration. Stimulates collagen production and accelerates cell turnover.",
          keyIngredients: ["Retinol", "Peptides", "AHAs", "BHAs", "Growth Factors"],
          benefits: ["Stimulates collagen", "Accelerates renewal", "Reduces wrinkles", "Improves texture"],
        },
      ],
      philosophy: "The Zone Concept is built on the principle that optimal skin health requires a balance of three key pillars: calming inflammation, protecting against oxidative damage, and promoting cellular renewal. By addressing all three zones, we create a comprehensive approach to skincare that delivers visible, lasting results.",
    };
  }

  getSkinTypesInfo(): Array<{
    type: string;
    characteristics: string[];
    commonConcerns: string[];
    recommendedIngredients: string[];
    ingredientsToAvoid: string[];
  }> {
    return [
      {
        type: "Normal",
        characteristics: ["Balanced oil production", "Small pores", "Even texture", "Good elasticity"],
        commonConcerns: ["Maintaining balance", "Prevention"],
        recommendedIngredients: ["Hyaluronic Acid", "Vitamin C", "Niacinamide"],
        ingredientsToAvoid: ["Heavy oils in excess"],
      },
      {
        type: "Dry",
        characteristics: ["Tight feeling", "Flakiness", "Visible fine lines", "Dull appearance"],
        commonConcerns: ["Dehydration", "Flakiness", "Sensitivity"],
        recommendedIngredients: ["Ceramides", "Hyaluronic Acid", "Squalane", "Glycerin"],
        ingredientsToAvoid: ["Alcohol denat", "Strong acids", "Harsh sulfates"],
      },
      {
        type: "Oily",
        characteristics: ["Shiny appearance", "Enlarged pores", "Prone to breakouts", "Thick texture"],
        commonConcerns: ["Excess oil", "Acne", "Enlarged pores"],
        recommendedIngredients: ["Niacinamide", "Salicylic Acid", "Clay", "Zinc"],
        ingredientsToAvoid: ["Heavy oils", "Comedogenic ingredients"],
      },
      {
        type: "Combination",
        characteristics: ["Oily T-zone", "Dry cheeks", "Mixed concerns"],
        commonConcerns: ["Balancing different areas", "Pores in T-zone"],
        recommendedIngredients: ["Niacinamide", "Hyaluronic Acid", "Light moisturizers"],
        ingredientsToAvoid: ["Very heavy products"],
      },
      {
        type: "Sensitive",
        characteristics: ["Easily irritated", "Redness", "Reactive to products", "Thin skin"],
        commonConcerns: ["Redness", "Irritation", "Barrier damage"],
        recommendedIngredients: ["Centella Asiatica", "Aloe Vera", "Ceramides", "Oat extract"],
        ingredientsToAvoid: ["Fragrance", "Essential oils", "Strong acids", "Alcohol"],
      },
    ];
  }

  getSkinConcerns(): Array<{
    concern: string;
    description: string;
    primaryZone: ZoneType;
    keyIngredients: string[];
  }> {
    return [
      {
        concern: "Acne",
        description: "Breakouts, pimples, and blemishes caused by excess oil and bacteria",
        primaryZone: "med",
        keyIngredients: ["Salicylic Acid", "Benzoyl Peroxide", "Niacinamide", "Tea Tree"],
      },
      {
        concern: "Aging",
        description: "Fine lines, wrinkles, and loss of firmness",
        primaryZone: "med",
        keyIngredients: ["Retinol", "Peptides", "Vitamin C", "Hyaluronic Acid"],
      },
      {
        concern: "Pigmentation",
        description: "Dark spots, uneven skin tone, and hyperpigmentation",
        primaryZone: "zon",
        keyIngredients: ["Vitamin C", "Niacinamide", "Alpha Arbutin", "Tranexamic Acid"],
      },
      {
        concern: "Dehydration",
        description: "Lack of water in the skin causing tightness and dullness",
        primaryZone: "spa",
        keyIngredients: ["Hyaluronic Acid", "Glycerin", "Ceramides", "Squalane"],
      },
      {
        concern: "Sensitivity",
        description: "Easily irritated skin prone to redness and reactions",
        primaryZone: "spa",
        keyIngredients: ["Centella Asiatica", "Aloe Vera", "Bisabolol", "Allantoin"],
      },
      {
        concern: "Dullness",
        description: "Lack of radiance and glow",
        primaryZone: "zon",
        keyIngredients: ["Vitamin C", "AHAs", "Niacinamide", "Exfoliating acids"],
      },
      {
        concern: "Large Pores",
        description: "Visibly enlarged pores, often in T-zone",
        primaryZone: "med",
        keyIngredients: ["Niacinamide", "Salicylic Acid", "Retinol", "Clay"],
      },
      {
        concern: "Redness",
        description: "Persistent redness or flushing",
        primaryZone: "spa",
        keyIngredients: ["Centella Asiatica", "Azelaic Acid", "Niacinamide", "Green Tea"],
      },
    ];
  }

  // Private helper methods

  private analyzePrimaryNeeds(skinType: string, concerns: string[]): string[] {
    const needs: string[] = [];

    if (skinType.toLowerCase() === "dry") {
      needs.push("Hydration", "Barrier repair");
    } else if (skinType.toLowerCase() === "oily") {
      needs.push("Oil control", "Pore refinement");
    } else if (skinType.toLowerCase() === "sensitive") {
      needs.push("Calming", "Barrier protection");
    }

    if (concerns.includes("acne")) needs.push("Antibacterial treatment");
    if (concerns.includes("aging")) needs.push("Collagen stimulation");
    if (concerns.includes("pigmentation")) needs.push("Brightening");

    return [...new Set(needs)];
  }

  private calculateZoneScores(skinType: string, concerns: string[]): { spa: number; zon: number; med: number } {
    let spa = 50, zon = 50, med = 50;

    // Adjust based on skin type
    if (skinType.toLowerCase() === "sensitive") spa += 30;
    if (skinType.toLowerCase() === "oily") med += 20;
    if (skinType.toLowerCase() === "dry") spa += 20;

    // Adjust based on concerns
    for (const concern of concerns) {
      const lowerConcern = concern.toLowerCase();
      if (["redness", "sensitivity", "irritation"].includes(lowerConcern)) spa += 15;
      if (["dullness", "pigmentation", "sun damage"].includes(lowerConcern)) zon += 15;
      if (["aging", "acne", "texture"].includes(lowerConcern)) med += 15;
    }

    return {
      spa: Math.min(100, spa),
      zon: Math.min(100, zon),
      med: Math.min(100, med),
    };
  }

  private getZoneFocus(zone: ZoneType, concerns: string[]): string[] {
    const focusMap: Record<ZoneType, Record<string, string>> = {
      spa: {
        redness: "Reduce inflammation and calm redness",
        sensitivity: "Strengthen barrier and reduce reactivity",
        dehydration: "Restore moisture balance",
      },
      zon: {
        pigmentation: "Inhibit melanin production",
        dullness: "Boost radiance and brightness",
        "sun damage": "Repair oxidative damage",
      },
      med: {
        aging: "Stimulate collagen and elastin",
        acne: "Accelerate cell turnover",
        texture: "Refine skin surface",
      },
    };

    return concerns
      .map((c) => focusMap[zone][c.toLowerCase()])
      .filter(Boolean);
  }

  private getIngredientRecommendations(concerns: string[]): Array<{
    name: string;
    benefits: string[];
    concentration: string;
  }> {
    const recommendations: Array<{ name: string; benefits: string[]; concentration: string }> = [];

    for (const concern of concerns) {
      const ingredients = getIngredientsForConcern(concern);
      for (const ing of ingredients.slice(0, 2)) {
        if (!recommendations.find((r) => r.name === ing.name)) {
          recommendations.push({
            name: ing.name,
            benefits: ing.benefits,
            concentration: ing.concentration,
          });
        }
      }
    }

    return recommendations.slice(0, 8);
  }

  private generateQuickRoutine(skinType: string, concerns: string[]): {
    morning: string[];
    evening: string[];
    weekly: string[];
  } {
    return {
      morning: [
        "Gentle cleanser",
        "Antioxidant serum (Vitamin C)",
        "Lightweight moisturizer",
        "SPF 50 sunscreen",
      ],
      evening: [
        "Double cleanse (oil + water-based)",
        "Treatment serum (based on concerns)",
        "Nourishing moisturizer",
        "Eye cream (optional)",
      ],
      weekly: [
        "Exfoliation (1-2x per week)",
        "Hydrating mask",
        "Treatment mask (if needed)",
      ],
    };
  }

  private generateLifestyleAdvice(lifestyle?: ConsultationInput["lifestyle"]): string[] {
    const advice: string[] = [];

    if (!lifestyle) {
      return [
        "Stay hydrated by drinking at least 8 glasses of water daily",
        "Get 7-8 hours of quality sleep",
        "Protect your skin from sun exposure",
        "Maintain a balanced diet rich in antioxidants",
      ];
    }

    if (lifestyle.sunExposure === "high") {
      advice.push("Increase sun protection - use SPF 50+ and reapply every 2 hours");
    }
    if (lifestyle.stressLevel === "high") {
      advice.push("Consider stress-management techniques as stress can trigger skin issues");
    }
    if (lifestyle.sleepQuality === "poor") {
      advice.push("Prioritize sleep - skin repairs itself during rest");
    }
    if (lifestyle.waterIntake === "low") {
      advice.push("Increase water intake to at least 8 glasses daily for skin hydration");
    }

    return advice;
  }

  private generateConsultationSummary(
    skinType: string,
    concerns: string[],
    zoneScores: { spa: number; zon: number; med: number }
  ): string {
    const primaryZone = Object.entries(zoneScores).reduce((a, b) =>
      a[1] > b[1] ? a : b
    )[0];

    const zoneNames: Record<string, string> = {
      spa: "anti-inflammatory",
      zon: "antioxidant protection",
      med: "rejuvenation",
    };

    return `Based on your ${skinType} skin type and concerns (${concerns.join(", ")}), your skincare routine should prioritize ${zoneNames[primaryZone]}. A balanced approach addressing all three zones will help achieve optimal skin health.`;
  }

  private getProductUsage(product: Product): string {
    const categoryUsage: Record<string, string> = {
      Cleanser: "Use morning and evening on damp skin",
      Serum: "Apply 2-3 drops after cleansing, before moisturizer",
      Moisturizer: "Apply as final step morning and evening",
      Treatment: "Use as directed, typically in the evening",
      Sunscreen: "Apply as final step in morning routine",
      Mask: "Use 1-2 times per week",
      Exfoliant: "Use 2-3 times per week in the evening",
    };

    return categoryUsage[product.category] || "Follow product instructions";
  }

  private buildMorningRoutine(
    skinType: string,
    concerns: string[],
    routineType: string
  ): RoutineResult["morning"] {
    const routine: RoutineResult["morning"] = [
      {
        step: 1,
        category: "Cleanser",
        purpose: "Remove overnight buildup and prepare skin",
        suggestedProducts: ["Gentle Cleansing Gel"],
        instructions: "Massage onto damp skin for 60 seconds, rinse thoroughly",
      },
      {
        step: 2,
        category: "Serum",
        purpose: "Deliver antioxidant protection",
        suggestedProducts: ["Vitamin C Brightening Serum"],
        instructions: "Apply 2-3 drops to face and neck, allow to absorb",
      },
      {
        step: 3,
        category: "Moisturizer",
        purpose: "Hydrate and protect skin barrier",
        suggestedProducts: ["Hydrating Barrier Cream"],
        instructions: "Apply evenly to face and neck",
      },
      {
        step: 4,
        category: "Sunscreen",
        purpose: "Protect from UV damage",
        suggestedProducts: ["Daily Defense SPF 50"],
        instructions: "Apply generously as final step, reapply every 2 hours if outdoors",
      },
    ];

    if (routineType === "minimal") {
      return routine.filter((s) => [1, 3, 4].includes(s.step));
    }

    return routine;
  }

  private buildEveningRoutine(
    skinType: string,
    concerns: string[],
    routineType: string
  ): RoutineResult["evening"] {
    const routine: RoutineResult["evening"] = [
      {
        step: 1,
        category: "Cleanser",
        purpose: "Remove makeup, sunscreen, and daily buildup",
        suggestedProducts: ["Gentle Cleansing Gel"],
        instructions: "Double cleanse if wearing makeup - oil cleanser first, then water-based",
      },
      {
        step: 2,
        category: "Treatment Serum",
        purpose: "Address specific skin concerns",
        suggestedProducts: ["Retinol Night Treatment", "Peptide Firming Complex"],
        instructions: "Apply to clean skin, allow to absorb before next step",
      },
      {
        step: 3,
        category: "Moisturizer",
        purpose: "Nourish and repair overnight",
        suggestedProducts: ["Hydrating Barrier Cream"],
        instructions: "Apply generous layer to seal in treatments",
      },
    ];

    if (routineType === "minimal") {
      return routine.filter((s) => [1, 3].includes(s.step));
    }

    return routine;
  }

  private buildWeeklyTreatments(
    skinType: string,
    concerns: string[]
  ): RoutineResult["weekly"] {
    return [
      {
        treatment: "Exfoliation",
        frequency: "1-2 times per week",
        purpose: "Remove dead skin cells and improve texture",
        instructions: "Use AHA/BHA exfoliant in the evening, follow with hydrating products",
      },
      {
        treatment: "Hydrating Mask",
        frequency: "1-2 times per week",
        purpose: "Boost hydration and nourishment",
        instructions: "Apply thick layer, leave for 15-20 minutes, rinse or tissue off",
      },
    ];
  }

  private getRoutineTips(skinType: string, concerns: string[]): string[] {
    const tips = [
      "Always apply products from thinnest to thickest consistency",
      "Wait 30 seconds between layers for better absorption",
      "Patch test new products before full application",
      "Be consistent - results take 4-6 weeks to show",
    ];

    if (skinType.toLowerCase() === "sensitive") {
      tips.push("Introduce new products one at a time");
    }

    return tips;
  }

  private getZoneRecommendations(zone: ZoneType, status: string): string[] {
    const recommendations: Record<ZoneType, Record<string, string[]>> = {
      spa: {
        deficient: [
          "Add calming ingredients like Centella Asiatica",
          "Use fragrance-free products",
          "Incorporate barrier-repair ingredients",
        ],
        balanced: ["Maintain current anti-inflammatory products"],
        excess: ["Reduce soothing products if skin is not reactive"],
      },
      zon: {
        deficient: [
          "Add Vitamin C serum to morning routine",
          "Incorporate antioxidant-rich products",
          "Ensure adequate sun protection",
        ],
        balanced: ["Continue antioxidant protection"],
        excess: ["Balance with other zone products"],
      },
      med: {
        deficient: [
          "Consider adding retinol (start low, go slow)",
          "Incorporate peptides for collagen support",
          "Add gentle exfoliation",
        ],
        balanced: ["Maintain current renewal products"],
        excess: ["Reduce active treatments if experiencing irritation"],
      },
    };

    return recommendations[zone][status] || [];
  }

  private getPriorityActions(
    scores: { spa: number; zon: number; med: number },
    concerns: string[]
  ): string[] {
    const actions: string[] = [];

    const lowestZone = Object.entries(scores).reduce((a, b) =>
      a[1] < b[1] ? a : b
    );

    if (lowestZone[1] < 50) {
      const zoneNames: Record<string, string> = {
        spa: "anti-inflammatory",
        zon: "antioxidant",
        med: "rejuvenation",
      };
      actions.push(`Prioritize ${zoneNames[lowestZone[0]]} products`);
    }

    return actions;
  }

  private getSuggestedAdjustments(scores: { spa: number; zon: number; med: number }): string[] {
    const adjustments: string[] = [];

    if (scores.spa < 40) {
      adjustments.push("Add calming products to your routine");
    }
    if (scores.zon < 40) {
      adjustments.push("Increase antioxidant protection");
    }
    if (scores.med < 40) {
      adjustments.push("Consider adding renewal treatments");
    }

    return adjustments;
  }

  private getIngredientsToAvoid(
    skinType?: string,
    concerns?: string[]
  ): Array<{ name: string; reason: string }> {
    const toAvoid: Array<{ name: string; reason: string }> = [];

    if (skinType?.toLowerCase() === "sensitive") {
      toAvoid.push(
        { name: "Fragrance", reason: "Can cause irritation in sensitive skin" },
        { name: "Alcohol denat", reason: "Can be drying and irritating" }
      );
    }

    if (concerns?.includes("acne")) {
      toAvoid.push(
        { name: "Coconut oil", reason: "Highly comedogenic" },
        { name: "Isopropyl myristate", reason: "Can clog pores" }
      );
    }

    return toAvoid;
  }

  private getIngredientTips(skinType?: string, concerns?: string[]): string[] {
    return [
      "Start with lower concentrations and increase gradually",
      "Some ingredients work better together (Vitamin C + E + Ferulic Acid)",
      "Avoid mixing retinol with AHAs/BHAs in the same routine",
      "Always use sunscreen when using photosensitizing ingredients",
    ];
  }
}
