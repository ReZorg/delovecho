/**
 * Modules Service
 * Business logic for training modules
 */

import type { Module, InsertModule, Lesson } from "@regima/core";

// In-memory storage for development (replace with database in production)
const modulesStore: Map<number, Module> = new Map();
const lessonsStore: Map<number, Lesson> = new Map();
let moduleIdCounter = 1;

// Initialize with sample data
function initializeSampleData(): void {
  if (modulesStore.size > 0) return;

  const sampleModules: Omit<Module, "id">[] = [
    {
      title: "Introduction to RegimA",
      description: "Learn the fundamentals of the RegimA skincare philosophy and the Zone Concept",
      estimatedTime: "45 minutes",
      order: 1,
    },
    {
      title: "Understanding Skin Types",
      description: "Deep dive into different skin types and how to identify them",
      estimatedTime: "60 minutes",
      order: 2,
    },
    {
      title: "The Zone Concept",
      description: "Master the three pillars: Anti-inflammatory, Anti-oxidant, and Rejuvenation",
      estimatedTime: "90 minutes",
      order: 3,
    },
    {
      title: "Product Knowledge",
      description: "Comprehensive overview of RegimA product lines and their applications",
      estimatedTime: "120 minutes",
      order: 4,
    },
    {
      title: "Ingredient Science",
      description: "Understanding active ingredients and their mechanisms of action",
      estimatedTime: "90 minutes",
      order: 5,
    },
    {
      title: "Consultation Techniques",
      description: "Learn how to conduct effective skincare consultations",
      estimatedTime: "75 minutes",
      order: 6,
    },
    {
      title: "Treatment Protocols",
      description: "Step-by-step professional treatment protocols",
      estimatedTime: "120 minutes",
      order: 7,
    },
    {
      title: "Advanced Techniques",
      description: "Advanced treatment methods and combination therapies",
      estimatedTime: "90 minutes",
      order: 8,
    },
  ];

  sampleModules.forEach((module) => {
    const id = moduleIdCounter++;
    modulesStore.set(id, { ...module, id });
  });
}

// Initialize on module load
initializeSampleData();

export interface ModuleWithLessons extends Module {
  lessons: Lesson[];
}

export class ModulesService {
  async getAllModules(): Promise<Module[]> {
    const modules = Array.from(modulesStore.values());
    return modules.sort((a, b) => a.order - b.order);
  }

  async getModuleById(id: number): Promise<ModuleWithLessons | null> {
    const module = modulesStore.get(id);
    if (!module) return null;

    const lessons = await this.getModuleLessons(id);
    return { ...module, lessons };
  }

  async getModuleLessons(moduleId: number): Promise<Lesson[]> {
    const lessons = Array.from(lessonsStore.values())
      .filter((lesson) => lesson.moduleId === moduleId)
      .sort((a, b) => a.order - b.order);
    return lessons;
  }

  async createModule(data: InsertModule): Promise<Module> {
    const id = moduleIdCounter++;
    const module: Module = { ...data, id };
    modulesStore.set(id, module);
    return module;
  }

  async updateModule(id: number, data: Partial<InsertModule>): Promise<Module | null> {
    const existing = modulesStore.get(id);
    if (!existing) return null;

    const updated: Module = { ...existing, ...data };
    modulesStore.set(id, updated);
    return updated;
  }

  async deleteModule(id: number): Promise<boolean> {
    return modulesStore.delete(id);
  }

  async getModuleCount(): Promise<number> {
    return modulesStore.size;
  }

  async searchModules(query: string): Promise<Module[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(modulesStore.values()).filter(
      (module) =>
        module.title.toLowerCase().includes(lowerQuery) ||
        module.description.toLowerCase().includes(lowerQuery)
    );
  }
}
