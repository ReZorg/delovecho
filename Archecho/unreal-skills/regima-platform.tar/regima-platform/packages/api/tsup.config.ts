import { defineConfig } from "tsup";

export default defineConfig({
  entry: ["src/index.ts", "src/bin/server.ts"],
  format: ["esm"],
  dts: false,
  splitting: false,
  sourcemap: true,
  clean: true,
  treeshake: true,
  external: [
    "@regima/core",
    "express",
    "express-session",
    "cors",
    "helmet",
    "morgan",
    "compression",
    "express-rate-limit",
    "ws",
    "memorystore",
    "zod",
    "zod-validation-error",
    "dotenv",
  ],
  outDir: "dist",
});
