/**
 * API Services Unit Tests
 */

import { describe, it, expect, beforeEach } from "vitest";

// Mock services for testing
class MockModulesService {
  private modules = [
    { id: 1, title: "Introduction to Skincare", description: "Learn the basics", order: 1 },
    { id: 2, title: "Understanding Skin Types", description: "Know your skin", order: 2 },
    { id: 3, title: "The Zone Concept", description: "Master the zones", order: 3 },
  ];

  async getAllModules() {
    return this.modules;
  }

  async getModuleById(id: number) {
    return this.modules.find((m) => m.id === id) || null;
  }

  async getModuleLessons(moduleId: number) {
    return [
      { id: 1, moduleId, title: "Lesson 1", order: 1 },
      { id: 2, moduleId, title: "Lesson 2", order: 2 },
    ];
  }

  async searchModules(query: string) {
    const lowerQuery = query.toLowerCase();
    return this.modules.filter(
      (m) =>
        m.title.toLowerCase().includes(lowerQuery) ||
        m.description.toLowerCase().includes(lowerQuery)
    );
  }
}

class MockProductsService {
  private products = [
    { id: 1, name: "Cleanser A", category: "Cleansers", type: "professional" },
    { id: 2, name: "Moisturizer B", category: "Moisturizers", type: "retail" },
    { id: 3, name: "Retinol Serum", category: "Serums", type: "professional" },
  ];

  async getAllProducts(filters?: { category?: string; type?: string }) {
    let result = this.products;
    if (filters?.category) {
      result = result.filter((p) => p.category === filters.category);
    }
    if (filters?.type) {
      result = result.filter((p) => p.type === filters.type);
    }
    return result;
  }

  async getProductById(id: number) {
    return this.products.find((p) => p.id === id) || null;
  }

  async searchProducts(query: string) {
    const lowerQuery = query.toLowerCase();
    return this.products.filter((p) => p.name.toLowerCase().includes(lowerQuery));
  }

  async getCategories() {
    return [...new Set(this.products.map((p) => p.category))];
  }
}

class MockProgressService {
  private progress: Map<number, any> = new Map();

  async getUserProgress(userId: number) {
    if (!this.progress.has(userId)) {
      this.progress.set(userId, {
        userId,
        modulesCompleted: 0,
        totalModules: 8,
        lessonsCompleted: 0,
        totalLessons: 24,
        averageScore: 0,
        totalTimeSpent: 0,
        currentStreak: 0,
        longestStreak: 0,
      });
    }
    return this.progress.get(userId);
  }

  async updateLessonProgress(data: {
    userId: number;
    lessonId: number;
    completed: boolean;
    score?: number;
  }) {
    const progress = await this.getUserProgress(data.userId);
    if (data.completed) {
      progress.lessonsCompleted++;
      if (data.score) {
        progress.averageScore = data.score;
      }
    }
    return { lessonId: data.lessonId, completed: data.completed, score: data.score };
  }

  async getUserAchievements(userId: number) {
    const progress = await this.getUserProgress(userId);
    const achievements = [];
    
    if (progress.lessonsCompleted >= 1) {
      achievements.push({ id: "first_lesson", name: "First Steps" });
    }
    if (progress.modulesCompleted >= 1) {
      achievements.push({ id: "first_module", name: "Module Master" });
    }
    
    return achievements;
  }
}

describe("ModulesService", () => {
  let service: MockModulesService;

  beforeEach(() => {
    service = new MockModulesService();
  });

  describe("getAllModules", () => {
    it("should return all modules", async () => {
      const modules = await service.getAllModules();

      expect(modules).toBeDefined();
      expect(modules.length).toBe(3);
    });

    it("should return modules in order", async () => {
      const modules = await service.getAllModules();

      for (let i = 1; i < modules.length; i++) {
        expect(modules[i].order).toBeGreaterThan(modules[i - 1].order);
      }
    });
  });

  describe("getModuleById", () => {
    it("should return a module by ID", async () => {
      const module = await service.getModuleById(1);

      expect(module).toBeDefined();
      expect(module?.id).toBe(1);
      expect(module?.title).toBe("Introduction to Skincare");
    });

    it("should return null for non-existent module", async () => {
      const module = await service.getModuleById(999);

      expect(module).toBeNull();
    });
  });

  describe("getModuleLessons", () => {
    it("should return lessons for a module", async () => {
      const lessons = await service.getModuleLessons(1);

      expect(lessons).toBeDefined();
      expect(lessons.length).toBeGreaterThan(0);
      expect(lessons.every((l) => l.moduleId === 1)).toBe(true);
    });
  });

  describe("searchModules", () => {
    it("should search modules by title", async () => {
      const results = await service.searchModules("skincare");

      expect(results).toBeDefined();
      expect(results.length).toBeGreaterThan(0);
    });

    it("should search modules by description", async () => {
      const results = await service.searchModules("basics");

      expect(results).toBeDefined();
      expect(results.length).toBeGreaterThan(0);
    });

    it("should return empty array for no matches", async () => {
      const results = await service.searchModules("nonexistent");

      expect(results).toEqual([]);
    });
  });
});

describe("ProductsService", () => {
  let service: MockProductsService;

  beforeEach(() => {
    service = new MockProductsService();
  });

  describe("getAllProducts", () => {
    it("should return all products", async () => {
      const products = await service.getAllProducts();

      expect(products).toBeDefined();
      expect(products.length).toBe(3);
    });

    it("should filter products by category", async () => {
      const products = await service.getAllProducts({ category: "Cleansers" });

      expect(products).toBeDefined();
      expect(products.every((p) => p.category === "Cleansers")).toBe(true);
    });

    it("should filter products by type", async () => {
      const products = await service.getAllProducts({ type: "professional" });

      expect(products).toBeDefined();
      expect(products.every((p) => p.type === "professional")).toBe(true);
    });
  });

  describe("getProductById", () => {
    it("should return a product by ID", async () => {
      const product = await service.getProductById(1);

      expect(product).toBeDefined();
      expect(product?.id).toBe(1);
    });

    it("should return null for non-existent product", async () => {
      const product = await service.getProductById(999);

      expect(product).toBeNull();
    });
  });

  describe("searchProducts", () => {
    it("should search products by name", async () => {
      const results = await service.searchProducts("cleanser");

      expect(results).toBeDefined();
      expect(results.length).toBeGreaterThan(0);
    });

    it("should be case-insensitive", async () => {
      const results = await service.searchProducts("CLEANSER");

      expect(results).toBeDefined();
      expect(results.length).toBeGreaterThan(0);
    });
  });

  describe("getCategories", () => {
    it("should return unique categories", async () => {
      const categories = await service.getCategories();

      expect(categories).toBeDefined();
      expect(categories.length).toBe(3);
      expect(new Set(categories).size).toBe(categories.length);
    });
  });
});

describe("ProgressService", () => {
  let service: MockProgressService;

  beforeEach(() => {
    service = new MockProgressService();
  });

  describe("getUserProgress", () => {
    it("should return progress for a user", async () => {
      const progress = await service.getUserProgress(1);

      expect(progress).toBeDefined();
      expect(progress.userId).toBe(1);
      expect(progress.modulesCompleted).toBeDefined();
      expect(progress.lessonsCompleted).toBeDefined();
    });

    it("should initialize progress for new user", async () => {
      const progress = await service.getUserProgress(999);

      expect(progress).toBeDefined();
      expect(progress.userId).toBe(999);
      expect(progress.modulesCompleted).toBe(0);
      expect(progress.lessonsCompleted).toBe(0);
    });
  });

  describe("updateLessonProgress", () => {
    it("should update lesson progress", async () => {
      const result = await service.updateLessonProgress({
        userId: 1,
        lessonId: 1,
        completed: true,
        score: 85,
      });

      expect(result).toBeDefined();
      expect(result.completed).toBe(true);
      expect(result.score).toBe(85);
    });

    it("should increment lessons completed count", async () => {
      const beforeProgress = await service.getUserProgress(1);
      const beforeCount = beforeProgress.lessonsCompleted;

      await service.updateLessonProgress({
        userId: 1,
        lessonId: 1,
        completed: true,
      });

      const afterProgress = await service.getUserProgress(1);
      expect(afterProgress.lessonsCompleted).toBe(beforeCount + 1);
    });
  });

  describe("getUserAchievements", () => {
    it("should return empty array for new user", async () => {
      const achievements = await service.getUserAchievements(999);

      expect(achievements).toEqual([]);
    });

    it("should return achievements based on progress", async () => {
      await service.updateLessonProgress({
        userId: 1,
        lessonId: 1,
        completed: true,
      });

      const achievements = await service.getUserAchievements(1);

      expect(achievements).toBeDefined();
      expect(achievements.some((a) => a.id === "first_lesson")).toBe(true);
    });
  });
});
