/**
 * @regima/core
 * 
 * Core domain models, schemas, and business logic for the RegimA platform.
 * This package provides the foundational types, database schemas, and
 * AI agent components for the SkinTwin Cognitive Alchemist Workbench.
 */

// Schema exports
export * from "./schema/index.js";

// Agent exports
export * from "./agent/index.js";

// Data exports
export * from "./data/index.js";

// Version
export const VERSION = "1.0.0";
