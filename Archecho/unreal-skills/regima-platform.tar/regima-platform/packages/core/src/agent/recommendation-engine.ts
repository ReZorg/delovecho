/**
 * REGIMA RECOMMENDATION ENGINE
 * Advanced matching algorithms for personalized skincare recommendations
 */

import type { Product, ZoneType } from "../schema/index.js";
import { ZoneConcept, type ZoneBalance, type ZoneRequirements } from "./zone-concept.js";

export interface SkincareRoutine {
  morning: RoutineStep[];
  evening: RoutineStep[];
  weekly: RoutineStep[];
  zoneBalance: ZoneBalance;
  estimatedCost?: string;
  expectedTimeline: string;
}

export interface RoutineStep {
  step: number;
  product: Product;
  amount: string;
  technique: string;
  waitTime?: string;
  tips: string[];
}

export interface ProductMatch {
  product: Product;
  matchScore: number;
  matchReasons: string[];
  concerns: string[];
  benefits: string[];
}

export interface ProductSynergy {
  product1: Product;
  product2: Product;
  synergyScore: number;
  benefits: string[];
  applicationOrder: string;
}

export interface ProductRecommendation {
  product: Product;
  priority: 'essential' | 'recommended' | 'optional';
  reasoning: string;
  applicationTime: 'morning' | 'evening' | 'both' | 'weekly';
  applicationOrder: number;
}

export interface SkincareAnalysis {
  skinType: string;
  primaryConcerns: string[];
  secondaryConcerns: string[];
  goals: string[];
  zoneRequirements: ZoneRequirements;
  recommendedCategories: string[];
}

// Severity weights for concern prioritization
const SEVERITY_WEIGHTS: Record<string, number> = {
  'acne': 10,
  'severe acne': 15,
  'cystic acne': 20,
  'rosacea': 15,
  'melasma': 12,
  'deep wrinkles': 12,
  'hyperpigmentation': 10,
  'sensitivity': 8,
  'dryness': 6,
  'oiliness': 5,
  'fine lines': 5,
  'dullness': 3,
  'dehydration': 7,
  'uneven texture': 6,
  'enlarged pores': 5
};

// Expected timeline for different concerns
const CONCERN_TIMELINES: Record<string, string> = {
  'acne': '6-12 weeks',
  'hyperpigmentation': '8-16 weeks',
  'fine lines': '8-12 weeks',
  'dryness': '2-4 weeks',
  'dullness': '4-6 weeks',
  'sensitivity': '4-8 weeks',
  'rosacea': '8-12 weeks',
  'aging': '12-24 weeks'
};

// Synergy pairs - ingredients that work well together
const SYNERGY_PAIRS: Array<{ ingredients: [string, string]; benefit: string }> = [
  { ingredients: ['vitamin c', 'vitamin e'], benefit: 'Enhanced antioxidant protection' },
  { ingredients: ['vitamin c', 'ferulic acid'], benefit: 'Stabilized vitamin C with boosted efficacy' },
  { ingredients: ['niacinamide', 'hyaluronic acid'], benefit: 'Improved hydration and barrier function' },
  { ingredients: ['retinol', 'peptides'], benefit: 'Comprehensive anti-aging support' },
  { ingredients: ['aha', 'bha'], benefit: 'Complete exfoliation for all pore depths' },
  { ingredients: ['ceramides', 'fatty acids'], benefit: 'Optimal barrier repair' },
  { ingredients: ['centella', 'niacinamide'], benefit: 'Enhanced calming and healing' }
];

// Conflict pairs - ingredients that shouldn't be used together
const CONFLICT_PAIRS: Array<{ ingredients: [string, string]; reason: string }> = [
  { ingredients: ['retinol', 'aha'], reason: 'May cause excessive irritation' },
  { ingredients: ['retinol', 'vitamin c'], reason: 'pH incompatibility reduces efficacy' },
  { ingredients: ['benzoyl peroxide', 'retinol'], reason: 'Benzoyl peroxide deactivates retinol' },
  { ingredients: ['niacinamide', 'vitamin c'], reason: 'May reduce efficacy (controversial)' }
];

export class RecommendationEngine {
  private zoneConcept: ZoneConcept;

  constructor() {
    this.zoneConcept = new ZoneConcept();
  }

  /**
   * Analyze skincare needs based on profile
   */
  analyzeSkincareNeeds(
    skinType: string,
    concerns: string[],
    goals: string[]
  ): SkincareAnalysis {
    const zoneRequirements = this.zoneConcept.calculateZoneRequirements(skinType, concerns);
    
    // Categorize concerns by priority
    const sortedConcerns = [...concerns].sort((a, b) => {
      const weightA = SEVERITY_WEIGHTS[a.toLowerCase()] || 1;
      const weightB = SEVERITY_WEIGHTS[b.toLowerCase()] || 1;
      return weightB - weightA;
    });

    const primaryConcerns = sortedConcerns.slice(0, 2);
    const secondaryConcerns = sortedConcerns.slice(2);

    // Determine recommended product categories
    const recommendedCategories = this.determineCategories(skinType, concerns, goals);

    return {
      skinType,
      primaryConcerns,
      secondaryConcerns,
      goals,
      zoneRequirements,
      recommendedCategories
    };
  }

  /**
   * Generate smart product recommendations with priority scoring
   */
  generateSmartRecommendations(
    products: Product[],
    skinType: string,
    concerns: string[],
    goals: string[],
    budget?: 'economy' | 'standard' | 'premium'
  ): ProductRecommendation[] {
    const analysis = this.analyzeSkincareNeeds(skinType, concerns, goals);
    
    // Score all products
    const scoredProducts = products.map(product => ({
      product,
      match: this.calculateProductMatchScore(product, skinType, concerns, goals)
    }));

    // Sort by match score
    scoredProducts.sort((a, b) => b.match.matchScore - a.match.matchScore);

    // Convert to recommendations
    let recommendations = scoredProducts.map((item, index) => {
      const priority: 'essential' | 'recommended' | 'optional' = 
        index < 3 ? 'essential' : index < 6 ? 'recommended' : 'optional';
      
      return {
        product: item.product,
        priority,
        reasoning: item.match.matchReasons.join('. '),
        applicationTime: this.determineApplicationTime(item.product),
        applicationOrder: this.determineApplicationOrder(item.product)
      };
    });

    // Apply budget filter
    if (budget === 'economy') {
      recommendations = recommendations.filter(r => r.priority === 'essential');
    } else if (budget === 'standard') {
      recommendations = recommendations.filter(r => 
        r.priority === 'essential' || r.priority === 'recommended'
      );
    }

    // Optimize combination
    return this.optimizeProductCombination(recommendations);
  }

  /**
   * Generate complete AM/PM skincare routine
   */
  generatePersonalizedRoutine(
    products: Product[],
    skinType: string,
    concerns: string[],
    goals: string[],
    lifestyle?: {
      outdoorExposure?: 'minimal' | 'moderate' | 'high';
      stressLevel?: 'low' | 'moderate' | 'high';
      sleepQuality?: 'poor' | 'average' | 'good';
    }
  ): SkincareRoutine {
    const recommendations = this.generateSmartRecommendations(products, skinType, concerns, goals);
    
    const morningSteps = this.buildMorningRoutine(recommendations, skinType, lifestyle?.outdoorExposure);
    const eveningSteps = this.buildEveningRoutine(recommendations, skinType, concerns);
    const weeklySteps = this.buildWeeklyTreatments(recommendations, skinType, concerns);

    const allProducts = [
      ...morningSteps.map(s => s.product),
      ...eveningSteps.map(s => s.product),
      ...weeklySteps.map(s => s.product)
    ];
    
    const zoneBalance = this.zoneConcept.calculateRoutineZoneBalance(allProducts);
    const expectedTimeline = this.calculateExpectedTimeline(concerns);

    return {
      morning: morningSteps,
      evening: eveningSteps,
      weekly: weeklySteps,
      zoneBalance,
      expectedTimeline
    };
  }

  /**
   * Calculate product match score based on multiple factors
   */
  calculateProductMatchScore(
    product: Product,
    skinType: string,
    concerns: string[],
    goals: string[]
  ): ProductMatch {
    let matchScore = 0;
    const matchReasons: string[] = [];
    const benefits: string[] = [];
    const matchedConcerns: string[] = [];

    // 1. Skin type compatibility (30 points max)
    const skinTypeScore = this.calculateSkinTypeCompatibility(product, skinType);
    matchScore += skinTypeScore;
    if (skinTypeScore >= 20) {
      matchReasons.push(`Highly compatible with ${skinType} skin`);
    } else if (skinTypeScore >= 10) {
      matchReasons.push(`Suitable for ${skinType} skin`);
    }

    // 2. Concern targeting (40 points max)
    const concernResult = this.calculateConcernTargeting(product, concerns);
    matchScore += concernResult.score;
    matchedConcerns.push(...concernResult.matchedConcerns);
    if (concernResult.matchedConcerns.length > 0) {
      matchReasons.push(`Targets: ${concernResult.matchedConcerns.join(', ')}`);
      benefits.push(...concernResult.benefits);
    }

    // 3. Goal alignment (20 points max)
    const goalScore = this.calculateGoalAlignment(product, goals);
    matchScore += goalScore;
    if (goalScore >= 15) {
      matchReasons.push('Strongly aligns with your skincare goals');
    }

    // 4. Zone Concept balance (10 points max)
    const zoneScores = this.zoneConcept.analyzeProductZoneActions(product);
    const zoneScore = Math.min(10, zoneScores.totalScore / 10);
    matchScore += zoneScore;
    if (zoneScore >= 8) {
      matchReasons.push('Excellent Zone Concept balance');
    }

    // Extract main benefits
    if (product.mainFunctions) {
      benefits.push(...product.mainFunctions.slice(0, 3));
    }

    return {
      product,
      matchScore,
      matchReasons,
      concerns: matchedConcerns,
      benefits: [...new Set(benefits)].slice(0, 5)
    };
  }

  /**
   * Analyze product synergies for optimal combinations
   */
  analyzeProductSynergies(products: Product[]): ProductSynergy[] {
    const synergies: ProductSynergy[] = [];

    for (let i = 0; i < products.length; i++) {
      for (let j = i + 1; j < products.length; j++) {
        const synergy = this.calculateSynergy(products[i], products[j]);
        if (synergy.synergyScore > 60) {
          synergies.push(synergy);
        }
      }
    }

    return synergies.sort((a, b) => b.synergyScore - a.synergyScore);
  }

  /**
   * Check for ingredient conflicts between products
   */
  checkProductConflicts(product1: Product, product2: Product): { hasConflict: boolean; reason?: string } {
    const ingredients1 = this.extractIngredientKeywords(product1);
    const ingredients2 = this.extractIngredientKeywords(product2);

    for (const conflict of CONFLICT_PAIRS) {
      const has1 = ingredients1.some(i => i.includes(conflict.ingredients[0]));
      const has2 = ingredients2.some(i => i.includes(conflict.ingredients[1]));
      const reverse1 = ingredients1.some(i => i.includes(conflict.ingredients[1]));
      const reverse2 = ingredients2.some(i => i.includes(conflict.ingredients[0]));

      if ((has1 && has2) || (reverse1 && reverse2)) {
        return { hasConflict: true, reason: conflict.reason };
      }
    }

    return { hasConflict: false };
  }

  // Private helper methods

  private determineCategories(skinType: string, concerns: string[], goals: string[]): string[] {
    const categories = new Set<string>(['cleanser', 'moisturizer', 'sunscreen']);

    concerns.forEach(concern => {
      const lowerConcern = concern.toLowerCase();
      if (lowerConcern.includes('acne') || lowerConcern.includes('oily')) {
        categories.add('exfoliant');
        categories.add('treatment serum');
      }
      if (lowerConcern.includes('aging') || lowerConcern.includes('wrinkle')) {
        categories.add('anti-aging serum');
        categories.add('eye cream');
      }
      if (lowerConcern.includes('pigment') || lowerConcern.includes('dark spot')) {
        categories.add('brightening serum');
      }
      if (lowerConcern.includes('dry') || lowerConcern.includes('dehydrat')) {
        categories.add('hydrating serum');
        categories.add('facial oil');
      }
    });

    return Array.from(categories);
  }

  private calculateSkinTypeCompatibility(product: Product, skinType: string): number {
    if (!product.skinTypes || product.skinTypes.length === 0) {
      return 15; // Neutral score for products without skin type info
    }

    const normalizedSkinType = skinType.toLowerCase();
    const productSkinTypes = product.skinTypes.map(t => t.toLowerCase());

    if (productSkinTypes.some(t => t === 'all skin types' || t === 'all')) {
      return 25;
    }

    if (productSkinTypes.some(t => t.includes(normalizedSkinType))) {
      return 30;
    }

    // Partial match
    if (normalizedSkinType === 'combination' && 
        (productSkinTypes.some(t => t.includes('oily')) || productSkinTypes.some(t => t.includes('dry')))) {
      return 20;
    }

    return 5;
  }

  private calculateConcernTargeting(
    product: Product,
    concerns: string[]
  ): { score: number; matchedConcerns: string[]; benefits: string[] } {
    let score = 0;
    const matchedConcerns: string[] = [];
    const benefits: string[] = [];

    const productText = [
      product.description || '',
      ...(product.mainFunctions || []),
      ...(product.keyIngredients || []),
      ...(product.activeIngredients || [])
    ].join(' ').toLowerCase();

    concerns.forEach(concern => {
      const normalizedConcern = concern.toLowerCase();
      if (productText.includes(normalizedConcern)) {
        score += 15;
        matchedConcerns.push(concern);
        
        // Extract related benefits
        if (product.mainFunctions) {
          const relatedBenefits = product.mainFunctions.filter(f => 
            f.toLowerCase().includes(normalizedConcern)
          );
          benefits.push(...relatedBenefits);
        }
      }
    });

    return { score: Math.min(40, score), matchedConcerns, benefits };
  }

  private calculateGoalAlignment(product: Product, goals: string[]): number {
    let score = 0;

    const productText = [
      product.description || '',
      ...(product.mainFunctions || [])
    ].join(' ').toLowerCase();

    goals.forEach(goal => {
      if (productText.includes(goal.toLowerCase())) {
        score += 10;
      }
    });

    return Math.min(20, score);
  }

  private calculateSynergy(product1: Product, product2: Product): ProductSynergy {
    const ingredients1 = this.extractIngredientKeywords(product1);
    const ingredients2 = this.extractIngredientKeywords(product2);
    
    let synergyScore = 50; // Base score
    const benefits: string[] = [];

    // Check for synergy pairs
    for (const pair of SYNERGY_PAIRS) {
      const has1 = ingredients1.some(i => i.includes(pair.ingredients[0]));
      const has2 = ingredients2.some(i => i.includes(pair.ingredients[1]));
      
      if (has1 && has2) {
        synergyScore += 15;
        benefits.push(pair.benefit);
      }
    }

    // Check for conflicts
    const conflict = this.checkProductConflicts(product1, product2);
    if (conflict.hasConflict) {
      synergyScore -= 30;
    }

    // Determine application order
    const applicationOrder = this.determineLayeringOrder(product1, product2);

    return {
      product1,
      product2,
      synergyScore: Math.max(0, Math.min(100, synergyScore)),
      benefits,
      applicationOrder
    };
  }

  private extractIngredientKeywords(product: Product): string[] {
    const keywords: string[] = [];
    
    if (product.keyIngredients) {
      keywords.push(...product.keyIngredients.map(i => i.toLowerCase()));
    }
    if (product.activeIngredients) {
      keywords.push(...product.activeIngredients.map(i => i.toLowerCase()));
    }
    if (product.ingredients) {
      keywords.push(...product.ingredients.map(i => i.toLowerCase()));
    }

    return keywords;
  }

  private determineLayeringOrder(product1: Product, product2: Product): string {
    const order1 = this.determineApplicationOrder(product1);
    const order2 = this.determineApplicationOrder(product2);

    if (order1 < order2) {
      return `Apply ${product1.name} before ${product2.name}`;
    } else if (order2 < order1) {
      return `Apply ${product2.name} before ${product1.name}`;
    }
    return `Can be applied in either order`;
  }

  private determineApplicationTime(product: Product): 'morning' | 'evening' | 'both' | 'weekly' {
    const name = product.name?.toLowerCase() || '';
    const category = product.category?.toLowerCase() || '';
    const description = product.description?.toLowerCase() || '';

    if (name.includes('spf') || name.includes('sunscreen') || description.includes('sun protection')) {
      return 'morning';
    }
    if (name.includes('retinol') || name.includes('night') || description.includes('overnight')) {
      return 'evening';
    }
    if (category.includes('mask') || category.includes('peel') || name.includes('weekly')) {
      return 'weekly';
    }
    return 'both';
  }

  private determineApplicationOrder(product: Product): number {
    const category = product.category?.toLowerCase() || '';
    const name = product.name?.toLowerCase() || '';
    const type = product.type?.toLowerCase() || '';

    // Standard skincare layering order
    if (category.includes('cleanser') || name.includes('cleanser')) return 1;
    if (category.includes('toner') || name.includes('toner')) return 2;
    if (category.includes('essence') || name.includes('essence')) return 3;
    if (category.includes('serum') || name.includes('serum')) return 4;
    if (category.includes('eye') || name.includes('eye')) return 5;
    if (category.includes('moisturizer') || name.includes('moisturizer') || name.includes('cream')) return 6;
    if (category.includes('oil') || name.includes('oil')) return 7;
    if (category.includes('sunscreen') || name.includes('spf')) return 8;

    return 5; // Default to middle
  }

  private buildMorningRoutine(
    recommendations: ProductRecommendation[],
    skinType: string,
    outdoorExposure?: 'minimal' | 'moderate' | 'high'
  ): RoutineStep[] {
    const morningProducts = recommendations
      .filter(r => r.applicationTime === 'morning' || r.applicationTime === 'both')
      .sort((a, b) => a.applicationOrder - b.applicationOrder);

    return morningProducts.map((rec, index) => ({
      step: index + 1,
      product: rec.product,
      amount: this.getProductAmount(rec.product),
      technique: this.getApplicationTechnique(rec.product),
      waitTime: index < morningProducts.length - 1 ? '30-60 seconds' : undefined,
      tips: this.getProductTips(rec.product, 'morning')
    }));
  }

  private buildEveningRoutine(
    recommendations: ProductRecommendation[],
    skinType: string,
    concerns: string[]
  ): RoutineStep[] {
    const eveningProducts = recommendations
      .filter(r => r.applicationTime === 'evening' || r.applicationTime === 'both')
      .sort((a, b) => a.applicationOrder - b.applicationOrder);

    return eveningProducts.map((rec, index) => ({
      step: index + 1,
      product: rec.product,
      amount: this.getProductAmount(rec.product),
      technique: this.getApplicationTechnique(rec.product),
      waitTime: index < eveningProducts.length - 1 ? '30-60 seconds' : undefined,
      tips: this.getProductTips(rec.product, 'evening')
    }));
  }

  private buildWeeklyTreatments(
    recommendations: ProductRecommendation[],
    skinType: string,
    concerns: string[]
  ): RoutineStep[] {
    const weeklyProducts = recommendations
      .filter(r => r.applicationTime === 'weekly')
      .sort((a, b) => a.applicationOrder - b.applicationOrder);

    return weeklyProducts.map((rec, index) => ({
      step: index + 1,
      product: rec.product,
      amount: this.getProductAmount(rec.product),
      technique: this.getApplicationTechnique(rec.product),
      tips: this.getProductTips(rec.product, 'weekly')
    }));
  }

  private getProductAmount(product: Product): string {
    const category = product.category?.toLowerCase() || '';
    
    if (category.includes('cleanser')) return 'Pea-sized amount';
    if (category.includes('serum')) return '2-3 drops';
    if (category.includes('moisturizer')) return 'Dime-sized amount';
    if (category.includes('sunscreen')) return '1/4 teaspoon for face';
    if (category.includes('eye')) return 'Rice grain amount per eye';
    if (category.includes('mask')) return 'Thin, even layer';
    
    return 'As directed';
  }

  private getApplicationTechnique(product: Product): string {
    const category = product.category?.toLowerCase() || '';
    
    if (category.includes('cleanser')) return 'Massage gently in circular motions, rinse with lukewarm water';
    if (category.includes('serum')) return 'Pat gently into skin, allow to absorb';
    if (category.includes('moisturizer')) return 'Apply in upward strokes, press gently to absorb';
    if (category.includes('sunscreen')) return 'Apply evenly, wait 15 minutes before sun exposure';
    if (category.includes('eye')) return 'Pat gently around orbital bone with ring finger';
    if (category.includes('mask')) return 'Apply evenly avoiding eye area, leave for recommended time';
    
    return 'Apply as directed on packaging';
  }

  private getProductTips(product: Product, time: 'morning' | 'evening' | 'weekly'): string[] {
    const tips: string[] = [];
    const category = product.category?.toLowerCase() || '';
    
    if (time === 'morning') {
      tips.push('Always follow with sunscreen');
      if (category.includes('vitamin c')) {
        tips.push('Apply to clean, dry skin for best absorption');
      }
    }
    
    if (time === 'evening') {
      if (category.includes('retinol')) {
        tips.push('Start with 2-3 times per week, gradually increase');
        tips.push('Avoid mixing with AHAs/BHAs');
      }
    }
    
    if (time === 'weekly') {
      tips.push('Best used in the evening');
      tips.push('Follow with hydrating products');
    }

    return tips;
  }

  private calculateExpectedTimeline(concerns: string[]): string {
    let maxWeeks = 4;

    concerns.forEach(concern => {
      const timeline = CONCERN_TIMELINES[concern.toLowerCase()];
      if (timeline) {
        const weeks = parseInt(timeline.split('-')[1]) || 8;
        maxWeeks = Math.max(maxWeeks, weeks);
      }
    });

    return `${Math.ceil(maxWeeks / 4)} - ${Math.ceil(maxWeeks / 2)} weeks for visible improvements`;
  }

  private optimizeProductCombination(recommendations: ProductRecommendation[]): ProductRecommendation[] {
    // Check for conflicts and adjust
    const products = recommendations.map(r => r.product);
    
    for (let i = 0; i < products.length; i++) {
      for (let j = i + 1; j < products.length; j++) {
        const conflict = this.checkProductConflicts(products[i], products[j]);
        if (conflict.hasConflict) {
          // Add warning to reasoning
          recommendations[i].reasoning += ` Note: ${conflict.reason} when used with ${products[j].name}`;
          recommendations[j].reasoning += ` Note: ${conflict.reason} when used with ${products[i].name}`;
        }
      }
    }

    // Sort by application order
    return recommendations.sort((a, b) => a.applicationOrder - b.applicationOrder);
  }
}

export const recommendationEngine = new RecommendationEngine();
