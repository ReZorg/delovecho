/**
 * REGIMA ZONE CONCEPT ANALYSIS ENGINE
 * Core philosophy implementation for intelligent skincare recommendations
 * 
 * The Zone Concept is the foundational philosophy of RegimA skincare:
 * - Anti-inflammatory (SPA Zone): Calming, soothing, barrier repair
 * - Anti-oxidant (ZON Zone): Protection, environmental defense
 * - Rejuvenation (MED Zone): Renewal, regeneration, active treatment
 */

import type { Product, ZoneType } from "../schema/index.js";

export interface ZoneBalance {
  antiInflammatory: number;
  antiOxidant: number;
  rejuvenation: number;
  overallBalance: number;
  recommendations: string[];
}

export interface ZoneRequirements {
  skinType: string;
  concerns: string[];
  antiInflammatoryNeeds: number;
  antiOxidantNeeds: number;
  rejuvenationNeeds: number;
}

export interface ZoneProductScore {
  antiInflammatory: number;
  antiOxidant: number;
  rejuvenation: number;
  totalScore: number;
}

export interface ZoneRecommendation {
  product: Product;
  score: number;
  zoneContribution: ZoneProductScore;
  reasoning: string;
}

export interface SkinProfile {
  skinType: string;
  skinConcerns: string[];
  currentProducts: Product[];
  lifestyle: {
    stressLevel: "low" | "moderate" | "high";
    sleepQuality: "poor" | "moderate" | "good";
    diet: "poor" | "moderate" | "good";
    sunExposure: "low" | "moderate" | "high";
  };
}

export interface ZoneAnalysisResult {
  zoneScores: {
    antiInflammatory: number;
    antiOxidant: number;
    rejuvenation: number;
  };
  primaryZone: "spa" | "zon" | "med";
  recommendations: {
    spa: string[];
    zon: string[];
    med: string[];
  };
}

// Concern to Zone mapping with priority scores
const CONCERN_ZONE_MAPPING: Record<string, { antiInflammatory: number; antiOxidant: number; rejuvenation: number }> = {
  acne: { antiInflammatory: 90, antiOxidant: 70, rejuvenation: 60 },
  aging: { antiInflammatory: 60, antiOxidant: 90, rejuvenation: 90 },
  pigmentation: { antiInflammatory: 70, antiOxidant: 85, rejuvenation: 80 },
  sensitivity: { antiInflammatory: 95, antiOxidant: 60, rejuvenation: 50 },
  dryness: { antiInflammatory: 70, antiOxidant: 60, rejuvenation: 75 },
  rosacea: { antiInflammatory: 100, antiOxidant: 70, rejuvenation: 40 },
  dehydration: { antiInflammatory: 65, antiOxidant: 55, rejuvenation: 70 },
  fine_lines: { antiInflammatory: 55, antiOxidant: 80, rejuvenation: 85 },
  "fine lines": { antiInflammatory: 55, antiOxidant: 80, rejuvenation: 85 },
  wrinkles: { antiInflammatory: 50, antiOxidant: 85, rejuvenation: 90 },
  hyperpigmentation: { antiInflammatory: 70, antiOxidant: 85, rejuvenation: 80 },
  uneven_texture: { antiInflammatory: 60, antiOxidant: 65, rejuvenation: 90 },
  "uneven skin tone": { antiInflammatory: 65, antiOxidant: 80, rejuvenation: 75 },
  dullness: { antiInflammatory: 55, antiOxidant: 85, rejuvenation: 70 },
  "enlarged pores": { antiInflammatory: 75, antiOxidant: 60, rejuvenation: 70 },
  inflammation: { antiInflammatory: 95, antiOxidant: 65, rejuvenation: 50 },
  redness: { antiInflammatory: 90, antiOxidant: 60, rejuvenation: 45 },
  irritation: { antiInflammatory: 95, antiOxidant: 55, rejuvenation: 40 },
  "loss of elasticity": { antiInflammatory: 50, antiOxidant: 80, rejuvenation: 95 },
  prevention: { antiInflammatory: 60, antiOxidant: 75, rejuvenation: 65 },
};

// Skin type to base Zone requirements
const SKIN_TYPE_ZONE_MAPPING: Record<string, { antiInflammatory: number; antiOxidant: number; rejuvenation: number }> = {
  oily: { antiInflammatory: 70, antiOxidant: 60, rejuvenation: 65 },
  dry: { antiInflammatory: 60, antiOxidant: 70, rejuvenation: 75 },
  combination: { antiInflammatory: 65, antiOxidant: 65, rejuvenation: 65 },
  sensitive: { antiInflammatory: 85, antiOxidant: 60, rejuvenation: 55 },
  normal: { antiInflammatory: 50, antiOxidant: 60, rejuvenation: 60 },
  mature: { antiInflammatory: 55, antiOxidant: 85, rejuvenation: 90 },
};

// Keywords for Zone action detection
const ANTI_INFLAMMATORY_KEYWORDS = [
  'anti-inflammatory', 'calming', 'soothing', 'reduces redness',
  'anti-irritant', 'healing', 'reduces inflammation', 'bisabolol',
  'centella', 'chamomile', 'aloe', 'green tea', 'barrier repair',
  'niacinamide', 'panthenol', 'allantoin', 'centella asiatica', 'aloe vera'
];

const ANTI_OXIDANT_KEYWORDS = [
  'anti-oxidant', 'antioxidant', 'vitamin c', 'vitamin e', 'vitamin a',
  'free radical', 'environmental protection', 'pollution', 'resveratrol',
  'coenzyme q10', 'ferulic acid', 'tocopherol', 'ascorbic acid',
  'glutathione', 'superoxide dismutase'
];

const REJUVENATION_KEYWORDS = [
  'rejuvenation', 'renewal', 'regeneration', 'collagen', 'elastin',
  'peptide', 'peptides', 'growth factor', 'cell turnover', 'exfoliation', 'retinol',
  'aha', 'bha', 'resurfacing', 'anti-aging', 'wrinkle', 'retinoid',
  'glycolic', 'lactic', 'salicylic', 'hyaluronic acid'
];

/**
 * ZoneConceptAnalyzer - Main class for Zone Concept analysis
 */
export class ZoneConceptAnalyzer {
  /**
   * Analyze a skin profile and return zone scores and recommendations
   */
  analyzeSkinProfile(profile: SkinProfile): ZoneAnalysisResult {
    const baseReqs = SKIN_TYPE_ZONE_MAPPING[profile.skinType.toLowerCase()] || {
      antiInflammatory: 60,
      antiOxidant: 60,
      rejuvenation: 60
    };

    let antiInflammatoryTotal = baseReqs.antiInflammatory;
    let antiOxidantTotal = baseReqs.antiOxidant;
    let rejuvenationTotal = baseReqs.rejuvenation;
    let concernCount = 1;

    // Add lifestyle factors
    if (profile.lifestyle.stressLevel === "high") {
      antiInflammatoryTotal += 15;
    }
    if (profile.lifestyle.sleepQuality === "poor") {
      rejuvenationTotal += 10;
    }
    if (profile.lifestyle.sunExposure === "high") {
      antiOxidantTotal += 15;
    }

    // Process concerns
    profile.skinConcerns.forEach(concern => {
      const key = concern.toLowerCase().replace(/\s+/g, '_');
      const concernReqs = CONCERN_ZONE_MAPPING[key] || CONCERN_ZONE_MAPPING[concern.toLowerCase()];
      if (concernReqs) {
        antiInflammatoryTotal += concernReqs.antiInflammatory;
        antiOxidantTotal += concernReqs.antiOxidant;
        rejuvenationTotal += concernReqs.rejuvenation;
        concernCount++;
      }
    });

    const zoneScores = {
      antiInflammatory: Math.min(100, Math.round(antiInflammatoryTotal / concernCount)),
      antiOxidant: Math.min(100, Math.round(antiOxidantTotal / concernCount)),
      rejuvenation: Math.min(100, Math.round(rejuvenationTotal / concernCount))
    };

    // Determine primary zone
    let primaryZone: "spa" | "zon" | "med" = "spa";
    if (zoneScores.antiOxidant > zoneScores.antiInflammatory && zoneScores.antiOxidant > zoneScores.rejuvenation) {
      primaryZone = "zon";
    } else if (zoneScores.rejuvenation > zoneScores.antiInflammatory && zoneScores.rejuvenation > zoneScores.antiOxidant) {
      primaryZone = "med";
    }

    // Generate recommendations
    const recommendations = {
      spa: this.generateSpaRecommendations(zoneScores.antiInflammatory, profile),
      zon: this.generateZonRecommendations(zoneScores.antiOxidant, profile),
      med: this.generateMedRecommendations(zoneScores.rejuvenation, profile)
    };

    return { zoneScores, primaryZone, recommendations };
  }

  /**
   * Analyze a product for zone compatibility
   */
  analyzeProduct(product: { name: string; ingredients: string[] }): {
    zoneScores: { antiInflammatory: number; antiOxidant: number; rejuvenation: number };
    primaryZone: "spa" | "zon" | "med";
  } {
    let antiInflammatory = 0;
    let antiOxidant = 0;
    let rejuvenation = 0;

    const textCorpus = product.ingredients.join(' ').toLowerCase();

    ANTI_INFLAMMATORY_KEYWORDS.forEach(keyword => {
      if (textCorpus.includes(keyword.toLowerCase())) {
        antiInflammatory = Math.min(100, antiInflammatory + 15);
      }
    });

    ANTI_OXIDANT_KEYWORDS.forEach(keyword => {
      if (textCorpus.includes(keyword.toLowerCase())) {
        antiOxidant = Math.min(100, antiOxidant + 15);
      }
    });

    REJUVENATION_KEYWORDS.forEach(keyword => {
      if (textCorpus.includes(keyword.toLowerCase())) {
        rejuvenation = Math.min(100, rejuvenation + 15);
      }
    });

    let primaryZone: "spa" | "zon" | "med" = "spa";
    if (antiOxidant > antiInflammatory && antiOxidant > rejuvenation) {
      primaryZone = "zon";
    } else if (rejuvenation > antiInflammatory && rejuvenation > antiOxidant) {
      primaryZone = "med";
    }

    return {
      zoneScores: { antiInflammatory, antiOxidant, rejuvenation },
      primaryZone
    };
  }

  /**
   * Get zone information
   */
  getZoneInfo(): {
    philosophy: string;
    zones: Array<{
      id: "spa" | "zon" | "med";
      name: string;
      description: string;
      keyIngredients: string[];
    }>;
  } {
    return {
      philosophy: "The Zone Concept is the foundational philosophy of RegimA skincare, balancing three essential pillars: Anti-inflammatory (SPA), Anti-oxidant (ZON), and Rejuvenation (MED). A well-balanced routine addresses all three zones for optimal skin health.",
      zones: [
        {
          id: "spa",
          name: "Anti-inflammatory (SPA)",
          description: "Calming, soothing, and barrier repair. Essential for maintaining skin health and reducing irritation.",
          keyIngredients: ["Niacinamide", "Centella Asiatica", "Aloe Vera", "Bisabolol", "Panthenol", "Chamomile"]
        },
        {
          id: "zon",
          name: "Anti-oxidant (ZON)",
          description: "Protection against environmental damage, free radicals, and oxidative stress.",
          keyIngredients: ["Vitamin C", "Vitamin E", "Ferulic Acid", "Resveratrol", "Green Tea Extract", "CoQ10"]
        },
        {
          id: "med",
          name: "Rejuvenation (MED)",
          description: "Cellular renewal, regeneration, and active treatment for visible skin improvements.",
          keyIngredients: ["Retinol", "Peptides", "AHAs", "BHAs", "Growth Factors", "Hyaluronic Acid"]
        }
      ]
    };
  }

  private generateSpaRecommendations(score: number, profile: SkinProfile): string[] {
    const recs: string[] = [];
    if (score >= 80) {
      recs.push("High anti-inflammatory needs detected. Focus on calming products with centella asiatica and niacinamide.");
    } else if (score >= 60) {
      recs.push("Moderate anti-inflammatory support recommended. Include soothing ingredients in your routine.");
    } else {
      recs.push("Basic anti-inflammatory maintenance. Use gentle, barrier-supporting products.");
    }
    return recs;
  }

  private generateZonRecommendations(score: number, profile: SkinProfile): string[] {
    const recs: string[] = [];
    if (score >= 80) {
      recs.push("High antioxidant needs. Use Vitamin C serum daily and consider additional antioxidant boosters.");
    } else if (score >= 60) {
      recs.push("Moderate antioxidant protection needed. Include Vitamin C or E in your routine.");
    } else {
      recs.push("Basic antioxidant maintenance. Ensure SPF protection and consider occasional antioxidant serums.");
    }
    return recs;
  }

  private generateMedRecommendations(score: number, profile: SkinProfile): string[] {
    const recs: string[] = [];
    if (score >= 80) {
      recs.push("High rejuvenation needs. Consider retinol or professional treatments for cellular renewal.");
    } else if (score >= 60) {
      recs.push("Moderate rejuvenation support. Include gentle exfoliants and peptides in your routine.");
    } else {
      recs.push("Basic rejuvenation maintenance. Focus on hydration and occasional exfoliation.");
    }
    return recs;
  }
}

/**
 * ZoneConcept - Legacy class for backward compatibility
 */
export class ZoneConcept {
  /**
   * Calculate Zone requirements based on skin type and concerns
   */
  calculateZoneRequirements(skinType: string, concerns: string[]): ZoneRequirements {
    const baseReqs = SKIN_TYPE_ZONE_MAPPING[skinType.toLowerCase()] || {
      antiInflammatory: 60,
      antiOxidant: 60,
      rejuvenation: 60
    };

    let antiInflammatoryTotal = baseReqs.antiInflammatory;
    let antiOxidantTotal = baseReqs.antiOxidant;
    let rejuvenationTotal = baseReqs.rejuvenation;
    let concernCount = 1;

    concerns.forEach(concern => {
      const concernReqs = CONCERN_ZONE_MAPPING[concern.toLowerCase().replace(/\s+/g, '_')];
      if (concernReqs) {
        antiInflammatoryTotal += concernReqs.antiInflammatory;
        antiOxidantTotal += concernReqs.antiOxidant;
        rejuvenationTotal += concernReqs.rejuvenation;
        concernCount++;
      }
    });

    return {
      skinType,
      concerns,
      antiInflammatoryNeeds: Math.min(100, Math.round(antiInflammatoryTotal / concernCount)),
      antiOxidantNeeds: Math.min(100, Math.round(antiOxidantTotal / concernCount)),
      rejuvenationNeeds: Math.min(100, Math.round(rejuvenationTotal / concernCount))
    };
  }

  /**
   * Analyze a product's Zone actions and calculate scores
   */
  analyzeProductZoneActions(product: Product): ZoneProductScore {
    let antiInflammatory = 0;
    let antiOxidant = 0;
    let rejuvenation = 0;

    // Check explicit Zone actions
    if (product.zoneAction) {
      if (product.zoneAction.includes('Anti-inflammatory')) antiInflammatory = 80;
      if (product.zoneAction.includes('Anti-oxidant')) antiOxidant = 80;
      if (product.zoneAction.includes('Rejuvenation')) rejuvenation = 80;
    }

    // Build text corpus for keyword analysis
    const textCorpus = [
      ...(product.mainFunctions || []),
      ...(product.keyIngredients || []),
      ...(product.activeIngredients || []),
      product.description || ''
    ].join(' ').toLowerCase();

    // Score based on keywords
    ANTI_INFLAMMATORY_KEYWORDS.forEach(keyword => {
      if (textCorpus.includes(keyword)) {
        antiInflammatory = Math.min(100, antiInflammatory + 12);
      }
    });

    ANTI_OXIDANT_KEYWORDS.forEach(keyword => {
      if (textCorpus.includes(keyword)) {
        antiOxidant = Math.min(100, antiOxidant + 12);
      }
    });

    REJUVENATION_KEYWORDS.forEach(keyword => {
      if (textCorpus.includes(keyword)) {
        rejuvenation = Math.min(100, rejuvenation + 12);
      }
    });

    const totalScore = (antiInflammatory + antiOxidant + rejuvenation) / 3;

    return { antiInflammatory, antiOxidant, rejuvenation, totalScore };
  }

  /**
   * Calculate Zone balance for a routine (collection of products)
   */
  calculateRoutineZoneBalance(products: Product[]): ZoneBalance {
    if (products.length === 0) {
      return {
        antiInflammatory: 0,
        antiOxidant: 0,
        rejuvenation: 0,
        overallBalance: 0,
        recommendations: ['No products selected. Add products to build a balanced routine.']
      };
    }

    let totalAntiInflammatory = 0;
    let totalAntiOxidant = 0;
    let totalRejuvenation = 0;

    products.forEach(product => {
      const scores = this.analyzeProductZoneActions(product);
      totalAntiInflammatory += scores.antiInflammatory;
      totalAntiOxidant += scores.antiOxidant;
      totalRejuvenation += scores.rejuvenation;
    });

    const avgAntiInflammatory = Math.round(totalAntiInflammatory / products.length);
    const avgAntiOxidant = Math.round(totalAntiOxidant / products.length);
    const avgRejuvenation = Math.round(totalRejuvenation / products.length);

    const min = Math.min(avgAntiInflammatory, avgAntiOxidant, avgRejuvenation);
    const max = Math.max(avgAntiInflammatory, avgAntiOxidant, avgRejuvenation);
    const balance = 100 - (max - min);

    const recommendations = this.generateBalanceRecommendations(
      avgAntiInflammatory,
      avgAntiOxidant,
      avgRejuvenation
    );

    return {
      antiInflammatory: avgAntiInflammatory,
      antiOxidant: avgAntiOxidant,
      rejuvenation: avgRejuvenation,
      overallBalance: balance,
      recommendations
    };
  }

  /**
   * Generate recommendations to improve Zone balance
   */
  private generateBalanceRecommendations(
    antiInflammatory: number,
    antiOxidant: number,
    rejuvenation: number
  ): string[] {
    const recommendations: string[] = [];

    if (antiInflammatory < 60) {
      recommendations.push('Consider adding products with stronger anti-inflammatory properties containing bisabolol, centella asiatica, or niacinamide.');
    }

    if (antiOxidant < 60) {
      recommendations.push('Boost antioxidant protection with products containing Vitamin C, E, ferulic acid, or green tea extracts.');
    }

    if (rejuvenation < 60) {
      recommendations.push('Enhance cellular renewal with products containing AHAs, peptides, retinoids, or growth factors.');
    }

    if (antiInflammatory > 85 && antiOxidant < 70) {
      recommendations.push('Your routine is heavily focused on calming. Consider adding more antioxidant protection for comprehensive anti-aging benefits.');
    }

    if (rejuvenation > 85 && antiInflammatory < 70) {
      recommendations.push('Strong renewal focus detected. Balance with calming products to prevent irritation and maintain skin barrier health.');
    }

    if (recommendations.length === 0) {
      if (antiInflammatory >= 70 && antiOxidant >= 70 && rejuvenation >= 70) {
        recommendations.push('Excellent Zone balance achieved! Your routine addresses all three pillars of the RegimA philosophy effectively.');
      } else {
        recommendations.push('Good Zone balance. Continue with current routine and monitor skin response.');
      }
    }

    return recommendations;
  }

  /**
   * Recommend products to fill Zone gaps
   */
  recommendProductsForBalance(
    currentProducts: Product[],
    requirements: ZoneRequirements,
    availableProducts: Product[]
  ): ZoneRecommendation[] {
    const currentBalance = this.calculateRoutineZoneBalance(currentProducts);
    
    const antiInflamGap = Math.max(0, requirements.antiInflammatoryNeeds - currentBalance.antiInflammatory);
    const antiOxGap = Math.max(0, requirements.antiOxidantNeeds - currentBalance.antiOxidant);
    const rejuvGap = Math.max(0, requirements.rejuvenationNeeds - currentBalance.rejuvenation);

    const scoredProducts = availableProducts.map(product => {
      const zoneScores = this.analyzeProductZoneActions(product);
      
      let gapScore = 0;
      const reasons: string[] = [];

      if (antiInflamGap > 0 && zoneScores.antiInflammatory > 50) {
        gapScore += (zoneScores.antiInflammatory * antiInflamGap) / 100;
        reasons.push('anti-inflammatory support');
      }
      if (antiOxGap > 0 && zoneScores.antiOxidant > 50) {
        gapScore += (zoneScores.antiOxidant * antiOxGap) / 100;
        reasons.push('antioxidant protection');
      }
      if (rejuvGap > 0 && zoneScores.rejuvenation > 50) {
        gapScore += (zoneScores.rejuvenation * rejuvGap) / 100;
        reasons.push('rejuvenation benefits');
      }

      // Skin type compatibility bonus
      const skinTypeMatch = product.skinTypes?.some(type => 
        type.toLowerCase().includes(requirements.skinType.toLowerCase()) ||
        type.toLowerCase() === 'all skin types'
      ) ? 1.2 : 0.8;

      return {
        product,
        score: gapScore * skinTypeMatch,
        zoneContribution: zoneScores,
        reasoning: reasons.length > 0 
          ? `Provides ${reasons.join(', ')}`
          : 'General skincare support'
      };
    });

    return scoredProducts
      .filter(item => item.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
  }

  /**
   * Determine the primary Zone for a product
   */
  getPrimaryZone(product: Product): ZoneType {
    const scores = this.analyzeProductZoneActions(product);
    
    if (scores.antiInflammatory >= scores.antiOxidant && scores.antiInflammatory >= scores.rejuvenation) {
      return 'spa';
    } else if (scores.antiOxidant >= scores.rejuvenation) {
      return 'zon';
    } else {
      return 'med';
    }
  }

  /**
   * Get Zone compatibility for a product
   */
  getZoneCompatibility(product: Product): ZoneType[] {
    const scores = this.analyzeProductZoneActions(product);
    const zones: ZoneType[] = [];
    
    if (scores.antiInflammatory >= 50) zones.push('spa');
    if (scores.antiOxidant >= 50) zones.push('zon');
    if (scores.rejuvenation >= 50) zones.push('med');
    
    return zones.length > 0 ? zones : ['spa']; // Default to SPA if no strong Zone affinity
  }
}

export const zoneConcept = new ZoneConcept();
export const zoneConceptAnalyzer = new ZoneConceptAnalyzer();
