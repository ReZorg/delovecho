/**
 * REGIMA WORKFLOW ENGINE
 * Automated treatment protocol management and execution
 */

import type { Product, WorkflowType, WorkflowStatus, ZoneType } from "../schema/index.js";
import { ZoneConcept } from "./zone-concept.js";
import { RecommendationEngine } from "./recommendation-engine.js";

export interface WorkflowStep {
  id: string;
  workflowId: string;
  order: number;
  type: "cleanse" | "exfoliate" | "treat" | "mask" | "moisturize" | "protect";
  zone: ZoneType;
  products: string[];
  instructions: string;
  duration?: number;
  frequency?: string;
  time?: "morning" | "evening" | "anytime";
  completed: boolean;
  completedAt?: Date;
  notes?: string;
}

export interface WorkflowProgress {
  workflowId: string;
  currentStep: number;
  completedSteps: number;
  totalSteps: number;
  compliance: number;
  skinImprovements: {
    hydration: number;
    texture: number;
    pigmentation: number;
    acne: number;
    fineLines: number;
  };
  lastUpdated: Date;
  nextReview: Date;
}

export interface WorkflowDefinition {
  id: string;
  userId: number;
  type: WorkflowType;
  name: string;
  description: string;
  status: WorkflowStatus;
  startDate: Date;
  endDate?: Date;
  duration: number;
  skinType: string;
  skinConcerns: string[];
  steps: WorkflowStep[];
  progress: WorkflowProgress;
  adaptations: WorkflowAdaptation[];
  reminders: WorkflowReminder[];
  createdAt: Date;
  updatedAt: Date;
}

export interface WorkflowAdaptation {
  id: string;
  workflowId: string;
  date: Date;
  reason: string;
  changes: Array<{
    field: string;
    oldValue: unknown;
    newValue: unknown;
  }>;
}

export interface WorkflowReminder {
  id: string;
  workflowId: string;
  stepId: string;
  time: string;
  message: string;
  enabled: boolean;
}

export interface SkinProfile {
  skinType: string;
  skinConcerns: string[];
  goals: string[];
}

export interface StepFeedback {
  stepNotes?: string;
  skinResponse?: {
    reaction?: "positive" | "neutral" | "negative";
    improvements?: string[];
    concerns?: string[];
  };
  productFeedback?: Array<{
    productName: string;
    rating: number;
    notes?: string;
  }>;
}

// Workflow type configurations
const WORKFLOW_CONFIGS: Record<WorkflowType, { name: string; description: string; defaultDuration: number }> = {
  daily_routine: {
    name: "Daily Skincare Routine",
    description: "Comprehensive daily AM/PM skincare routine optimized for your skin type",
    defaultDuration: 30
  },
  weekly_treatment: {
    name: "Weekly Treatment Protocol",
    description: "Intensive weekly treatments to address specific skin concerns",
    defaultDuration: 8
  },
  monthly_protocol: {
    name: "Monthly Renewal Protocol",
    description: "Long-term protocol for sustained skin transformation",
    defaultDuration: 30
  },
  acne_program: {
    name: "Acne Management Program",
    description: "Targeted protocol for acne-prone skin with progressive treatment intensity",
    defaultDuration: 90
  },
  anti_aging_program: {
    name: "Anti-Aging Program",
    description: "Comprehensive anti-aging protocol focusing on prevention and correction",
    defaultDuration: 120
  }
};

export class WorkflowEngine {
  private workflows: Map<string, WorkflowDefinition> = new Map();
  private zoneConcept: ZoneConcept;
  private recommendationEngine: RecommendationEngine;

  constructor() {
    this.zoneConcept = new ZoneConcept();
    this.recommendationEngine = new RecommendationEngine();
  }

  /**
   * Create a new workflow for a user
   */
  async createWorkflow(
    userId: number,
    protocolType: WorkflowType,
    duration?: number,
    skinProfile?: SkinProfile
  ): Promise<WorkflowDefinition> {
    const workflowId = `wf_${userId}_${Date.now()}`;
    const config = WORKFLOW_CONFIGS[protocolType];
    const actualDuration = duration || config.defaultDuration;

    const steps = await this.generateWorkflowSteps(protocolType, skinProfile);

    const progress: WorkflowProgress = {
      workflowId,
      currentStep: 0,
      completedSteps: 0,
      totalSteps: steps.length,
      compliance: 100,
      skinImprovements: {
        hydration: 0,
        texture: 0,
        pigmentation: 0,
        acne: 0,
        fineLines: 0
      },
      lastUpdated: new Date(),
      nextReview: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
    };

    const workflow: WorkflowDefinition = {
      id: workflowId,
      userId,
      type: protocolType,
      name: config.name,
      description: config.description,
      status: "active",
      startDate: new Date(),
      endDate: new Date(Date.now() + actualDuration * 24 * 60 * 60 * 1000),
      duration: actualDuration,
      skinType: skinProfile?.skinType || "normal",
      skinConcerns: skinProfile?.skinConcerns || [],
      steps,
      progress,
      adaptations: [],
      reminders: this.generateDefaultReminders(workflowId, steps),
      createdAt: new Date(),
      updatedAt: new Date()
    };

    this.workflows.set(workflowId, workflow);
    return workflow;
  }

  /**
   * Execute the current step in a workflow
   */
  async executeStep(workflowId: string): Promise<WorkflowStep | null> {
    const workflow = this.workflows.get(workflowId);
    if (!workflow || workflow.status !== "active") {
      return null;
    }

    const currentStep = workflow.steps[workflow.progress.currentStep];
    if (!currentStep) {
      return null;
    }

    currentStep.completed = true;
    currentStep.completedAt = new Date();

    workflow.progress.completedSteps++;
    workflow.progress.currentStep++;
    workflow.progress.lastUpdated = new Date();

    const expectedCompletions = Math.floor(
      (Date.now() - workflow.startDate.getTime()) / (24 * 60 * 60 * 1000)
    );
    workflow.progress.compliance = Math.round(
      (workflow.progress.completedSteps / Math.max(expectedCompletions, 1)) * 100
    );

    workflow.updatedAt = new Date();
    this.workflows.set(workflowId, workflow);

    return currentStep;
  }

  /**
   * Update workflow progress with feedback
   */
  async updateProgress(
    workflowId: string,
    feedback: StepFeedback
  ): Promise<WorkflowProgress | null> {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) {
      return null;
    }

    if (feedback.skinResponse) {
      const improvements = workflow.progress.skinImprovements;

      if (feedback.skinResponse.improvements?.includes("hydration")) {
        improvements.hydration = Math.min(100, improvements.hydration + 5);
      }
      if (feedback.skinResponse.improvements?.includes("texture")) {
        improvements.texture = Math.min(100, improvements.texture + 5);
      }
      if (feedback.skinResponse.improvements?.includes("brightness")) {
        improvements.pigmentation = Math.min(100, improvements.pigmentation + 5);
      }
      if (feedback.skinResponse.improvements?.includes("acne")) {
        improvements.acne = Math.min(100, improvements.acne + 5);
      }
      if (feedback.skinResponse.improvements?.includes("fine lines")) {
        improvements.fineLines = Math.min(100, improvements.fineLines + 5);
      }

      if (feedback.skinResponse.reaction === "negative") {
        await this.adjustWorkflow(workflowId, {
          reason: "negative_reaction",
          feedback: feedback.skinResponse
        });
      }
    }

    workflow.progress.lastUpdated = new Date();
    workflow.updatedAt = new Date();
    this.workflows.set(workflowId, workflow);

    return workflow.progress;
  }

  /**
   * Get next steps in the workflow
   */
  async getNextSteps(workflowId: string, count: number = 5): Promise<WorkflowStep[]> {
    const workflow = this.workflows.get(workflowId);
    if (!workflow || workflow.status !== "active") {
      return [];
    }

    const currentIndex = workflow.progress.currentStep;
    return workflow.steps.slice(currentIndex, currentIndex + count);
  }

  /**
   * Adjust workflow based on feedback
   */
  async adjustWorkflow(
    workflowId: string,
    feedback: { reason: string; feedback: unknown }
  ): Promise<WorkflowDefinition | null> {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) {
      return null;
    }

    const adaptation: WorkflowAdaptation = {
      id: `adapt_${Date.now()}`,
      workflowId,
      date: new Date(),
      reason: feedback.reason,
      changes: []
    };

    if (feedback.reason === "negative_reaction") {
      const currentStep = workflow.steps[workflow.progress.currentStep - 1];
      if (currentStep && currentStep.zone === "med") {
        const oldZone = currentStep.zone;
        currentStep.zone = "zon";
        adaptation.changes.push({
          field: "zone",
          oldValue: oldZone,
          newValue: "zon"
        });
      }
    } else if (feedback.reason === "too_complex") {
      const essentialSteps = workflow.steps.filter(
        step => step.type === "cleanse" || step.type === "moisturize" || step.type === "protect"
      );
      adaptation.changes.push({
        field: "steps",
        oldValue: workflow.steps.length,
        newValue: essentialSteps.length
      });
      workflow.steps = essentialSteps;
    } else if (feedback.reason === "schedule_conflict") {
      workflow.steps.forEach(step => {
        if (step.frequency === "twice daily") {
          step.frequency = "daily";
          adaptation.changes.push({
            field: `step_${step.id}_frequency`,
            oldValue: "twice daily",
            newValue: "daily"
          });
        }
      });
    }

    workflow.adaptations.push(adaptation);
    workflow.updatedAt = new Date();
    this.workflows.set(workflowId, workflow);

    return workflow;
  }

  /**
   * Get all active workflows for a user
   */
  async getActiveWorkflows(userId: number): Promise<WorkflowDefinition[]> {
    const userWorkflows: WorkflowDefinition[] = [];

    this.workflows.forEach(workflow => {
      if (workflow.userId === userId && workflow.status === "active") {
        userWorkflows.push(workflow);
      }
    });

    return userWorkflows;
  }

  /**
   * Pause a workflow
   */
  async pauseWorkflow(workflowId: string): Promise<boolean> {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) {
      return false;
    }

    workflow.status = "paused";
    workflow.updatedAt = new Date();
    this.workflows.set(workflowId, workflow);

    return true;
  }

  /**
   * Resume a paused workflow
   */
  async resumeWorkflow(workflowId: string): Promise<boolean> {
    const workflow = this.workflows.get(workflowId);
    if (!workflow || workflow.status !== "paused") {
      return false;
    }

    workflow.status = "active";
    workflow.updatedAt = new Date();
    this.workflows.set(workflowId, workflow);

    return true;
  }

  /**
   * Complete a workflow
   */
  async completeWorkflow(workflowId: string): Promise<boolean> {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) {
      return false;
    }

    workflow.status = "completed";
    workflow.endDate = new Date();
    workflow.updatedAt = new Date();
    this.workflows.set(workflowId, workflow);

    return true;
  }

  /**
   * Get workflow by ID
   */
  getWorkflow(workflowId: string): WorkflowDefinition | undefined {
    return this.workflows.get(workflowId);
  }

  // Private helper methods

  private async generateWorkflowSteps(
    protocolType: WorkflowType,
    skinProfile?: SkinProfile
  ): Promise<WorkflowStep[]> {
    const steps: WorkflowStep[] = [];
    const baseId = Date.now().toString();

    switch (protocolType) {
      case "daily_routine":
        steps.push(...this.generateDailyRoutineSteps(baseId, skinProfile));
        break;
      case "weekly_treatment":
        steps.push(...this.generateWeeklyTreatmentSteps(baseId, skinProfile));
        break;
      case "acne_program":
        steps.push(...this.generateAcneProgramSteps(baseId, skinProfile));
        break;
      case "anti_aging_program":
        steps.push(...this.generateAntiAgingSteps(baseId, skinProfile));
        break;
      default:
        steps.push(...this.generateDailyRoutineSteps(baseId, skinProfile));
    }

    return steps;
  }

  private generateDailyRoutineSteps(baseId: string, skinProfile?: SkinProfile): WorkflowStep[] {
    return [
      {
        id: `${baseId}_1`,
        workflowId: "",
        order: 1,
        type: "cleanse",
        zone: "spa",
        products: ["Gentle Cleanser"],
        instructions: "Massage onto damp skin for 60 seconds, rinse thoroughly",
        duration: 2,
        frequency: "twice daily",
        time: "morning",
        completed: false
      },
      {
        id: `${baseId}_2`,
        workflowId: "",
        order: 2,
        type: "treat",
        zone: "zon",
        products: ["Vitamin C Serum"],
        instructions: "Apply 2-3 drops to clean skin, allow to absorb",
        duration: 1,
        frequency: "daily",
        time: "morning",
        completed: false
      },
      {
        id: `${baseId}_3`,
        workflowId: "",
        order: 3,
        type: "moisturize",
        zone: "spa",
        products: ["Daily Moisturizer"],
        instructions: "Apply evenly to face and neck",
        duration: 1,
        frequency: "twice daily",
        time: "morning",
        completed: false
      },
      {
        id: `${baseId}_4`,
        workflowId: "",
        order: 4,
        type: "protect",
        zone: "zon",
        products: ["SPF 50 Sunscreen"],
        instructions: "Apply generously, reapply every 2 hours if outdoors",
        duration: 1,
        frequency: "daily",
        time: "morning",
        completed: false
      },
      {
        id: `${baseId}_5`,
        workflowId: "",
        order: 5,
        type: "cleanse",
        zone: "spa",
        products: ["Gentle Cleanser"],
        instructions: "Double cleanse if wearing makeup",
        duration: 3,
        frequency: "daily",
        time: "evening",
        completed: false
      },
      {
        id: `${baseId}_6`,
        workflowId: "",
        order: 6,
        type: "treat",
        zone: "med",
        products: ["Retinol Serum"],
        instructions: "Apply pea-sized amount, avoid eye area",
        duration: 1,
        frequency: "3x weekly",
        time: "evening",
        completed: false
      },
      {
        id: `${baseId}_7`,
        workflowId: "",
        order: 7,
        type: "moisturize",
        zone: "spa",
        products: ["Night Cream"],
        instructions: "Apply generous layer before bed",
        duration: 1,
        frequency: "daily",
        time: "evening",
        completed: false
      }
    ];
  }

  private generateWeeklyTreatmentSteps(baseId: string, skinProfile?: SkinProfile): WorkflowStep[] {
    return [
      {
        id: `${baseId}_w1`,
        workflowId: "",
        order: 1,
        type: "exfoliate",
        zone: "med",
        products: ["AHA/BHA Exfoliant"],
        instructions: "Apply to clean skin, leave for 10 minutes, rinse",
        duration: 15,
        frequency: "weekly",
        time: "evening",
        completed: false
      },
      {
        id: `${baseId}_w2`,
        workflowId: "",
        order: 2,
        type: "mask",
        zone: "spa",
        products: ["Hydrating Mask"],
        instructions: "Apply thick layer, leave for 15-20 minutes",
        duration: 20,
        frequency: "weekly",
        time: "evening",
        completed: false
      }
    ];
  }

  private generateAcneProgramSteps(baseId: string, skinProfile?: SkinProfile): WorkflowStep[] {
    return [
      {
        id: `${baseId}_a1`,
        workflowId: "",
        order: 1,
        type: "cleanse",
        zone: "spa",
        products: ["Salicylic Acid Cleanser"],
        instructions: "Massage for 60 seconds, focus on T-zone",
        duration: 2,
        frequency: "twice daily",
        time: "morning",
        completed: false
      },
      {
        id: `${baseId}_a2`,
        workflowId: "",
        order: 2,
        type: "treat",
        zone: "med",
        products: ["Benzoyl Peroxide Treatment"],
        instructions: "Apply thin layer to affected areas only",
        duration: 1,
        frequency: "daily",
        time: "evening",
        completed: false
      },
      {
        id: `${baseId}_a3`,
        workflowId: "",
        order: 3,
        type: "treat",
        zone: "zon",
        products: ["Niacinamide Serum"],
        instructions: "Apply to entire face to control sebum",
        duration: 1,
        frequency: "twice daily",
        completed: false
      },
      {
        id: `${baseId}_a4`,
        workflowId: "",
        order: 4,
        type: "moisturize",
        zone: "spa",
        products: ["Oil-Free Moisturizer"],
        instructions: "Apply light layer to hydrate without clogging pores",
        duration: 1,
        frequency: "twice daily",
        completed: false
      }
    ];
  }

  private generateAntiAgingSteps(baseId: string, skinProfile?: SkinProfile): WorkflowStep[] {
    return [
      {
        id: `${baseId}_aa1`,
        workflowId: "",
        order: 1,
        type: "cleanse",
        zone: "spa",
        products: ["Gentle Cream Cleanser"],
        instructions: "Massage gently, avoid tugging skin",
        duration: 2,
        frequency: "twice daily",
        completed: false
      },
      {
        id: `${baseId}_aa2`,
        workflowId: "",
        order: 2,
        type: "treat",
        zone: "zon",
        products: ["Vitamin C + E Serum"],
        instructions: "Apply to face and neck for antioxidant protection",
        duration: 1,
        frequency: "daily",
        time: "morning",
        completed: false
      },
      {
        id: `${baseId}_aa3`,
        workflowId: "",
        order: 3,
        type: "treat",
        zone: "med",
        products: ["Peptide Complex"],
        instructions: "Apply to areas of concern, especially around eyes",
        duration: 1,
        frequency: "twice daily",
        completed: false
      },
      {
        id: `${baseId}_aa4`,
        workflowId: "",
        order: 4,
        type: "treat",
        zone: "med",
        products: ["Retinol 0.5%"],
        instructions: "Apply at night, start 2x weekly, increase gradually",
        duration: 1,
        frequency: "3x weekly",
        time: "evening",
        completed: false
      },
      {
        id: `${baseId}_aa5`,
        workflowId: "",
        order: 5,
        type: "moisturize",
        zone: "spa",
        products: ["Rich Anti-Aging Cream"],
        instructions: "Apply using upward motions",
        duration: 1,
        frequency: "twice daily",
        completed: false
      },
      {
        id: `${baseId}_aa6`,
        workflowId: "",
        order: 6,
        type: "protect",
        zone: "zon",
        products: ["SPF 50+ with Antioxidants"],
        instructions: "Essential for preventing further aging",
        duration: 1,
        frequency: "daily",
        time: "morning",
        completed: false
      }
    ];
  }

  private generateDefaultReminders(workflowId: string, steps: WorkflowStep[]): WorkflowReminder[] {
    const reminders: WorkflowReminder[] = [];

    steps.forEach(step => {
      if (step.time === "morning") {
        reminders.push({
          id: `rem_${step.id}_am`,
          workflowId,
          stepId: step.id,
          time: "08:00",
          message: `Time for your morning ${step.type} step`,
          enabled: true
        });
      }
      if (step.time === "evening") {
        reminders.push({
          id: `rem_${step.id}_pm`,
          workflowId,
          stepId: step.id,
          time: "20:00",
          message: `Time for your evening ${step.type} step`,
          enabled: true
        });
      }
    });

    return reminders;
  }
}

export const workflowEngine = new WorkflowEngine();
