/**
 * REGIMA Skincare Ingredients Catalog
 * 
 * Comprehensive database of skincare ingredients used in REGIMA products,
 * their benefits, functions, and applications in professional treatments.
 */

export interface IngredientInfo {
  name: string;
  inciName?: string;
  category: string;
  mainFunctions: string[];
  benefits: string[];
  concentration: string;
  notes: string;
  skinTypes?: string[];
  concerns?: string[];
  contraindications?: string[];
  synergies?: string[];
  zoneCompatibility?: ('spa' | 'zon' | 'med')[];
}

export const ingredientsCatalog: IngredientInfo[] = [
  // Antioxidants
  {
    name: "Vitamin C (L-Ascorbic Acid)",
    inciName: "Ascorbic Acid",
    category: "Antioxidant",
    mainFunctions: [
      "Neutralizes free radicals",
      "Brightens skin tone",
      "Boosts collagen synthesis"
    ],
    benefits: [
      "Reduces pigmentation",
      "Protects against UV damage",
      "Improves skin firmness"
    ],
    concentration: "5-20%",
    notes: "Unstable in water-based formulations; most effective at pH 3.5 or lower. REGIMA uses stabilized forms with ferulic acid and vitamin E for enhanced efficacy.",
    skinTypes: ["all", "normal", "oily", "combination"],
    concerns: ["pigmentation", "dullness", "aging", "sun damage"],
    contraindications: ["very sensitive skin", "active eczema"],
    synergies: ["Vitamin E", "Ferulic Acid"],
    zoneCompatibility: ["zon", "med"]
  },
  {
    name: "Vitamin E (Tocopherol)",
    inciName: "Tocopherol",
    category: "Antioxidant",
    mainFunctions: [
      "Neutralizes free radicals",
      "Moisturizes skin",
      "Enhances barrier function"
    ],
    benefits: [
      "Soothes inflammation",
      "Improves skin hydration",
      "Heals skin barrier"
    ],
    concentration: "0.5-1%",
    notes: "Oil-soluble antioxidant that works synergistically with vitamin C in REGIMA formulations. Helps stabilize products and extend shelf life.",
    skinTypes: ["all", "dry", "sensitive"],
    concerns: ["dryness", "aging", "barrier damage"],
    synergies: ["Vitamin C", "Ferulic Acid"],
    zoneCompatibility: ["spa", "zon"]
  },
  {
    name: "Ferulic Acid",
    inciName: "Ferulic Acid",
    category: "Antioxidant",
    mainFunctions: [
      "Stabilizes vitamin C",
      "Enhances antioxidant efficacy",
      "UV protection booster"
    ],
    benefits: [
      "Doubles vitamin C effectiveness",
      "Reduces photodamage",
      "Anti-inflammatory"
    ],
    concentration: "0.5-1%",
    notes: "Plant-derived antioxidant that significantly boosts the stability and efficacy of vitamins C and E when combined.",
    skinTypes: ["all"],
    concerns: ["aging", "sun damage", "pigmentation"],
    synergies: ["Vitamin C", "Vitamin E"],
    zoneCompatibility: ["zon", "med"]
  },
  {
    name: "Resveratrol",
    inciName: "Resveratrol",
    category: "Antioxidant",
    mainFunctions: [
      "Potent antioxidant",
      "Anti-inflammatory",
      "Sirtuin activator"
    ],
    benefits: [
      "Protects against environmental damage",
      "Reduces signs of aging",
      "Calms irritation"
    ],
    concentration: "0.5-2%",
    notes: "Derived from grapes and berries. Activates longevity genes (sirtuins) for enhanced cellular protection.",
    skinTypes: ["all", "mature"],
    concerns: ["aging", "environmental damage"],
    zoneCompatibility: ["zon"]
  },

  // Exfoliants
  {
    name: "Glycolic Acid",
    inciName: "Glycolic Acid",
    category: "Alpha Hydroxy Acid (AHA)",
    mainFunctions: [
      "Exfoliates stratum corneum",
      "Improves skin texture",
      "Accelerates cell turnover"
    ],
    benefits: [
      "Reduces fine lines",
      "Brightens complexion",
      "Improves product penetration"
    ],
    concentration: "5-30%",
    notes: "Smallest AHA molecule for enhanced penetration. REGIMA professional treatments contain up to 30% concentration while retail products typically range from 5-10%.",
    skinTypes: ["normal", "oily", "combination"],
    concerns: ["texture", "dullness", "fine lines", "acne"],
    contraindications: ["sensitive skin", "active inflammation", "sunburn"],
    zoneCompatibility: ["med"]
  },
  {
    name: "Salicylic Acid",
    inciName: "Salicylic Acid",
    category: "Beta Hydroxy Acid (BHA)",
    mainFunctions: [
      "Exfoliates within pores",
      "Reduces sebum production",
      "Anti-inflammatory"
    ],
    benefits: [
      "Clears congestion",
      "Reduces acne lesions",
      "Refines pore appearance"
    ],
    concentration: "0.5-2%",
    notes: "Oil-soluble acid that penetrates sebum-filled follicles. REGIMA formulates with specialized delivery systems for enhanced penetration without irritation.",
    skinTypes: ["oily", "combination", "acne-prone"],
    concerns: ["acne", "blackheads", "enlarged pores", "oiliness"],
    contraindications: ["aspirin allergy", "pregnancy"],
    zoneCompatibility: ["med"]
  },
  {
    name: "Lactic Acid",
    inciName: "Lactic Acid",
    category: "Alpha Hydroxy Acid (AHA)",
    mainFunctions: [
      "Gentle exfoliation",
      "Hydration",
      "pH balancing"
    ],
    benefits: [
      "Improves skin texture",
      "Enhances moisture retention",
      "Reduces sensitivity"
    ],
    concentration: "5-10%",
    notes: "Larger molecule than glycolic acid, providing gentler exfoliation. Also functions as a humectant. Ideal for sensitive skin types in REGIMA sensitive skin protocols.",
    skinTypes: ["all", "sensitive", "dry"],
    concerns: ["texture", "dryness", "dullness"],
    zoneCompatibility: ["spa", "med"]
  },
  {
    name: "Mandelic Acid",
    inciName: "Mandelic Acid",
    category: "Alpha Hydroxy Acid (AHA)",
    mainFunctions: [
      "Gentle exfoliation",
      "Antibacterial",
      "Melanin inhibition"
    ],
    benefits: [
      "Safe for darker skin tones",
      "Reduces acne",
      "Brightens without irritation"
    ],
    concentration: "5-10%",
    notes: "Largest AHA molecule, making it the gentlest option. Particularly effective for acne-prone skin with hyperpigmentation concerns.",
    skinTypes: ["all", "sensitive", "darker skin tones"],
    concerns: ["acne", "pigmentation", "texture"],
    zoneCompatibility: ["spa", "med"]
  },

  // Hydrators
  {
    name: "Hyaluronic Acid",
    inciName: "Sodium Hyaluronate",
    category: "Humectant",
    mainFunctions: [
      "Attracts and binds water",
      "Plumps skin",
      "Creates moisture reservoir"
    ],
    benefits: [
      "Intense hydration",
      "Reduces appearance of fine lines",
      "Soothes irritation"
    ],
    concentration: "1-2%",
    notes: "REGIMA uses multi-molecular weight hyaluronic acid complexes for penetration at different skin levels. Can hold up to 1000x its weight in water.",
    skinTypes: ["all"],
    concerns: ["dehydration", "fine lines", "dullness"],
    zoneCompatibility: ["spa", "zon"]
  },
  {
    name: "Glycerin",
    inciName: "Glycerin",
    category: "Humectant",
    mainFunctions: [
      "Attracts water to skin surface",
      "Improves barrier function",
      "Enhances product spreadability"
    ],
    benefits: [
      "Hydrates without oiliness",
      "Soothes sensitive skin",
      "Facilitates healing"
    ],
    concentration: "3-10%",
    notes: "Foundation humectant in many REGIMA formulations. Creates an ideal base for other active ingredients to perform optimally.",
    skinTypes: ["all"],
    concerns: ["dehydration", "dryness"],
    zoneCompatibility: ["spa"]
  },
  {
    name: "Squalane",
    inciName: "Squalane",
    category: "Emollient",
    mainFunctions: [
      "Mimics skin's natural oils",
      "Locks in moisture",
      "Non-comedogenic hydration"
    ],
    benefits: [
      "Lightweight moisturization",
      "Improves skin elasticity",
      "Suitable for all skin types"
    ],
    concentration: "5-100%",
    notes: "Plant-derived version of squalene naturally found in skin. Excellent carrier for other active ingredients.",
    skinTypes: ["all", "oily", "sensitive"],
    concerns: ["dryness", "dehydration", "aging"],
    zoneCompatibility: ["spa", "zon"]
  },

  // Peptides
  {
    name: "Argireline (Acetyl Hexapeptide-8)",
    inciName: "Acetyl Hexapeptide-8",
    category: "Peptide",
    mainFunctions: [
      "Inhibits muscle contractions",
      "Reduces dynamic wrinkles",
      "Alternative to neurotoxins"
    ],
    benefits: [
      "Softens expression lines",
      "Non-invasive wrinkle reduction",
      "Prevents deepening of lines"
    ],
    concentration: "2-10%",
    notes: "REGIMA's signature peptide for expression line management. Particularly effective around eyes and forehead in the professional anti-aging protocols.",
    skinTypes: ["all", "mature"],
    concerns: ["expression lines", "wrinkles", "aging"],
    zoneCompatibility: ["med"]
  },
  {
    name: "Matrixyl (Palmitoyl Pentapeptide-4)",
    inciName: "Palmitoyl Pentapeptide-4",
    category: "Peptide",
    mainFunctions: [
      "Stimulates collagen production",
      "Improves elasticity",
      "Strengthens dermal matrix"
    ],
    benefits: [
      "Reduces wrinkle depth",
      "Improves skin firmness",
      "Enhances skin resilience"
    ],
    concentration: "2-5%",
    notes: "Signal peptide that mimics the body's own mechanisms for healing and collagen synthesis. Core component in REGIMA's regenerative treatments.",
    skinTypes: ["all", "mature"],
    concerns: ["aging", "loss of firmness", "wrinkles"],
    zoneCompatibility: ["med"]
  },
  {
    name: "Copper Peptides (GHK-Cu)",
    inciName: "Copper Tripeptide-1",
    category: "Peptide",
    mainFunctions: [
      "Wound healing",
      "Collagen synthesis",
      "Anti-inflammatory"
    ],
    benefits: [
      "Accelerates skin repair",
      "Reduces scarring",
      "Improves skin density"
    ],
    concentration: "0.1-1%",
    notes: "Powerful regenerative peptide. Best used in recovery protocols and post-procedure care.",
    skinTypes: ["all"],
    concerns: ["aging", "scarring", "wound healing"],
    contraindications: ["copper sensitivity"],
    zoneCompatibility: ["med"]
  },

  // Retinoids
  {
    name: "Retinol",
    inciName: "Retinol",
    category: "Retinoid",
    mainFunctions: [
      "Accelerates cell turnover",
      "Stimulates collagen and elastin",
      "Regulates sebum production"
    ],
    benefits: [
      "Reduces fine lines and wrinkles",
      "Improves skin texture",
      "Helps clear acne"
    ],
    concentration: "0.1-1%",
    notes: "REGIMA uses encapsulated, time-release technology for reduced irritation. Always paired with soothing agents in professional formulations to minimize sensitivity.",
    skinTypes: ["normal", "oily", "combination"],
    concerns: ["aging", "acne", "texture", "pigmentation"],
    contraindications: ["pregnancy", "breastfeeding", "very sensitive skin"],
    zoneCompatibility: ["med"]
  },
  {
    name: "Granactive Retinoid",
    inciName: "Hydroxypinacolone Retinoate",
    category: "Retinoid",
    mainFunctions: [
      "Similar benefits to retinol",
      "Lower irritation potential",
      "Enhanced stability"
    ],
    benefits: [
      "Suitable for sensitive skin",
      "Reduces signs of aging",
      "Improves skin clarity"
    ],
    concentration: "0.5-2%",
    notes: "Next-generation retinoid used in REGIMA's sensitive skin protocols. Provides retinol-like benefits without the typical irritation.",
    skinTypes: ["all", "sensitive"],
    concerns: ["aging", "texture", "fine lines"],
    zoneCompatibility: ["spa", "med"]
  },
  {
    name: "Bakuchiol",
    inciName: "Bakuchiol",
    category: "Retinoid Alternative",
    mainFunctions: [
      "Plant-based retinol alternative",
      "Antioxidant",
      "Anti-inflammatory"
    ],
    benefits: [
      "Safe during pregnancy",
      "No photosensitivity",
      "Gentle anti-aging"
    ],
    concentration: "0.5-2%",
    notes: "Natural alternative to retinol derived from the babchi plant. Can be used day and night without sun sensitivity concerns.",
    skinTypes: ["all", "sensitive", "pregnant"],
    concerns: ["aging", "fine lines"],
    zoneCompatibility: ["spa", "zon"]
  },

  // Calming & Soothing
  {
    name: "Centella Asiatica (Cica)",
    inciName: "Centella Asiatica Extract",
    category: "Botanical Extract",
    mainFunctions: [
      "Anti-inflammatory",
      "Healing accelerator",
      "Antioxidant protection"
    ],
    benefits: [
      "Calms redness and irritation",
      "Strengthens skin barrier",
      "Promotes collagen synthesis"
    ],
    concentration: "2-5% extract",
    notes: "REGIMA uses a proprietary complex of purified centella compounds (madecassoside, asiaticoside, madecassic acid, and asiatic acid) for enhanced efficacy.",
    skinTypes: ["all", "sensitive", "irritated"],
    concerns: ["redness", "sensitivity", "barrier damage", "acne scars"],
    zoneCompatibility: ["spa"]
  },
  {
    name: "Niacinamide (Vitamin B3)",
    inciName: "Niacinamide",
    category: "Vitamin",
    mainFunctions: [
      "Regulates sebum production",
      "Anti-inflammatory",
      "Strengthens barrier function"
    ],
    benefits: [
      "Reduces redness",
      "Minimizes pore appearance",
      "Evens skin tone"
    ],
    concentration: "2-10%",
    notes: "Multi-functional ingredient used across many REGIMA formulations. Compatible with most other actives and suitable for all skin types.",
    skinTypes: ["all"],
    concerns: ["oiliness", "enlarged pores", "redness", "pigmentation"],
    synergies: ["Hyaluronic Acid", "Zinc"],
    zoneCompatibility: ["spa", "zon"]
  },
  {
    name: "Allantoin",
    inciName: "Allantoin",
    category: "Soothing Agent",
    mainFunctions: [
      "Skin protectant",
      "Healing promoter",
      "Moisturizing"
    ],
    benefits: [
      "Soothes irritation",
      "Promotes cell regeneration",
      "Softens skin"
    ],
    concentration: "0.5-2%",
    notes: "Gentle ingredient suitable for even the most sensitive skin. Often used in post-procedure care.",
    skinTypes: ["all", "sensitive"],
    concerns: ["irritation", "dryness", "sensitivity"],
    zoneCompatibility: ["spa"]
  },
  {
    name: "Bisabolol",
    inciName: "Bisabolol",
    category: "Soothing Agent",
    mainFunctions: [
      "Anti-inflammatory",
      "Antibacterial",
      "Skin healing"
    ],
    benefits: [
      "Calms irritation",
      "Reduces redness",
      "Enhances ingredient absorption"
    ],
    concentration: "0.1-0.5%",
    notes: "Derived from chamomile. Excellent for calming reactive skin and enhancing the penetration of other ingredients.",
    skinTypes: ["all", "sensitive", "reactive"],
    concerns: ["redness", "irritation", "sensitivity"],
    zoneCompatibility: ["spa"]
  },

  // Brightening
  {
    name: "Tranexamic Acid",
    inciName: "Tranexamic Acid",
    category: "Brightening Agent",
    mainFunctions: [
      "Inhibits melanin production",
      "Anti-inflammatory",
      "Strengthens capillaries"
    ],
    benefits: [
      "Fades hyperpigmentation",
      "Reduces redness",
      "Prevents melasma recurrence"
    ],
    concentration: "2-5%",
    notes: "Core ingredient in REGIMA's brightening treatment protocols. Works synergistically with other brightening agents like niacinamide and vitamin C.",
    skinTypes: ["all"],
    concerns: ["hyperpigmentation", "melasma", "dark spots", "redness"],
    zoneCompatibility: ["zon", "med"]
  },
  {
    name: "Alpha Arbutin",
    inciName: "Alpha-Arbutin",
    category: "Brightening Agent",
    mainFunctions: [
      "Tyrosinase inhibitor",
      "Melanin production blocker",
      "Gentle brightening"
    ],
    benefits: [
      "Fades dark spots",
      "Evens skin tone",
      "Safe for all skin types"
    ],
    concentration: "1-2%",
    notes: "Gentler alternative to hydroquinone. Safe for long-term use and all skin tones.",
    skinTypes: ["all"],
    concerns: ["pigmentation", "dark spots", "uneven tone"],
    zoneCompatibility: ["zon"]
  },
  {
    name: "Kojic Acid",
    inciName: "Kojic Acid",
    category: "Brightening Agent",
    mainFunctions: [
      "Tyrosinase inhibitor",
      "Antioxidant",
      "Antibacterial"
    ],
    benefits: [
      "Lightens hyperpigmentation",
      "Prevents new dark spots",
      "Antifungal properties"
    ],
    concentration: "1-4%",
    notes: "Derived from fungi. Can be sensitizing for some skin types; best used in combination with soothing ingredients.",
    skinTypes: ["normal", "oily"],
    concerns: ["pigmentation", "dark spots"],
    contraindications: ["sensitive skin"],
    zoneCompatibility: ["med"]
  },

  // Specialty Ingredients
  {
    name: "Snow Mushroom Extract",
    inciName: "Tremella Fuciformis Extract",
    category: "Natural Polysaccharide",
    mainFunctions: [
      "Natural humectant",
      "Improves moisture retention",
      "Anti-inflammatory"
    ],
    benefits: [
      "Deep hydration",
      "Reduces fine lines",
      "Soothes sensitive skin"
    ],
    concentration: "1-5% extract",
    notes: "Natural alternative to hyaluronic acid with smaller particle size for deeper penetration. Used in REGIMA's premium hydrating formulations.",
    skinTypes: ["all"],
    concerns: ["dehydration", "fine lines", "dullness"],
    zoneCompatibility: ["spa", "zon"]
  },
  {
    name: "Azelaic Acid",
    inciName: "Azelaic Acid",
    category: "Multi-functional Acid",
    mainFunctions: [
      "Antibacterial",
      "Anti-inflammatory",
      "Tyrosinase inhibitor"
    ],
    benefits: [
      "Treats acne and rosacea",
      "Fades post-inflammatory hyperpigmentation",
      "Gentle exfoliation"
    ],
    concentration: "10-20%",
    notes: "Versatile ingredient effective for both acne and pigmentation. Safe during pregnancy.",
    skinTypes: ["all", "acne-prone", "rosacea"],
    concerns: ["acne", "rosacea", "pigmentation"],
    zoneCompatibility: ["spa", "med"]
  },
  {
    name: "Ceramides",
    inciName: "Ceramide NP, Ceramide AP, Ceramide EOP",
    category: "Lipid",
    mainFunctions: [
      "Barrier repair",
      "Moisture retention",
      "Skin protection"
    ],
    benefits: [
      "Strengthens skin barrier",
      "Reduces water loss",
      "Protects against irritants"
    ],
    concentration: "0.5-3%",
    notes: "Essential lipids that make up 50% of the skin barrier. Best used in combination with cholesterol and fatty acids.",
    skinTypes: ["all", "dry", "sensitive", "eczema-prone"],
    concerns: ["barrier damage", "dryness", "sensitivity"],
    synergies: ["Cholesterol", "Fatty Acids"],
    zoneCompatibility: ["spa"]
  }
];

// Export organized by category
export const ingredientsByCategory = ingredientsCatalog.reduce((acc, ingredient) => {
  if (!acc[ingredient.category]) {
    acc[ingredient.category] = [];
  }
  acc[ingredient.category].push(ingredient);
  return acc;
}, {} as Record<string, IngredientInfo[]>);

// Export organized by concern
export const ingredientsByConcern = ingredientsCatalog.reduce((acc, ingredient) => {
  ingredient.concerns?.forEach(concern => {
    if (!acc[concern]) {
      acc[concern] = [];
    }
    acc[concern].push(ingredient);
  });
  return acc;
}, {} as Record<string, IngredientInfo[]>);

// Export organized by Zone
export const ingredientsByZone = ingredientsCatalog.reduce((acc, ingredient) => {
  ingredient.zoneCompatibility?.forEach(zone => {
    if (!acc[zone]) {
      acc[zone] = [];
    }
    acc[zone].push(ingredient);
  });
  return acc;
}, {} as Record<string, IngredientInfo[]>);

// Helper functions
export function getIngredientInfo(name: string): IngredientInfo | undefined {
  return ingredientsCatalog.find(ingredient =>
    ingredient.name.toLowerCase() === name.toLowerCase() ||
    ingredient.name.toLowerCase().includes(name.toLowerCase()) ||
    ingredient.inciName?.toLowerCase() === name.toLowerCase()
  );
}

export function getIngredientsForConcern(concern: string): IngredientInfo[] {
  return ingredientsCatalog.filter(ingredient =>
    ingredient.concerns?.some(c => c.toLowerCase().includes(concern.toLowerCase()))
  );
}

export function getIngredientsForSkinType(skinType: string): IngredientInfo[] {
  return ingredientsCatalog.filter(ingredient =>
    ingredient.skinTypes?.some(t => 
      t.toLowerCase() === skinType.toLowerCase() || t === 'all'
    )
  );
}

export function checkIngredientCompatibility(
  ingredient1: string,
  ingredient2: string
): { compatible: boolean; notes?: string } {
  const info1 = getIngredientInfo(ingredient1);
  const info2 = getIngredientInfo(ingredient2);

  if (!info1 || !info2) {
    return { compatible: true, notes: "Unable to verify compatibility" };
  }

  // Check if they're synergistic
  if (info1.synergies?.some(s => s.toLowerCase().includes(ingredient2.toLowerCase())) ||
      info2.synergies?.some(s => s.toLowerCase().includes(ingredient1.toLowerCase()))) {
    return { compatible: true, notes: "These ingredients work synergistically together" };
  }

  // Known conflicts
  const conflicts = [
    { pair: ["retinol", "vitamin c"], note: "Use at different times of day" },
    { pair: ["retinol", "aha"], note: "May cause irritation; alternate nights" },
    { pair: ["retinol", "bha"], note: "May cause irritation; alternate nights" },
    { pair: ["vitamin c", "niacinamide"], note: "Can be used together despite old myths" },
    { pair: ["aha", "bha"], note: "Can be combined but may increase sensitivity" }
  ];

  for (const conflict of conflicts) {
    const name1Lower = ingredient1.toLowerCase();
    const name2Lower = ingredient2.toLowerCase();
    if ((conflict.pair[0].includes(name1Lower) || name1Lower.includes(conflict.pair[0])) &&
        (conflict.pair[1].includes(name2Lower) || name2Lower.includes(conflict.pair[1]))) {
      return { compatible: true, notes: conflict.note };
    }
  }

  return { compatible: true };
}
