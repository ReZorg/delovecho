/**
 * RegimA Data Module
 * Static data catalogs and reference information
 */

export * from "./ingredients-catalog.js";
