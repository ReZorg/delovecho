import { pgTable, text, serial, integer, boolean, timestamp, json, varchar, index } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from 'drizzle-orm';

// ============================================================================
// Session & Authentication Tables
// ============================================================================

export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: json("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").unique(),
  password: text("password"),
  name: text("name").notNull(),
  role: text("role").notNull(),
  replitUserId: varchar("replit_user_id").unique(),
  email: varchar("email"),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ============================================================================
// Training Content Tables
// ============================================================================

export const modules = pgTable("modules", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  estimatedTime: text("estimated_time").notNull(),
  order: integer("order").notNull(),
});

export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  moduleId: integer("module_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  content: text("content").notNull(),
  videoUrl: text("video_url"),
  order: integer("order").notNull(),
});

export const steps = pgTable("steps", {
  id: serial("id").primaryKey(),
  lessonId: integer("lesson_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  order: integer("order").notNull(),
});

export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  lessonId: integer("lesson_id").notNull(),
  title: text("title").notNull(),
  type: text("type").notNull(),
  url: text("url").notNull(),
  fileSize: text("file_size"),
});

// ============================================================================
// Product & Ingredient Tables
// ============================================================================

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  type: text("type").notNull(),
  description: text("description").notNull(),
  mainFunctions: text("main_functions").array(),
  starIngredients: json("star_ingredients"),
  keyIngredients: text("key_ingredients").array(),
  activeIngredients: text("active_ingredients").array(),
  skinTypes: text("skin_types").array(),
  size: text("size"),
  usageInstructions: text("usage_instructions").notNull(),
  pH: text("ph"),
  zoneAction: text("zone_action").array(),
  imageUrl: text("image_url"),
  ingredients: text("ingredients").array(),
});

export const ingredients = pgTable("ingredients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  inciName: text("inci_name"),
  category: text("category").notNull(),
  description: text("description").notNull(),
  benefits: text("benefits").array(),
  skinTypes: text("skin_types").array(),
  concerns: text("concerns").array(),
  contraindications: text("contraindications").array(),
  concentration: text("concentration"),
  synergies: text("synergies").array(),
  zoneCompatibility: text("zone_compatibility").array(),
});

// ============================================================================
// Quiz & Assessment Tables
// ============================================================================

export const quizzes = pgTable("quizzes", {
  id: serial("id").primaryKey(),
  lessonId: integer("lesson_id").notNull(),
  questions: json("questions").notNull(),
});

// ============================================================================
// User Progress & Tracking Tables
// ============================================================================

export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  moduleId: integer("module_id").notNull(),
  lessonId: integer("lesson_id").notNull(),
  completed: boolean("completed").default(false).notNull(),
  quizScore: integer("quiz_score"),
  lastAccessed: timestamp("last_accessed").defaultNow().notNull(),
});

export const userNotes = pgTable("user_notes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  lessonId: integer("lesson_id").notNull(),
  content: text("content").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const lessonFeedback = pgTable("lesson_feedback", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  lessonId: integer("lesson_id").notNull(),
  rating: integer("rating").notNull(),
  comment: text("comment"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const certificates = pgTable("certificates", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  moduleId: integer("module_id").notNull(),
  issueDate: timestamp("issue_date").defaultNow().notNull(),
});

// ============================================================================
// Agent & Automation Tables
// ============================================================================

export const agentConversations = pgTable(
  "agent_conversations",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    title: text("title").notNull(),
    context: json("context"),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_agent_conversations_user_id").on(table.userId),
    index("idx_agent_conversations_is_active").on(table.isActive),
  ]
);

export const agentMessages = pgTable(
  "agent_messages",
  {
    id: serial("id").primaryKey(),
    conversationId: integer("conversation_id").notNull(),
    role: text("role").notNull(),
    content: text("content").notNull(),
    metadata: json("metadata"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_agent_messages_conversation_id").on(table.conversationId),
    index("idx_agent_messages_created_at").on(table.createdAt),
  ]
);

export const consultations = pgTable(
  "consultations",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    conversationId: integer("conversation_id"),
    skinType: text("skin_type"),
    skinConcerns: text("skin_concerns").array(),
    currentProducts: text("current_products").array(),
    lifestyleFactors: json("lifestyle_factors"),
    goals: text("goals").array(),
    status: text("status").default("draft").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_consultations_user_id").on(table.userId),
    index("idx_consultations_conversation_id").on(table.conversationId),
    index("idx_consultations_status").on(table.status),
  ]
);

export const recommendations = pgTable(
  "recommendations",
  {
    id: serial("id").primaryKey(),
    consultationId: integer("consultation_id").notNull(),
    recommendationType: text("recommendation_type").notNull(),
    recommendedItems: json("recommended_items").notNull(),
    reasoning: text("reasoning").notNull(),
    priority: integer("priority").default(0).notNull(),
    isAccepted: boolean("is_accepted"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_recommendations_consultation_id").on(table.consultationId),
    index("idx_recommendations_type").on(table.recommendationType),
    index("idx_recommendations_priority").on(table.priority),
  ]
);

export const automatedProtocols = pgTable(
  "automated_protocols",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    protocolType: text("protocol_type").notNull(),
    schedule: json("schedule").notNull(),
    progress: json("progress"),
    nextStep: text("next_step"),
    isActive: boolean("is_active").default(true).notNull(),
    startDate: timestamp("start_date").notNull(),
    endDate: timestamp("end_date"),
  },
  (table) => [
    index("idx_automated_protocols_user_id").on(table.userId),
    index("idx_automated_protocols_is_active").on(table.isActive),
    index("idx_automated_protocols_start_date").on(table.startDate),
  ]
);

// ============================================================================
// Workflow Tables
// ============================================================================

export const workflows = pgTable(
  "workflows",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    type: text("type").notNull(),
    name: text("name").notNull(),
    description: text("description"),
    status: text("status").default("active").notNull(),
    startDate: timestamp("start_date").notNull(),
    endDate: timestamp("end_date"),
    duration: integer("duration").notNull(),
    skinType: text("skin_type"),
    skinConcerns: text("skin_concerns").array(),
    steps: json("steps").notNull(),
    progress: json("progress"),
    adaptations: json("adaptations"),
    reminders: json("reminders"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_workflows_user_id").on(table.userId),
    index("idx_workflows_status").on(table.status),
    index("idx_workflows_type").on(table.type),
  ]
);

// ============================================================================
// Insert Schemas
// ============================================================================

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, updatedAt: true });
export const upsertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, updatedAt: true, username: true, password: true, name: true, role: true });
export const insertModuleSchema = createInsertSchema(modules).omit({ id: true });
export const insertLessonSchema = createInsertSchema(lessons).omit({ id: true });
export const insertStepSchema = createInsertSchema(steps).omit({ id: true });
export const insertResourceSchema = createInsertSchema(resources).omit({ id: true });
export const insertProductSchema = createInsertSchema(products).omit({ id: true });
export const insertIngredientSchema = createInsertSchema(ingredients).omit({ id: true });
export const insertQuizSchema = createInsertSchema(quizzes).omit({ id: true });
export const insertUserProgressSchema = createInsertSchema(userProgress).omit({ id: true, lastAccessed: true });
export const insertUserNoteSchema = createInsertSchema(userNotes).omit({ id: true, updatedAt: true });
export const insertLessonFeedbackSchema = createInsertSchema(lessonFeedback).omit({ id: true, createdAt: true });
export const insertCertificateSchema = createInsertSchema(certificates).omit({ id: true, issueDate: true });
export const insertAgentConversationSchema = createInsertSchema(agentConversations).omit({ id: true, createdAt: true, updatedAt: true });
export const insertAgentMessageSchema = createInsertSchema(agentMessages).omit({ id: true, createdAt: true });
export const insertConsultationSchema = createInsertSchema(consultations).omit({ id: true, createdAt: true, updatedAt: true });
export const insertRecommendationSchema = createInsertSchema(recommendations).omit({ id: true, createdAt: true });
export const insertAutomatedProtocolSchema = createInsertSchema(automatedProtocols).omit({ id: true });
export const insertWorkflowSchema = createInsertSchema(workflows).omit({ id: true, createdAt: true, updatedAt: true });

// ============================================================================
// Types
// ============================================================================

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpsertUser = z.infer<typeof upsertUserSchema>;

export type Module = typeof modules.$inferSelect;
export type InsertModule = z.infer<typeof insertModuleSchema>;

export type Lesson = typeof lessons.$inferSelect;
export type InsertLesson = z.infer<typeof insertLessonSchema>;

export type Step = typeof steps.$inferSelect;
export type InsertStep = z.infer<typeof insertStepSchema>;

export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type Ingredient = typeof ingredients.$inferSelect;
export type InsertIngredient = z.infer<typeof insertIngredientSchema>;

export type Quiz = typeof quizzes.$inferSelect;
export type InsertQuiz = z.infer<typeof insertQuizSchema>;

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;

export type UserNote = typeof userNotes.$inferSelect;
export type InsertUserNote = z.infer<typeof insertUserNoteSchema>;

export type LessonFeedback = typeof lessonFeedback.$inferSelect;
export type InsertLessonFeedback = z.infer<typeof insertLessonFeedbackSchema>;

export type Certificate = typeof certificates.$inferSelect;
export type InsertCertificate = z.infer<typeof insertCertificateSchema>;

export type AgentConversation = typeof agentConversations.$inferSelect;
export type InsertAgentConversation = z.infer<typeof insertAgentConversationSchema>;

export type AgentMessage = typeof agentMessages.$inferSelect;
export type InsertAgentMessage = z.infer<typeof insertAgentMessageSchema>;

export type Consultation = typeof consultations.$inferSelect;
export type InsertConsultation = z.infer<typeof insertConsultationSchema>;

export type Recommendation = typeof recommendations.$inferSelect;
export type InsertRecommendation = z.infer<typeof insertRecommendationSchema>;

export type AutomatedProtocol = typeof automatedProtocols.$inferSelect;
export type InsertAutomatedProtocol = z.infer<typeof insertAutomatedProtocolSchema>;

export type Workflow = typeof workflows.$inferSelect;
export type InsertWorkflow = z.infer<typeof insertWorkflowSchema>;

// ============================================================================
// Question Schema for Quizzes
// ============================================================================

export const questionSchema = z.object({
  id: z.string(),
  question: z.string(),
  options: z.array(z.object({
    id: z.string(),
    text: z.string(),
  })),
  correctOptionId: z.string(),
});

export type Question = z.infer<typeof questionSchema>;

// ============================================================================
// Zone Types
// ============================================================================

export type ZoneType = "spa" | "zon" | "med";

export const zoneTypeSchema = z.enum(["spa", "zon", "med"]);

export interface ZoneDefinition {
  type: ZoneType;
  name: string;
  description: string;
  intensity: number;
  targetConcerns: string[];
  contraindications: string[];
}

// ============================================================================
// Workflow Types
// ============================================================================

export type WorkflowType = 
  | "daily_routine"
  | "weekly_treatment"
  | "monthly_protocol"
  | "acne_program"
  | "anti_aging_program";

export type WorkflowStatus = "active" | "paused" | "completed" | "cancelled";

export const workflowTypeSchema = z.enum([
  "daily_routine",
  "weekly_treatment",
  "monthly_protocol",
  "acne_program",
  "anti_aging_program"
]);

export const workflowStatusSchema = z.enum(["active", "paused", "completed", "cancelled"]);
