/**
 * Recommendation Engine Unit Tests
 */

import { describe, it, expect, beforeEach } from "vitest";
import { RecommendationEngine } from "../src/agent/recommendation-engine.js";

describe("RecommendationEngine", () => {
  let engine: RecommendationEngine;

  beforeEach(() => {
    engine = new RecommendationEngine();
  });

  describe("analyzeSkincareNeeds", () => {
    it("should analyze skincare needs for oily skin with acne", () => {
      const result = engine.analyzeSkincareNeeds("oily", ["acne", "enlarged pores"], ["clear skin"]);

      expect(result).toBeDefined();
      expect(result.skinType).toBe("oily");
      expect(result.primaryConcerns.length).toBeGreaterThan(0);
      expect(result.zoneRequirements).toBeDefined();
      expect(result.recommendedCategories).toBeDefined();
    });

    it("should analyze skincare needs for dry skin with aging concerns", () => {
      const result = engine.analyzeSkincareNeeds("dry", ["fine lines", "dehydration"], ["anti-aging", "hydration"]);

      expect(result).toBeDefined();
      expect(result.skinType).toBe("dry");
      expect(result.zoneRequirements.rejuvenationNeeds).toBeGreaterThan(0);
    });

    it("should prioritize concerns by severity", () => {
      const result = engine.analyzeSkincareNeeds("combination", ["dullness", "acne", "fine lines"], ["clear skin"]);

      expect(result).toBeDefined();
      expect(result.primaryConcerns.length).toBeLessThanOrEqual(2);
    });
  });

  describe("calculateProductMatchScore", () => {
    it("should calculate match score for a product", () => {
      const product = {
        id: 1,
        name: "Test Cleanser",
        category: "Cleansers",
        type: "professional" as const,
        skinTypes: ["oily", "combination"],
        mainFunctions: ["Cleansing", "Oil control"],
        keyIngredients: ["Salicylic acid"],
        description: "A gentle cleanser for oily skin",
      };

      const result = engine.calculateProductMatchScore(product, "oily", ["acne"], ["clear skin"]);

      expect(result).toBeDefined();
      expect(result.matchScore).toBeGreaterThanOrEqual(0);
      expect(result.matchReasons).toBeDefined();
      expect(result.benefits).toBeDefined();
    });
  });

  describe("analyzeProductSynergies", () => {
    it("should analyze synergies between products", () => {
      const products = [
        {
          id: 1,
          name: "Vitamin C Serum",
          category: "Serums",
          type: "professional" as const,
          keyIngredients: ["Vitamin C", "Ferulic acid"],
        },
        {
          id: 2,
          name: "Vitamin E Moisturizer",
          category: "Moisturizers",
          type: "professional" as const,
          keyIngredients: ["Vitamin E", "Ceramides"],
        },
      ];

      const result = engine.analyzeProductSynergies(products);

      expect(result).toBeDefined();
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("checkProductConflicts", () => {
    it("should detect conflicts between products", () => {
      const product1 = {
        id: 1,
        name: "Retinol Serum",
        category: "Serums",
        type: "professional" as const,
        keyIngredients: ["Retinol"],
      };

      const product2 = {
        id: 2,
        name: "AHA Exfoliant",
        category: "Exfoliants",
        type: "professional" as const,
        keyIngredients: ["Glycolic acid", "AHA"],
      };

      const result = engine.checkProductConflicts(product1, product2);

      expect(result).toBeDefined();
      expect(typeof result.hasConflict).toBe("boolean");
    });

    it("should not detect conflicts for compatible products", () => {
      const product1 = {
        id: 1,
        name: "Hyaluronic Acid Serum",
        category: "Serums",
        type: "professional" as const,
        keyIngredients: ["Hyaluronic acid"],
      };

      const product2 = {
        id: 2,
        name: "Niacinamide Serum",
        category: "Serums",
        type: "professional" as const,
        keyIngredients: ["Niacinamide"],
      };

      const result = engine.checkProductConflicts(product1, product2);

      expect(result).toBeDefined();
    });
  });
});
