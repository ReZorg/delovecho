/**
 * Workflow Engine Unit Tests
 */

import { describe, it, expect, beforeEach } from "vitest";
import { WorkflowEngine } from "../src/agent/workflow-engine.js";

describe("WorkflowEngine", () => {
  let engine: WorkflowEngine;

  beforeEach(() => {
    engine = new WorkflowEngine();
  });

  describe("createWorkflow", () => {
    it("should create a daily routine workflow", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);

      expect(workflow).toBeDefined();
      expect(workflow.id).toBeDefined();
      expect(workflow.type).toBe("daily_routine");
      expect(workflow.userId).toBe(1);
      expect(workflow.duration).toBe(30);
      expect(workflow.status).toBe("active");
      expect(workflow.steps.length).toBeGreaterThan(0);
    });

    it("should create a weekly treatment workflow", async () => {
      const workflow = await engine.createWorkflow(1, "weekly_treatment", 8);

      expect(workflow).toBeDefined();
      expect(workflow.type).toBe("weekly_treatment");
      expect(workflow.duration).toBe(8);
    });

    it("should create an acne program workflow", async () => {
      const workflow = await engine.createWorkflow(1, "acne_program", 90, {
        skinType: "oily",
        skinConcerns: ["acne", "enlarged pores"],
      });

      expect(workflow).toBeDefined();
      expect(workflow.type).toBe("acne_program");
    });

    it("should create an anti-aging program workflow", async () => {
      const workflow = await engine.createWorkflow(1, "anti_aging_program", 120, {
        skinType: "dry",
        skinConcerns: ["fine lines", "wrinkles"],
      });

      expect(workflow).toBeDefined();
      expect(workflow.type).toBe("anti_aging_program");
    });

    it("should use default duration if not specified", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine");

      expect(workflow.duration).toBeGreaterThan(0);
    });

    it("should initialize progress tracking", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);

      expect(workflow.progress).toBeDefined();
      expect(workflow.progress.completedSteps).toBe(0);
      expect(workflow.progress.totalSteps).toBe(workflow.steps.length);
      expect(workflow.progress.compliance).toBeGreaterThanOrEqual(0);
    });
  });

  describe("getWorkflow", () => {
    it("should retrieve a created workflow", async () => {
      const created = await engine.createWorkflow(1, "daily_routine", 30);
      const retrieved = engine.getWorkflow(created.id);

      expect(retrieved).toBeDefined();
      expect(retrieved?.id).toBe(created.id);
      expect(retrieved?.type).toBe(created.type);
    });

    it("should return undefined for non-existent workflow", () => {
      const result = engine.getWorkflow("non-existent-id");

      expect(result).toBeUndefined();
    });
  });

  describe("getActiveWorkflows", () => {
    it("should return active workflows for a user", async () => {
      // Create fresh engine for this test
      const testEngine = new WorkflowEngine();
      await testEngine.createWorkflow(1, "daily_routine", 30);
      await testEngine.createWorkflow(1, "weekly_treatment", 8);
      await testEngine.createWorkflow(2, "daily_routine", 30);

      const workflows = await testEngine.getActiveWorkflows(1);

      expect(workflows).toBeDefined();
      expect(workflows.length).toBeGreaterThanOrEqual(1);
      expect(workflows.every((w) => w.userId === 1)).toBe(true);
    });

    it("should return empty array for user with no workflows", async () => {
      const testEngine = new WorkflowEngine();
      const workflows = await testEngine.getActiveWorkflows(999);

      expect(workflows).toEqual([]);
    });
  });

  describe("getNextSteps", () => {
    it("should return next steps for a workflow", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);
      const steps = await engine.getNextSteps(workflow.id, 5);

      expect(steps).toBeDefined();
      expect(steps.length).toBeLessThanOrEqual(5);
    });

    it("should return steps in order", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);
      const steps = await engine.getNextSteps(workflow.id, 10);

      for (let i = 1; i < steps.length; i++) {
        expect(steps[i].order).toBeGreaterThanOrEqual(steps[i - 1].order);
      }
    });

    it("should return empty array for non-existent workflow", async () => {
      const steps = await engine.getNextSteps("non-existent", 5);

      expect(steps).toEqual([]);
    });
  });

  describe("executeStep", () => {
    it("should execute the current step", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);
      const step = await engine.executeStep(workflow.id);

      expect(step).toBeDefined();
      expect(step?.completed).toBe(true);
      expect(step?.completedAt).toBeDefined();
    });

    it("should update workflow progress after execution", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);
      await engine.executeStep(workflow.id);

      const updated = engine.getWorkflow(workflow.id);

      expect(updated?.progress.completedSteps).toBe(1);
    });

    it("should return null for non-existent workflow", async () => {
      const step = await engine.executeStep("non-existent");

      expect(step).toBeNull();
    });
  });

  describe("updateProgress", () => {
    it("should update progress with feedback", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);
      await engine.executeStep(workflow.id);

      const progress = await engine.updateProgress(workflow.id, {
        stepNotes: "Skin felt good after application",
        skinResponse: {
          reaction: "positive",
          improvements: ["less redness"],
        },
      });

      expect(progress).toBeDefined();
    });

    it("should track product feedback", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);
      await engine.executeStep(workflow.id);

      const progress = await engine.updateProgress(workflow.id, {
        productFeedback: [
          {
            productName: "Cleanser",
            rating: 4,
            notes: "Nice texture",
          },
        ],
      });

      expect(progress).toBeDefined();
    });
  });

  describe("adjustWorkflow", () => {
    it("should adjust workflow based on feedback", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);
      
      const adjusted = await engine.adjustWorkflow(workflow.id, {
        reason: "Skin sensitivity",
        feedback: { reaction: "negative" },
      });

      expect(adjusted).toBeDefined();
    });

    it("should return null for non-existent workflow", async () => {
      const adjusted = await engine.adjustWorkflow("non-existent", {
        reason: "Test",
        feedback: {},
      });

      expect(adjusted).toBeNull();
    });
  });

  describe("pauseWorkflow", () => {
    it("should pause an active workflow", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);
      const success = await engine.pauseWorkflow(workflow.id);

      expect(success).toBe(true);

      const updated = engine.getWorkflow(workflow.id);
      expect(updated?.status).toBe("paused");
    });

    it("should return false for non-existent workflow", async () => {
      const success = await engine.pauseWorkflow("non-existent");

      expect(success).toBe(false);
    });
  });

  describe("resumeWorkflow", () => {
    it("should resume a paused workflow", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);
      await engine.pauseWorkflow(workflow.id);
      const success = await engine.resumeWorkflow(workflow.id);

      expect(success).toBe(true);

      const updated = engine.getWorkflow(workflow.id);
      expect(updated?.status).toBe("active");
    });

    it("should return false for non-paused workflow", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);
      const success = await engine.resumeWorkflow(workflow.id);

      // May succeed or fail depending on implementation
      expect(typeof success).toBe("boolean");
    });
  });

  describe("completeWorkflow", () => {
    it("should mark workflow as complete", async () => {
      const workflow = await engine.createWorkflow(1, "daily_routine", 30);
      const success = await engine.completeWorkflow(workflow.id);

      expect(success).toBe(true);

      const updated = engine.getWorkflow(workflow.id);
      expect(updated?.status).toBe("completed");
      expect(updated?.endDate).toBeDefined();
    });

    it("should return false for non-existent workflow", async () => {
      const success = await engine.completeWorkflow("non-existent");

      expect(success).toBe(false);
    });
  });
});
