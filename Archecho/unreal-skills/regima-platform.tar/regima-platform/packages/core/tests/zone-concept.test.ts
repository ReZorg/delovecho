/**
 * Zone Concept Unit Tests
 */

import { describe, it, expect, beforeEach } from "vitest";
import { ZoneConceptAnalyzer, ZoneConcept } from "../src/agent/zone-concept.js";

describe("ZoneConceptAnalyzer", () => {
  let analyzer: ZoneConceptAnalyzer;

  beforeEach(() => {
    analyzer = new ZoneConceptAnalyzer();
  });

  describe("analyzeSkinProfile", () => {
    it("should analyze a basic skin profile", () => {
      const profile = {
        skinType: "oily",
        skinConcerns: ["acne", "enlarged pores"],
        currentProducts: [],
        lifestyle: {
          stressLevel: "high" as const,
          sleepQuality: "poor" as const,
          diet: "moderate" as const,
          sunExposure: "moderate" as const,
        },
      };

      const result = analyzer.analyzeSkinProfile(profile);

      expect(result).toBeDefined();
      expect(result.zoneScores).toBeDefined();
      expect(result.zoneScores.antiInflammatory).toBeGreaterThanOrEqual(0);
      expect(result.zoneScores.antiInflammatory).toBeLessThanOrEqual(100);
      expect(result.zoneScores.antiOxidant).toBeGreaterThanOrEqual(0);
      expect(result.zoneScores.antiOxidant).toBeLessThanOrEqual(100);
      expect(result.zoneScores.rejuvenation).toBeGreaterThanOrEqual(0);
      expect(result.zoneScores.rejuvenation).toBeLessThanOrEqual(100);
    });

    it("should identify primary zone correctly for acne concerns", () => {
      const profile = {
        skinType: "oily",
        skinConcerns: ["acne", "inflammation"],
        currentProducts: [],
        lifestyle: {
          stressLevel: "high" as const,
          sleepQuality: "moderate" as const,
          diet: "moderate" as const,
          sunExposure: "low" as const,
        },
      };

      const result = analyzer.analyzeSkinProfile(profile);

      expect(result.primaryZone).toBe("spa");
    });

    it("should identify primary zone correctly for aging concerns", () => {
      const profile = {
        skinType: "dry",
        skinConcerns: ["fine lines", "wrinkles", "loss of elasticity"],
        currentProducts: [],
        lifestyle: {
          stressLevel: "moderate" as const,
          sleepQuality: "moderate" as const,
          diet: "good" as const,
          sunExposure: "high" as const,
        },
      };

      const result = analyzer.analyzeSkinProfile(profile);

      // With aging concerns, med or zon should be primary
      expect(["med", "zon"]).toContain(result.primaryZone);
    });

    it("should identify primary zone correctly for oxidative stress concerns", () => {
      const profile = {
        skinType: "combination",
        skinConcerns: ["dullness", "uneven skin tone", "hyperpigmentation"],
        currentProducts: [],
        lifestyle: {
          stressLevel: "high" as const,
          sleepQuality: "poor" as const,
          diet: "poor" as const,
          sunExposure: "high" as const,
        },
      };

      const result = analyzer.analyzeSkinProfile(profile);

      expect(result.primaryZone).toBe("zon");
    });

    it("should provide recommendations for each zone", () => {
      const profile = {
        skinType: "normal",
        skinConcerns: ["prevention"],
        currentProducts: [],
        lifestyle: {
          stressLevel: "low" as const,
          sleepQuality: "good" as const,
          diet: "good" as const,
          sunExposure: "moderate" as const,
        },
      };

      const result = analyzer.analyzeSkinProfile(profile);

      expect(result.recommendations).toBeDefined();
      expect(result.recommendations.spa).toBeDefined();
      expect(result.recommendations.zon).toBeDefined();
      expect(result.recommendations.med).toBeDefined();
    });
  });

  describe("analyzeProduct", () => {
    it("should analyze a product with anti-inflammatory ingredients", () => {
      const product = {
        name: "Calming Serum",
        ingredients: ["niacinamide", "centella asiatica", "aloe vera"],
      };

      const result = analyzer.analyzeProduct(product);

      expect(result).toBeDefined();
      expect(result.zoneScores.antiInflammatory).toBeGreaterThan(0);
      expect(result.primaryZone).toBe("spa");
    });

    it("should analyze a product with antioxidant ingredients", () => {
      const product = {
        name: "Vitamin C Serum",
        ingredients: ["vitamin c", "vitamin e", "ferulic acid"],
      };

      const result = analyzer.analyzeProduct(product);

      expect(result).toBeDefined();
      expect(result.zoneScores.antiOxidant).toBeGreaterThan(0);
      expect(result.primaryZone).toBe("zon");
    });

    it("should analyze a product with rejuvenation ingredients", () => {
      const product = {
        name: "Retinol Night Cream",
        ingredients: ["retinol", "peptides", "hyaluronic acid"],
      };

      const result = analyzer.analyzeProduct(product);

      expect(result).toBeDefined();
      expect(result.zoneScores.rejuvenation).toBeGreaterThan(0);
      expect(result.primaryZone).toBe("med");
    });
  });

  describe("getZoneInfo", () => {
    it("should return information for all zones", () => {
      const info = analyzer.getZoneInfo();

      expect(info).toBeDefined();
      expect(info.zones).toHaveLength(3);
      expect(info.zones.map((z) => z.id)).toContain("spa");
      expect(info.zones.map((z) => z.id)).toContain("zon");
      expect(info.zones.map((z) => z.id)).toContain("med");
    });

    it("should include philosophy description", () => {
      const info = analyzer.getZoneInfo();

      expect(info.philosophy).toBeDefined();
      expect(info.philosophy.length).toBeGreaterThan(0);
    });

    it("should include key ingredients for each zone", () => {
      const info = analyzer.getZoneInfo();

      for (const zone of info.zones) {
        expect(zone.keyIngredients).toBeDefined();
        expect(zone.keyIngredients.length).toBeGreaterThan(0);
      }
    });
  });
});

describe("ZoneConcept (Legacy)", () => {
  let zoneConcept: ZoneConcept;

  beforeEach(() => {
    zoneConcept = new ZoneConcept();
  });

  describe("calculateZoneRequirements", () => {
    it("should calculate zone requirements for oily skin", () => {
      const result = zoneConcept.calculateZoneRequirements("oily", ["acne"]);

      expect(result).toBeDefined();
      expect(result.skinType).toBe("oily");
      expect(result.antiInflammatoryNeeds).toBeGreaterThan(0);
      expect(result.antiOxidantNeeds).toBeGreaterThan(0);
      expect(result.rejuvenationNeeds).toBeGreaterThan(0);
    });
  });
});
